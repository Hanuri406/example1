// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_dcache_core_data_ram.h"

void Vriscv_top_dcache_core_data_ram___ctor_var_reset(Vriscv_top_dcache_core_data_ram* vlSelf);

Vriscv_top_dcache_core_data_ram::Vriscv_top_dcache_core_data_ram(Vriscv_top__Syms* symsp, const char* name)
    : VerilatedModule{name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vriscv_top_dcache_core_data_ram___ctor_var_reset(this);
}

void Vriscv_top_dcache_core_data_ram::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vriscv_top_dcache_core_data_ram::~Vriscv_top_dcache_core_data_ram() {
}
