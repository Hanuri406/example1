// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_dcache.h"

VL_INLINE_OPT void Vriscv_top_dcache___combo__TOP__v__u_dcache__0(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___combo__TOP__v__u_dcache__0\n"); );
    // Body
    vlSelf->__PVT__pmem_ack_w = ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bvalid_i) 
                                 | (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rvalid_i));
}

extern const VlUnpacked<CData/*0:0*/, 512> Vriscv_top__ConstPool__TABLE_h017d0787_0;
extern const VlUnpacked<CData/*0:0*/, 512> Vriscv_top__ConstPool__TABLE_hd79a88a8_0;

VL_INLINE_OPT void Vriscv_top_dcache___sequent__TOP__v__u_dcache__0(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___sequent__TOP__v__u_dcache__0\n"); );
    // Init
    SData/*8:0*/ __Vtableidx1;
    CData/*0:0*/ __Vdly__u_uncached__DOT__u_req__DOT__wr_ptr_q;
    CData/*0:0*/ __Vdlyvdim0__u_uncached__DOT__u_req__DOT__ram_q__v0;
    VlWide<3>/*69:0*/ __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0;
    CData/*0:0*/ __Vdlyvset__u_uncached__DOT__u_req__DOT__ram_q__v0;
    CData/*1:0*/ __Vdly__u_uncached__DOT__u_req__DOT__count_q;
    CData/*0:0*/ __Vdly__u_uncached__DOT__u_req__DOT__rd_ptr_q;
    CData/*0:0*/ __Vdly__u_uncached__DOT__u_resp__DOT__wr_ptr_q;
    CData/*0:0*/ __Vdlyvdim0__u_uncached__DOT__u_resp__DOT__ram_q__v0;
    CData/*0:0*/ __Vdlyvset__u_uncached__DOT__u_resp__DOT__ram_q__v0;
    CData/*1:0*/ __Vdly__u_uncached__DOT__u_resp__DOT__count_q;
    CData/*0:0*/ __Vdly__u_uncached__DOT__u_resp__DOT__rd_ptr_q;
    CData/*7:0*/ __Vdly__u_axi__DOT__req_cnt_q;
    CData/*1:0*/ __Vdly__u_axi__DOT__resp_outstanding_q;
    CData/*0:0*/ __Vdly__u_axi__DOT__u_req__DOT__wr_ptr_q;
    CData/*0:0*/ __Vdlyvdim0__u_axi__DOT__u_req__DOT__ram_q__v0;
    VlWide<3>/*76:0*/ __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0;
    CData/*0:0*/ __Vdlyvset__u_axi__DOT__u_req__DOT__ram_q__v0;
    CData/*1:0*/ __Vdly__u_axi__DOT__u_req__DOT__count_q;
    CData/*0:0*/ __Vdly__u_axi__DOT__u_req__DOT__rd_ptr_q;
    CData/*7:0*/ __Vdly__u_axi__DOT__u_axi__DOT__req_cnt_q;
    // Body
    __Vdly__u_axi__DOT__req_cnt_q = vlSelf->__PVT__u_axi__DOT__req_cnt_q;
    __Vdly__u_uncached__DOT__u_resp__DOT__wr_ptr_q 
        = vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__wr_ptr_q;
    __Vdlyvset__u_uncached__DOT__u_resp__DOT__ram_q__v0 = 0U;
    __Vdly__u_uncached__DOT__u_req__DOT__rd_ptr_q = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q;
    __Vdly__u_axi__DOT__u_axi__DOT__req_cnt_q = vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q;
    __Vdly__u_axi__DOT__resp_outstanding_q = vlSelf->__PVT__u_axi__DOT__resp_outstanding_q;
    __Vdly__u_axi__DOT__u_req__DOT__wr_ptr_q = vlSelf->__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q;
    __Vdly__u_axi__DOT__u_req__DOT__rd_ptr_q = vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q;
    __Vdly__u_axi__DOT__u_req__DOT__count_q = vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q;
    __Vdlyvset__u_axi__DOT__u_req__DOT__ram_q__v0 = 0U;
    __Vdly__u_uncached__DOT__u_req__DOT__count_q = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q;
    __Vdly__u_uncached__DOT__u_resp__DOT__rd_ptr_q 
        = vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q;
    __Vdly__u_uncached__DOT__u_resp__DOT__count_q = vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q;
    __Vdly__u_uncached__DOT__u_req__DOT__wr_ptr_q = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__wr_ptr_q;
    __Vdlyvset__u_uncached__DOT__u_req__DOT__ram_q__v0 = 0U;
    if (vlSymsp->TOP.__Vcellinp__v__rst_i) {
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wlast_q = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[0U] = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] = 0U;
        __Vdly__u_axi__DOT__req_cnt_q = 0U;
        __Vdly__u_uncached__DOT__u_resp__DOT__wr_ptr_q = 0U;
        __Vdly__u_uncached__DOT__u_req__DOT__rd_ptr_q = 0U;
        __Vdly__u_axi__DOT__u_axi__DOT__req_cnt_q = 0U;
        __Vdly__u_axi__DOT__resp_outstanding_q = 0U;
        __Vdly__u_axi__DOT__u_req__DOT__rd_ptr_q = 0U;
        __Vdly__u_axi__DOT__u_req__DOT__count_q = 0U;
        __Vdly__u_axi__DOT__u_req__DOT__wr_ptr_q = 0U;
        __Vdly__u_uncached__DOT__u_req__DOT__count_q = 0U;
        vlSelf->__PVT__u_mux__DOT__pending_q = 0U;
        vlSelf->__PVT__u_uncached__DOT__request_pending_q = 0U;
        __Vdly__u_uncached__DOT__u_resp__DOT__rd_ptr_q = 0U;
        __Vdly__u_uncached__DOT__u_resp__DOT__count_q = 0U;
        __Vdly__u_uncached__DOT__u_req__DOT__wr_ptr_q = 0U;
        vlSelf->__PVT__u_mux__DOT__cache_access_q = 0U;
    } else {
        if (((IData)(vlSelf->__PVT__axi_wvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i))) {
            vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wlast_q 
                = vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w;
        }
        if ((((IData)(vlSelf->__PVT__axi_awvalid_o) 
              & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_awready_i)) 
             & ((~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_accepted_w)) 
                | (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_last_w))))) {
            vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q = 1U;
        } else if (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_accepted_w) 
                    & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_last_w))) {
            vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q = 0U;
        }
        if ((((IData)(vlSelf->__PVT__axi_wvalid_o) 
              & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i)) 
             & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_cmd_accepted_w)))) {
            vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q = 1U;
        } else if (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_cmd_accepted_w) {
            vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q = 0U;
        }
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[0U] 
            = (IData)((((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w)) 
                        << 0x2dU) | (((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_len_w)) 
                                      << 0x25U) | (
                                                   ((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_id_w)) 
                                                    << 0x21U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w)) 
                                                       << 1U) 
                                                      | (QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)))))));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
            = ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w 
                << 0xfU) | (IData)(((((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w)) 
                                      << 0x2dU) | (
                                                   ((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_len_w)) 
                                                    << 0x25U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_id_w)) 
                                                       << 0x21U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w)) 
                                                          << 1U) 
                                                         | (QData)((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)))))) 
                                    >> 0x20U)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
            = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w) 
                << 0x13U) | (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w) 
                              << 0xfU) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w 
                                          >> 0x11U)));
        if (((((IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w) 
               & (0U == (IData)(vlSelf->__PVT__u_axi__DOT__req_cnt_q))) 
              & (0U != (0xffU & (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                 >> 5U)))) & (IData)(vlSelf->__PVT__u_axi__DOT__accept_w))) {
            __Vdly__u_axi__DOT__req_cnt_q = (0xffU 
                                             & (((vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                  << 0x1bU) 
                                                 | (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                    >> 5U)) 
                                                - (IData)(1U)));
        } else if ((((0U != (IData)(vlSelf->__PVT__u_axi__DOT__req_cnt_q)) 
                     & (IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w)) 
                    & (IData)(vlSelf->__PVT__u_axi__DOT__accept_w))) {
            __Vdly__u_axi__DOT__req_cnt_q = (0xffU 
                                             & ((IData)(vlSelf->__PVT__u_axi__DOT__req_cnt_q) 
                                                - (IData)(1U)));
        }
        if (((IData)(vlSelf->__PVT__u_uncached__DOT__res_push_w) 
             & (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q)))) {
            __Vdlyvset__u_uncached__DOT__u_resp__DOT__ram_q__v0 = 1U;
            __Vdlyvdim0__u_uncached__DOT__u_resp__DOT__ram_q__v0 
                = vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__wr_ptr_q;
            __Vdly__u_uncached__DOT__u_resp__DOT__wr_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__wr_ptr_q)));
        }
        if (((IData)(vlSelf->__PVT__u_uncached__DOT__request_complete_w) 
             & (0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)))) {
            __Vdly__u_uncached__DOT__u_req__DOT__rd_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q)));
        }
        if ((((IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w) 
              & (IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w)) 
             & (IData)(vlSelf->__PVT__u_axi__DOT__accept_w))) {
            __Vdly__u_axi__DOT__u_axi__DOT__req_cnt_q 
                = (0xffU & ((0U != (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q))
                             ? ((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q) 
                                - (IData)(1U)) : ((
                                                   vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                   << 0x1bU) 
                                                  | (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                     >> 5U))));
        }
        if ((((IData)(vlSelf->__PVT__u_axi__DOT__res_push_w) 
              & (IData)(vlSelf->__PVT__u_axi__DOT__res_accept_w)) 
             & (~ ((IData)(vlSelf->__PVT__u_axi__DOT__resp_pop_w) 
                   & (IData)(vlSelf->__PVT__u_axi__DOT__res_valid_w))))) {
            __Vdly__u_axi__DOT__resp_outstanding_q 
                = (3U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q)));
        } else if (((~ ((IData)(vlSelf->__PVT__u_axi__DOT__res_push_w) 
                        & (IData)(vlSelf->__PVT__u_axi__DOT__res_accept_w))) 
                    & ((IData)(vlSelf->__PVT__u_axi__DOT__resp_pop_w) 
                       & (IData)(vlSelf->__PVT__u_axi__DOT__res_valid_w)))) {
            __Vdly__u_axi__DOT__resp_outstanding_q 
                = (3U & ((IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q) 
                         - (IData)(1U)));
        }
        if (((IData)(vlSelf->__PVT__u_axi__DOT__accept_w) 
             & (0U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)))) {
            __Vdly__u_axi__DOT__u_req__DOT__rd_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q)));
        }
        if ((((IData)(vlSelf->__PVT__u_axi__DOT__req_push_w) 
              & (IData)(vlSelf->__PVT__u_axi__DOT__req_accept_w)) 
             & (~ ((IData)(vlSelf->__PVT__u_axi__DOT__accept_w) 
                   & (IData)(vlSelf->__PVT__u_axi__DOT__req_valid_w))))) {
            __Vdly__u_axi__DOT__u_req__DOT__count_q 
                = (3U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)));
        } else if (((~ ((IData)(vlSelf->__PVT__u_axi__DOT__req_push_w) 
                        & (IData)(vlSelf->__PVT__u_axi__DOT__req_accept_w))) 
                    & ((IData)(vlSelf->__PVT__u_axi__DOT__accept_w) 
                       & (IData)(vlSelf->__PVT__u_axi__DOT__req_valid_w)))) {
            __Vdly__u_axi__DOT__u_req__DOT__count_q 
                = (3U & ((IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q) 
                         - (IData)(1U)));
        }
        if (((IData)(vlSelf->__PVT__u_axi__DOT__req_push_w) 
             & (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)))) {
            __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0[0U] 
                = (IData)((((QData)((IData)(((IData)(vlSelf->__PVT__pmem_select_w)
                                              ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                              : vlSelf->__PVT__u_uncached__DOT__req_w[1U]))) 
                            << 0x20U) | (QData)((IData)(
                                                        ((IData)(vlSelf->__PVT__pmem_select_w)
                                                          ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                                          : 
                                                         (0xfffffffcU 
                                                          & vlSelf->__PVT__u_uncached__DOT__req_w[0U]))))));
            __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0[1U] 
                = (IData)(((((QData)((IData)(((IData)(vlSelf->__PVT__pmem_select_w)
                                               ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                               : vlSelf->__PVT__u_uncached__DOT__req_w[1U]))) 
                             << 0x20U) | (QData)((IData)(
                                                         ((IData)(vlSelf->__PVT__pmem_select_w)
                                                           ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                                           : 
                                                          (0xfffffffcU 
                                                           & vlSelf->__PVT__u_uncached__DOT__req_w[0U]))))) 
                           >> 0x20U));
            __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0[2U] 
                = ((((IData)(vlSelf->__PVT__pmem_select_w)
                      ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w)
                      : 0U) << 5U) | (((IData)(vlSelf->__PVT__u_pmem_mux__DOT__outport_rd_r) 
                                       << 4U) | (IData)(vlSelf->__PVT__u_pmem_mux__DOT__outport_wr_r)));
            __Vdlyvset__u_axi__DOT__u_req__DOT__ram_q__v0 = 1U;
            __Vdlyvdim0__u_axi__DOT__u_req__DOT__ram_q__v0 
                = vlSelf->__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q;
            __Vdly__u_axi__DOT__u_req__DOT__wr_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q)));
        }
        if ((((IData)(vlSelf->__PVT__u_uncached__DOT__req_push_w) 
              & (IData)(vlSelf->__PVT__u_uncached__DOT__req_accept_w)) 
             & (~ ((IData)(vlSelf->__PVT__u_uncached__DOT__request_complete_w) 
                   & (IData)(vlSelf->__PVT__u_uncached__DOT__req_valid_w))))) {
            __Vdly__u_uncached__DOT__u_req__DOT__count_q 
                = (3U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)));
        } else if (((~ ((IData)(vlSelf->__PVT__u_uncached__DOT__req_push_w) 
                        & (IData)(vlSelf->__PVT__u_uncached__DOT__req_accept_w))) 
                    & ((IData)(vlSelf->__PVT__u_uncached__DOT__request_complete_w) 
                       & (IData)(vlSelf->__PVT__u_uncached__DOT__req_valid_w)))) {
            __Vdly__u_uncached__DOT__u_req__DOT__count_q 
                = (3U & ((IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q) 
                         - (IData)(1U)));
        }
        vlSelf->__PVT__u_mux__DOT__pending_q = vlSelf->__PVT__u_mux__DOT__pending_r;
        if (vlSelf->__PVT__u_uncached__DOT__request_complete_w) {
            vlSelf->__PVT__u_uncached__DOT__request_pending_q = 1U;
        } else if (vlSelf->__PVT__mem_uncached_ack_w) {
            vlSelf->__PVT__u_uncached__DOT__request_pending_q = 0U;
        }
        if (((IData)(vlSelf->__PVT__mem_uncached_ack_w) 
             & (0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q)))) {
            __Vdly__u_uncached__DOT__u_resp__DOT__rd_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q)));
        }
        if ((((IData)(vlSelf->__PVT__u_uncached__DOT__res_push_w) 
              & (IData)(vlSelf->__PVT__u_uncached__DOT__res_accept_w)) 
             & (~ ((IData)(vlSelf->__PVT__mem_uncached_ack_w) 
                   & (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__valid_o))))) {
            __Vdly__u_uncached__DOT__u_resp__DOT__count_q 
                = (3U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q)));
        } else if (((~ ((IData)(vlSelf->__PVT__u_uncached__DOT__res_push_w) 
                        & (IData)(vlSelf->__PVT__u_uncached__DOT__res_accept_w))) 
                    & ((IData)(vlSelf->__PVT__mem_uncached_ack_w) 
                       & (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__valid_o)))) {
            __Vdly__u_uncached__DOT__u_resp__DOT__count_q 
                = (3U & ((IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q) 
                         - (IData)(1U)));
        }
        if (((IData)(vlSelf->__PVT__u_uncached__DOT__req_push_w) 
             & (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)))) {
            __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0[0U] 
                = (IData)((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                            << 0x20U) | (QData)((IData)(
                                                        (0xfffffffcU 
                                                         & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))));
            __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0[1U] 
                = (IData)(((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                             << 0x20U) | (QData)((IData)(
                                                         (0xfffffffcU 
                                                          & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))) 
                           >> 0x20U));
            __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0[2U] 
                = (((IData)(vlSelf->__PVT__u_uncached__DOT__drop_req_w) 
                    << 5U) | (((IData)(vlSelf->__PVT__mem_uncached_rd_w) 
                               << 4U) | (IData)(vlSelf->__PVT__mem_uncached_wr_w)));
            __Vdlyvset__u_uncached__DOT__u_req__DOT__ram_q__v0 = 1U;
            __Vdlyvdim0__u_uncached__DOT__u_req__DOT__ram_q__v0 
                = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__wr_ptr_q;
            __Vdly__u_uncached__DOT__u_req__DOT__wr_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__wr_ptr_q)));
        }
        if (((IData)(vlSelf->__PVT__u_mux__DOT__request_w) 
             & (IData)(vlSelf->__PVT__mem_accept_o))) {
            vlSelf->__PVT__u_mux__DOT__cache_access_q 
                = vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q;
        }
    }
    __Vtableidx1 = (((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_arready_i) 
                     << 8U) | (((IData)(vlSelf->__PVT__axi_arvalid_o) 
                                << 7U) | (((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i) 
                                           << 6U) | 
                                          (((IData)(vlSelf->__PVT__axi_wvalid_o) 
                                            << 5U) 
                                           | (((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_awready_i) 
                                               << 4U) 
                                              | (((IData)(vlSelf->__PVT__axi_awvalid_o) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->__PVT__u_axi__DOT__accept_w) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w) 
                                                        << 1U) 
                                                       | (IData)(vlSymsp->TOP.__Vcellinp__v__rst_i)))))))));
    if (Vriscv_top__ConstPool__TABLE_h017d0787_0[__Vtableidx1]) {
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q 
            = Vriscv_top__ConstPool__TABLE_hd79a88a8_0
            [__Vtableidx1];
    }
    vlSelf->__PVT__u_uncached__DOT__dropped_q = ((~ (IData)(vlSymsp->TOP.__Vcellinp__v__rst_i)) 
                                                 & (IData)(vlSelf->__PVT__u_uncached__DOT__req_is_drop_w));
    vlSelf->__PVT__u_axi__DOT__req_cnt_q = __Vdly__u_axi__DOT__req_cnt_q;
    vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__wr_ptr_q 
        = __Vdly__u_uncached__DOT__u_resp__DOT__wr_ptr_q;
    if (__Vdlyvset__u_uncached__DOT__u_resp__DOT__ram_q__v0) {
        vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__ram_q[__Vdlyvdim0__u_uncached__DOT__u_resp__DOT__ram_q__v0] = 0U;
    }
    vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q 
        = __Vdly__u_uncached__DOT__u_req__DOT__rd_ptr_q;
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q 
        = __Vdly__u_axi__DOT__u_axi__DOT__req_cnt_q;
    vlSelf->__PVT__u_axi__DOT__resp_outstanding_q = __Vdly__u_axi__DOT__resp_outstanding_q;
    vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q 
        = __Vdly__u_axi__DOT__u_req__DOT__rd_ptr_q;
    vlSelf->__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q 
        = __Vdly__u_axi__DOT__u_req__DOT__wr_ptr_q;
    if (__Vdlyvset__u_axi__DOT__u_req__DOT__ram_q__v0) {
        vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q[__Vdlyvdim0__u_axi__DOT__u_req__DOT__ram_q__v0][0U] 
            = __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0[0U];
        vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q[__Vdlyvdim0__u_axi__DOT__u_req__DOT__ram_q__v0][1U] 
            = __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0[1U];
        vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q[__Vdlyvdim0__u_axi__DOT__u_req__DOT__ram_q__v0][2U] 
            = __Vdlyvval__u_axi__DOT__u_req__DOT__ram_q__v0[2U];
    }
    vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q 
        = __Vdly__u_axi__DOT__u_req__DOT__count_q;
    vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q 
        = __Vdly__u_uncached__DOT__u_resp__DOT__rd_ptr_q;
    vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q 
        = __Vdly__u_uncached__DOT__u_resp__DOT__count_q;
    vlSelf->__PVT__u_uncached__DOT__u_req__DOT__wr_ptr_q 
        = __Vdly__u_uncached__DOT__u_req__DOT__wr_ptr_q;
    if (__Vdlyvset__u_uncached__DOT__u_req__DOT__ram_q__v0) {
        vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q[__Vdlyvdim0__u_uncached__DOT__u_req__DOT__ram_q__v0][0U] 
            = __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0[0U];
        vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q[__Vdlyvdim0__u_uncached__DOT__u_req__DOT__ram_q__v0][1U] 
            = __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0[1U];
        vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q[__Vdlyvdim0__u_uncached__DOT__u_req__DOT__ram_q__v0][2U] 
            = __Vdlyvval__u_uncached__DOT__u_req__DOT__ram_q__v0[2U];
    }
    vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q 
        = __Vdly__u_uncached__DOT__u_req__DOT__count_q;
    vlSelf->__PVT__u_axi__DOT__res_valid_w = (0U != (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q));
    vlSelf->__PVT__u_axi__DOT__res_accept_w = (2U != (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q));
    vlSelf->__PVT__u_axi__DOT__req_w[0U] = vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q][0U];
    vlSelf->__PVT__u_axi__DOT__req_w[1U] = vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q][1U];
    vlSelf->__PVT__u_axi__DOT__req_w[2U] = vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q][2U];
    vlSelf->__PVT__u_axi__DOT__req_valid_w = (0U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_axi__DOT__req_accept_w = (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_axi__DOT__req_can_issue_w = ((0U 
                                                   != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)) 
                                                  & (2U 
                                                     != (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q)));
    vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__valid_o 
        = (0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__res_accept_w = 
        (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__req_w[0U] = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q][0U];
    vlSelf->__PVT__u_uncached__DOT__req_w[1U] = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q][1U];
    vlSelf->__PVT__u_uncached__DOT__req_w[2U] = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q][2U];
    vlSelf->__PVT__u_uncached__DOT__req_valid_w = (0U 
                                                   != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__req_accept_w = 
        (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w 
        = ((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q) 
           | (IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w));
    vlSelf->__PVT__u_axi__DOT__req_is_write_w = ((IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w) 
                                                 & (~ 
                                                    (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                     >> 4U)));
    if (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q) {
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_id_w 
            = (0xfU & (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                       >> 1U));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w 
            = (3U & (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                     >> 0xdU));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w 
            = ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                << 0x11U) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                             >> 0xfU));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w 
            = (0xfU & ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                        << 0x11U) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                                     >> 0xfU)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w 
            = ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                << 0x1fU) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[0U] 
                             >> 1U));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_len_w 
            = (0xffU & ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                         << 0x1bU) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                                      >> 5U)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w 
            = (1U & (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                     >> 0x13U));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w 
            = (1U & vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[0U]);
    } else {
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_id_w = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w = 1U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w 
            = vlSelf->__PVT__u_axi__DOT__req_w[1U];
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w 
            = (0xfU & vlSelf->__PVT__u_axi__DOT__req_w[2U]);
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w 
            = (0xfffffffcU & vlSelf->__PVT__u_axi__DOT__req_w[0U]);
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_len_w 
            = (0xffU & ((vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                         << 0x1bU) | (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                      >> 5U)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w 
            = (1U & ((IData)(((0U == (0x1fe0U & vlSelf->__PVT__u_axi__DOT__req_w[2U])) 
                              & (0U == (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q)))) 
                     | (1U == (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q))));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w 
            = (1U & (IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w));
    }
    vlSelf->__PVT__axi_arvalid_o = ((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w) 
                                    & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)));
    vlSelf->__PVT__axi_awvalid_o = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w) 
                                     & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)) 
                                    & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q)));
    vlSelf->__PVT__axi_wvalid_o = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w) 
                                    & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)) 
                                   & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q)));
}

VL_INLINE_OPT void Vriscv_top_dcache___sequent__TOP__v__u_dcache__1(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___sequent__TOP__v__u_dcache__1\n"); );
    // Body
    vlSelf->__PVT__u_mux__DOT__hold_w = ((0U != (IData)(vlSelf->__PVT__u_mux__DOT__pending_q)) 
                                         & ((IData)(vlSelf->__PVT__u_mux__DOT__cache_access_q) 
                                            != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)));
    vlSelf->__PVT__u_pmem_mux__DOT__select_q = ((~ (IData)(vlSymsp->TOP.__Vcellinp__v__rst_i)) 
                                                & (IData)(vlSelf->__PVT__pmem_select_w));
    vlSelf->__PVT__u_uncached__DOT__drop_req_w = ((
                                                   (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                                     & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                                    & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                                   | (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                                       & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                                      & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q))) 
                                                  | (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                                      & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                                     & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)));
    vlSelf->__PVT__mem_cached_invalidate_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                               & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                              & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
    vlSelf->__PVT__mem_cached_writeback_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                              & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                             & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q));
    vlSelf->__PVT__mem_cached_flush_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                          & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                         & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q));
    vlSelf->__PVT__pmem_select_w = ((0U != (IData)(vlSelf->__PVT__u_mux__DOT__pending_q))
                                     ? (IData)(vlSelf->__PVT__u_mux__DOT__cache_access_q)
                                     : (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
    vlSelf->__PVT__pmem_cache_accept_w = ((IData)(vlSelf->__PVT__pmem_select_w) 
                                          & (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)));
}

VL_INLINE_OPT void Vriscv_top_dcache___combo__TOP__v__u_dcache__1(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___combo__TOP__v__u_dcache__1\n"); );
    // Body
    vlSelf->__PVT__u_axi__DOT__resp_pop_w = ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bvalid_i) 
                                             | ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rvalid_i) 
                                                & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rlast_i)));
    vlSelf->__PVT__pmem_error_w = ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bvalid_i)
                                    ? (0U != (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bresp_i))
                                    : (0U != (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rresp_i)));
    vlSelf->__PVT__pmem_cache_ack_w = ((IData)(vlSelf->__PVT__u_pmem_mux__DOT__select_q) 
                                       & (IData)(vlSelf->__PVT__pmem_ack_w));
    vlSelf->__PVT__mem_uncached_ack_w = ((IData)(vlSelf->__PVT__u_uncached__DOT__dropped_q) 
                                         | ((~ (IData)(vlSelf->__PVT__u_pmem_mux__DOT__select_q)) 
                                            & (IData)(vlSelf->__PVT__pmem_ack_w)));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_cmd_accepted_w 
        = (((IData)(vlSelf->__PVT__axi_awvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_awready_i)) 
           | (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_accepted_w 
        = (((IData)(vlSelf->__PVT__axi_wvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i)) 
           | (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_last_w 
        = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q) 
            & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wlast_q)) 
           | (((IData)(vlSelf->__PVT__axi_wvalid_o) 
               & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i)) 
              & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w)));
    vlSelf->__PVT__u_axi__DOT__accept_w = ((~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q)) 
                                           & ((((IData)(vlSelf->__PVT__axi_awvalid_o) 
                                                & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_awready_i)) 
                                               | ((IData)(vlSelf->__PVT__axi_wvalid_o) 
                                                  & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i))) 
                                              | ((IData)(vlSelf->__PVT__axi_arvalid_o) 
                                                 & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_arready_i))));
    if (vlSelf->__PVT__u_mux__DOT__cache_access_q) {
        vlSelf->__PVT__mem_error_o = vlSymsp->TOP__v__u_dcache__u_core.__PVT__error_q;
        vlSelf->__PVT__mem_ack_o = vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_ack_r;
    } else {
        vlSelf->__PVT__mem_error_o = ((~ (IData)(vlSelf->__PVT__u_pmem_mux__DOT__select_q)) 
                                      & (IData)(vlSelf->__PVT__pmem_error_w));
        vlSelf->__PVT__mem_ack_o = vlSelf->__PVT__mem_uncached_ack_w;
    }
    vlSelf->__PVT__u_uncached__DOT__request_in_progress_w 
        = ((IData)(vlSelf->__PVT__u_uncached__DOT__request_pending_q) 
           & (~ (IData)(vlSelf->__PVT__mem_uncached_ack_w)));
    vlSelf->__PVT__u_axi__DOT__res_push_w = (((((IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w) 
                                                & (0U 
                                                   == 
                                                   (0x1fe0U 
                                                    & vlSelf->__PVT__u_axi__DOT__req_w[2U]))) 
                                               & (0U 
                                                  == (IData)(vlSelf->__PVT__u_axi__DOT__req_cnt_q))) 
                                              | ((IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w) 
                                                 & (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                    >> 4U))) 
                                             & (IData)(vlSelf->__PVT__u_axi__DOT__accept_w));
    vlSelf->__PVT__u_uncached__DOT__req_is_drop_w = 
        (((0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
          & (~ (IData)(vlSelf->__PVT__u_uncached__DOT__request_in_progress_w))) 
         & (vlSelf->__PVT__u_uncached__DOT__req_w[2U] 
            >> 5U));
    vlSelf->__PVT__u_uncached__DOT__req_is_read_w = 
        (((0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
          & (~ (IData)(vlSelf->__PVT__u_uncached__DOT__request_in_progress_w))) 
         & (vlSelf->__PVT__u_uncached__DOT__req_w[2U] 
            >> 4U));
    vlSelf->__PVT__pmem_uncached_wr_w = ((((0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                                           & (~ (IData)(vlSelf->__PVT__u_uncached__DOT__request_in_progress_w))) 
                                          & (~ (vlSelf->__PVT__u_uncached__DOT__req_w[2U] 
                                                >> 4U)))
                                          ? (0xfU & 
                                             vlSelf->__PVT__u_uncached__DOT__req_w[2U])
                                          : 0U);
    vlSelf->__PVT__u_uncached__DOT__request_complete_w 
        = ((IData)(vlSelf->__PVT__u_uncached__DOT__req_is_drop_w) 
           | (((IData)(vlSelf->__PVT__u_uncached__DOT__req_is_read_w) 
               | (0U != (IData)(vlSelf->__PVT__pmem_uncached_wr_w))) 
              & ((~ (IData)(vlSelf->__PVT__pmem_select_w)) 
                 & (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)))));
    vlSelf->__PVT__u_pmem_mux__DOT__outport_wr_r = 
        ((IData)(vlSelf->__PVT__pmem_select_w) ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr_w)
          : (IData)(vlSelf->__PVT__pmem_uncached_wr_w));
}

VL_INLINE_OPT void Vriscv_top_dcache___combo__TOP__v__u_dcache__2(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___combo__TOP__v__u_dcache__2\n"); );
    // Body
    vlSelf->__PVT__mem_uncached_wr_w = ((1U & ((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                               & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))))
                                         ? (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w)
                                         : 0U);
    vlSelf->__PVT__u_mux__DOT__request_w = (((((IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w) 
                                               | (0U 
                                                  != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                                              | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                            | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q));
    vlSelf->__PVT__mem_uncached_rd_w = (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                         & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                        & (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w));
    vlSelf->__PVT__mem_cached_rd_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                       & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                      & (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w));
    vlSelf->__PVT__u_uncached__DOT__request_w = (((IData)(vlSelf->__PVT__u_uncached__DOT__drop_req_w) 
                                                  | (IData)(vlSelf->__PVT__mem_uncached_rd_w)) 
                                                 | (0U 
                                                    != (IData)(vlSelf->__PVT__mem_uncached_wr_w)));
    vlSelf->__PVT__u_uncached__DOT__req_push_w = ((IData)(vlSelf->__PVT__u_uncached__DOT__request_w) 
                                                  & (2U 
                                                     != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q)));
    vlSelf->__PVT__u_uncached__DOT__res_push_w = ((IData)(vlSelf->__PVT__u_uncached__DOT__request_w) 
                                                  & (2U 
                                                     != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)));
}

VL_INLINE_OPT void Vriscv_top_dcache___combo__TOP__v__u_dcache__3(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___combo__TOP__v__u_dcache__3\n"); );
    // Body
    vlSelf->__PVT__mem_accept_o = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)
                                     ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_accept_r)
                                     : ((2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                                        & (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q)))) 
                                   & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w)));
    vlSelf->__PVT__u_mux__DOT__pending_r = vlSelf->__PVT__u_mux__DOT__pending_q;
    if ((((IData)(vlSelf->__PVT__u_mux__DOT__request_w) 
          & (IData)(vlSelf->__PVT__mem_accept_o)) & 
         (~ (IData)(vlSelf->__PVT__mem_ack_o)))) {
        vlSelf->__PVT__u_mux__DOT__pending_r = (0x1fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelf->__PVT__u_mux__DOT__pending_r)));
    } else if (((~ ((IData)(vlSelf->__PVT__u_mux__DOT__request_w) 
                    & (IData)(vlSelf->__PVT__mem_accept_o))) 
                & (IData)(vlSelf->__PVT__mem_ack_o))) {
        vlSelf->__PVT__u_mux__DOT__pending_r = (0x1fU 
                                                & ((IData)(vlSelf->__PVT__u_mux__DOT__pending_r) 
                                                   - (IData)(1U)));
    }
}

VL_INLINE_OPT void Vriscv_top_dcache___combo__TOP__v__u_dcache__4(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___combo__TOP__v__u_dcache__4\n"); );
    // Body
    vlSelf->__PVT__u_pmem_mux__DOT__outport_rd_r = 
        ((IData)(vlSelf->__PVT__pmem_select_w) ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_rd_w)
          : (IData)(vlSelf->__PVT__u_uncached__DOT__req_is_read_w));
    vlSelf->__PVT__u_axi__DOT__req_push_w = ((IData)(vlSelf->__PVT__u_pmem_mux__DOT__outport_rd_r) 
                                             | (0U 
                                                != (IData)(vlSelf->__PVT__u_pmem_mux__DOT__outport_wr_r)));
}
