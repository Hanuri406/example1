// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top_riscv_top.h"

VL_ATTR_COLD void Vriscv_top_riscv_top___ctor_var_reset(Vriscv_top_riscv_top* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_top_riscv_top___ctor_var_reset\n"); );
    // Body
    vlSelf->clk_i = VL_RAND_RESET_I(1);
    vlSelf->rst_i = VL_RAND_RESET_I(1);
    vlSelf->axi_i_awready_i = VL_RAND_RESET_I(1);
    vlSelf->axi_i_wready_i = VL_RAND_RESET_I(1);
    vlSelf->axi_i_bvalid_i = VL_RAND_RESET_I(1);
    vlSelf->axi_i_bresp_i = VL_RAND_RESET_I(2);
    vlSelf->axi_i_bid_i = VL_RAND_RESET_I(4);
    vlSelf->axi_i_arready_i = VL_RAND_RESET_I(1);
    vlSelf->axi_i_rvalid_i = VL_RAND_RESET_I(1);
    vlSelf->axi_i_rdata_i = VL_RAND_RESET_I(32);
    vlSelf->axi_i_rresp_i = VL_RAND_RESET_I(2);
    vlSelf->axi_i_rid_i = VL_RAND_RESET_I(4);
    vlSelf->axi_i_rlast_i = VL_RAND_RESET_I(1);
    vlSelf->axi_d_awready_i = VL_RAND_RESET_I(1);
    vlSelf->axi_d_wready_i = VL_RAND_RESET_I(1);
    vlSelf->axi_d_bvalid_i = VL_RAND_RESET_I(1);
    vlSelf->axi_d_bresp_i = VL_RAND_RESET_I(2);
    vlSelf->axi_d_bid_i = VL_RAND_RESET_I(4);
    vlSelf->axi_d_arready_i = VL_RAND_RESET_I(1);
    vlSelf->axi_d_rvalid_i = VL_RAND_RESET_I(1);
    vlSelf->axi_d_rdata_i = VL_RAND_RESET_I(32);
    vlSelf->axi_d_rresp_i = VL_RAND_RESET_I(2);
    vlSelf->axi_d_rid_i = VL_RAND_RESET_I(4);
    vlSelf->axi_d_rlast_i = VL_RAND_RESET_I(1);
    vlSelf->intr_i = VL_RAND_RESET_I(1);
    vlSelf->reset_vector_i = VL_RAND_RESET_I(32);
    vlSelf->__PVT__axi_i_awvalid_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__axi_i_awaddr_o = VL_RAND_RESET_I(32);
    vlSelf->__PVT__axi_i_awid_o = VL_RAND_RESET_I(4);
    vlSelf->__PVT__axi_i_awlen_o = VL_RAND_RESET_I(8);
    vlSelf->__PVT__axi_i_awburst_o = VL_RAND_RESET_I(2);
    vlSelf->__PVT__axi_i_wvalid_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__axi_i_wdata_o = VL_RAND_RESET_I(32);
    vlSelf->__PVT__axi_i_wstrb_o = VL_RAND_RESET_I(4);
    vlSelf->__PVT__axi_i_wlast_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__axi_i_bready_o = VL_RAND_RESET_I(1);
    vlSelf->axi_i_arvalid_o = VL_RAND_RESET_I(1);
    vlSelf->axi_i_araddr_o = VL_RAND_RESET_I(32);
    vlSelf->__PVT__axi_i_arid_o = VL_RAND_RESET_I(4);
    vlSelf->__PVT__axi_i_arlen_o = VL_RAND_RESET_I(8);
    vlSelf->__PVT__axi_i_arburst_o = VL_RAND_RESET_I(2);
    vlSelf->__PVT__axi_i_rready_o = VL_RAND_RESET_I(1);
    vlSelf->axi_d_awvalid_o = VL_RAND_RESET_I(1);
    vlSelf->axi_d_awaddr_o = VL_RAND_RESET_I(32);
    vlSelf->axi_d_awid_o = VL_RAND_RESET_I(4);
    vlSelf->axi_d_awlen_o = VL_RAND_RESET_I(8);
    vlSelf->axi_d_awburst_o = VL_RAND_RESET_I(2);
    vlSelf->axi_d_wvalid_o = VL_RAND_RESET_I(1);
    vlSelf->axi_d_wdata_o = VL_RAND_RESET_I(32);
    vlSelf->axi_d_wstrb_o = VL_RAND_RESET_I(4);
    vlSelf->axi_d_wlast_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__axi_d_bready_o = VL_RAND_RESET_I(1);
    vlSelf->axi_d_arvalid_o = VL_RAND_RESET_I(1);
    vlSelf->axi_d_araddr_o = VL_RAND_RESET_I(32);
    vlSelf->axi_d_arid_o = VL_RAND_RESET_I(4);
    vlSelf->axi_d_arlen_o = VL_RAND_RESET_I(8);
    vlSelf->axi_d_arburst_o = VL_RAND_RESET_I(2);
    vlSelf->__PVT__axi_d_rready_o = VL_RAND_RESET_I(1);
}
