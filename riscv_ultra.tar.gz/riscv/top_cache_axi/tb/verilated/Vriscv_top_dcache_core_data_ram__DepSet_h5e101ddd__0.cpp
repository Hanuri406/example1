// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_dcache_core_data_ram.h"

VL_INLINE_OPT void Vriscv_top_dcache_core_data_ram___sequent__TOP__v__u_dcache__u_core__u_data0__0(Vriscv_top_dcache_core_data_ram* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vriscv_top_dcache_core_data_ram___sequent__TOP__v__u_dcache__u_core__u_data0__0\n"); );
    // Init
    SData/*10:0*/ __Vdlyvdim0__ram__v0;
    CData/*4:0*/ __Vdlyvlsb__ram__v0;
    CData/*7:0*/ __Vdlyvval__ram__v0;
    CData/*0:0*/ __Vdlyvset__ram__v0;
    SData/*10:0*/ __Vdlyvdim0__ram__v1;
    CData/*4:0*/ __Vdlyvlsb__ram__v1;
    CData/*7:0*/ __Vdlyvval__ram__v1;
    CData/*0:0*/ __Vdlyvset__ram__v1;
    SData/*10:0*/ __Vdlyvdim0__ram__v2;
    CData/*4:0*/ __Vdlyvlsb__ram__v2;
    CData/*7:0*/ __Vdlyvval__ram__v2;
    CData/*0:0*/ __Vdlyvset__ram__v2;
    SData/*10:0*/ __Vdlyvdim0__ram__v3;
    CData/*4:0*/ __Vdlyvlsb__ram__v3;
    CData/*7:0*/ __Vdlyvval__ram__v3;
    CData/*0:0*/ __Vdlyvset__ram__v3;
    // Body
    __Vdlyvset__ram__v0 = 0U;
    __Vdlyvset__ram__v1 = 0U;
    __Vdlyvset__ram__v2 = 0U;
    __Vdlyvset__ram__v3 = 0U;
    vlSelf->__PVT__ram_read1_q = vlSelf->ram[vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r];
    vlSelf->__PVT__ram_read0_q = vlSelf->ram[vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_x_r];
    if ((1U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data0_write_m_r))) {
        __Vdlyvval__ram__v0 = (0xffU & ((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                         ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                         : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q));
        __Vdlyvset__ram__v0 = 1U;
        __Vdlyvlsb__ram__v0 = 0U;
        __Vdlyvdim0__ram__v0 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if ((2U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data0_write_m_r))) {
        __Vdlyvval__ram__v1 = (0xffU & (((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                          ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                          : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q) 
                                        >> 8U));
        __Vdlyvset__ram__v1 = 1U;
        __Vdlyvlsb__ram__v1 = 8U;
        __Vdlyvdim0__ram__v1 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if ((4U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data0_write_m_r))) {
        __Vdlyvval__ram__v2 = (0xffU & (((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                          ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                          : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q) 
                                        >> 0x10U));
        __Vdlyvset__ram__v2 = 1U;
        __Vdlyvlsb__ram__v2 = 0x10U;
        __Vdlyvdim0__ram__v2 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if ((8U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data0_write_m_r))) {
        __Vdlyvval__ram__v3 = (((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                 ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                 : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q) 
                               >> 0x18U);
        __Vdlyvset__ram__v3 = 1U;
        __Vdlyvlsb__ram__v3 = 0x18U;
        __Vdlyvdim0__ram__v3 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if (__Vdlyvset__ram__v0) {
        vlSelf->ram[__Vdlyvdim0__ram__v0] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v0))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v0]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v0) 
                                                   << (IData)(__Vdlyvlsb__ram__v0))));
    }
    if (__Vdlyvset__ram__v1) {
        vlSelf->ram[__Vdlyvdim0__ram__v1] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v1))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v1]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v1) 
                                                   << (IData)(__Vdlyvlsb__ram__v1))));
    }
    if (__Vdlyvset__ram__v2) {
        vlSelf->ram[__Vdlyvdim0__ram__v2] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v2))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v2]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v2) 
                                                   << (IData)(__Vdlyvlsb__ram__v2))));
    }
    if (__Vdlyvset__ram__v3) {
        vlSelf->ram[__Vdlyvdim0__ram__v3] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v3))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v3]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v3) 
                                                   << (IData)(__Vdlyvlsb__ram__v3))));
    }
}

VL_INLINE_OPT void Vriscv_top_dcache_core_data_ram___sequent__TOP__v__u_dcache__u_core__u_data1__0(Vriscv_top_dcache_core_data_ram* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vriscv_top_dcache_core_data_ram___sequent__TOP__v__u_dcache__u_core__u_data1__0\n"); );
    // Init
    SData/*10:0*/ __Vdlyvdim0__ram__v0;
    CData/*4:0*/ __Vdlyvlsb__ram__v0;
    CData/*7:0*/ __Vdlyvval__ram__v0;
    CData/*0:0*/ __Vdlyvset__ram__v0;
    SData/*10:0*/ __Vdlyvdim0__ram__v1;
    CData/*4:0*/ __Vdlyvlsb__ram__v1;
    CData/*7:0*/ __Vdlyvval__ram__v1;
    CData/*0:0*/ __Vdlyvset__ram__v1;
    SData/*10:0*/ __Vdlyvdim0__ram__v2;
    CData/*4:0*/ __Vdlyvlsb__ram__v2;
    CData/*7:0*/ __Vdlyvval__ram__v2;
    CData/*0:0*/ __Vdlyvset__ram__v2;
    SData/*10:0*/ __Vdlyvdim0__ram__v3;
    CData/*4:0*/ __Vdlyvlsb__ram__v3;
    CData/*7:0*/ __Vdlyvval__ram__v3;
    CData/*0:0*/ __Vdlyvset__ram__v3;
    // Body
    __Vdlyvset__ram__v0 = 0U;
    __Vdlyvset__ram__v1 = 0U;
    __Vdlyvset__ram__v2 = 0U;
    __Vdlyvset__ram__v3 = 0U;
    vlSelf->__PVT__ram_read1_q = vlSelf->ram[vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r];
    vlSelf->__PVT__ram_read0_q = vlSelf->ram[vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_x_r];
    if ((1U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data1_write_m_r))) {
        __Vdlyvval__ram__v0 = (0xffU & ((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                         ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                         : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q));
        __Vdlyvset__ram__v0 = 1U;
        __Vdlyvlsb__ram__v0 = 0U;
        __Vdlyvdim0__ram__v0 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if ((2U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data1_write_m_r))) {
        __Vdlyvval__ram__v1 = (0xffU & (((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                          ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                          : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q) 
                                        >> 8U));
        __Vdlyvset__ram__v1 = 1U;
        __Vdlyvlsb__ram__v1 = 8U;
        __Vdlyvdim0__ram__v1 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if ((4U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data1_write_m_r))) {
        __Vdlyvval__ram__v2 = (0xffU & (((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                          ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                          : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q) 
                                        >> 0x10U));
        __Vdlyvset__ram__v2 = 1U;
        __Vdlyvlsb__ram__v2 = 0x10U;
        __Vdlyvdim0__ram__v2 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if ((8U & (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data1_write_m_r))) {
        __Vdlyvval__ram__v3 = (((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                 ? vlSymsp->TOP.__Vcellinp__v__axi_d_rdata_i
                                 : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q) 
                               >> 0x18U);
        __Vdlyvset__ram__v3 = 1U;
        __Vdlyvlsb__ram__v3 = 0x18U;
        __Vdlyvdim0__ram__v3 = vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r;
    }
    if (__Vdlyvset__ram__v0) {
        vlSelf->ram[__Vdlyvdim0__ram__v0] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v0))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v0]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v0) 
                                                   << (IData)(__Vdlyvlsb__ram__v0))));
    }
    if (__Vdlyvset__ram__v1) {
        vlSelf->ram[__Vdlyvdim0__ram__v1] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v1))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v1]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v1) 
                                                   << (IData)(__Vdlyvlsb__ram__v1))));
    }
    if (__Vdlyvset__ram__v2) {
        vlSelf->ram[__Vdlyvdim0__ram__v2] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v2))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v2]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v2) 
                                                   << (IData)(__Vdlyvlsb__ram__v2))));
    }
    if (__Vdlyvset__ram__v3) {
        vlSelf->ram[__Vdlyvdim0__ram__v3] = (((~ ((IData)(0xffU) 
                                                  << (IData)(__Vdlyvlsb__ram__v3))) 
                                              & vlSelf->ram
                                              [__Vdlyvdim0__ram__v3]) 
                                             | (0xffffffffULL 
                                                & ((IData)(__Vdlyvval__ram__v3) 
                                                   << (IData)(__Vdlyvlsb__ram__v3))));
    }
}
