// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top_riscv_core__M0_MBffffffff.h"

VL_INLINE_OPT void Vriscv_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__2(Vriscv_top_riscv_core__M0_MBffffffff* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__2\n"); );
    // Body
    vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
        = (((IData)(vlSelf->__PVT__fetch_dec_fault_page_w) 
            | (IData)(vlSelf->__PVT__fetch_dec_fault_fetch_w))
            ? 0U : vlSelf->__PVT__fetch_dec_instr_w);
    vlSelf->__PVT__fetch_instr_exec_w = (((((((((((
                                                   ((((((((((0x7013U 
                                                             == 
                                                             (0x707fU 
                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                            | (0x13U 
                                                               == 
                                                               (0x707fU 
                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                           | (0x2013U 
                                                              == 
                                                              (0x707fU 
                                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                          | (0x3013U 
                                                             == 
                                                             (0x707fU 
                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                         | (0x6013U 
                                                            == 
                                                            (0x707fU 
                                                             & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                        | (0x4013U 
                                                           == 
                                                           (0x707fU 
                                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                       | (0x1013U 
                                                          == 
                                                          (0xfc00707fU 
                                                           & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                      | (0x5013U 
                                                         == 
                                                         (0xfc00707fU 
                                                          & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                     | (0x40005013U 
                                                        == 
                                                        (0xfc00707fU 
                                                         & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                    | (0x37U 
                                                       == 
                                                       (0x7fU 
                                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                   | (0x17U 
                                                      == 
                                                      (0x7fU 
                                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                  | (0x33U 
                                                     == 
                                                     (0xfe00707fU 
                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                 | (0x40000033U 
                                                    == 
                                                    (0xfe00707fU 
                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                | (0x2033U 
                                                   == 
                                                   (0xfe00707fU 
                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                               | (0x3033U 
                                                  == 
                                                  (0xfe00707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                              | (0x4033U 
                                                 == 
                                                 (0xfe00707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                             | (0x6033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                            | (0x7033U 
                                               == (0xfe00707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                           | (0x1033U 
                                              == (0xfe00707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                          | (0x5033U 
                                             == (0xfe00707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                         | (0x40005033U 
                                            == (0xfe00707fU 
                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
    vlSelf->__PVT__u_div__DOT__signed_operation_w = 
        ((0x2004033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
         | (0x2006033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
    vlSelf->__PVT__u_exec__DOT__branch_r = 0U;
    vlSelf->__PVT__u_lsu__DOT__load_inst_w = ((((((3U 
                                                   == 
                                                   (0x707fU 
                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                  | (0x1003U 
                                                     == 
                                                     (0x707fU 
                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                 | (0x2003U 
                                                    == 
                                                    (0x707fU 
                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                | (0x4003U 
                                                   == 
                                                   (0x707fU 
                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                               | (0x5003U 
                                                  == 
                                                  (0x707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                              | (0x6003U 
                                                 == 
                                                 (0x707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
    vlSelf->__PVT__u_exec__DOT__alu_func_r = 0U;
    if ((0x33U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 4U;
    } else if ((0x7033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 7U;
    } else if ((0x6033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 8U;
    } else if ((0x1033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 1U;
    } else if ((0x40005033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 3U;
    } else if ((0x5033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 2U;
    } else if ((0x40000033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 6U;
    } else if ((0x4033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 9U;
    } else if ((0x2033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 0xbU;
    } else if ((0x3033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 0xaU;
    } else if ((0x13U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 4U;
    } else if ((0x7013U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 7U;
    } else if ((0x2013U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 0xbU;
    } else if ((0x3013U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 0xaU;
    } else if ((0x6013U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 8U;
    } else if ((0x4013U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 9U;
    } else if ((0x1013U == (0xfc00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 1U;
    } else if ((0x5013U == (0xfc00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 2U;
    } else if ((0x40005013U == (0xfc00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__alu_func_r = 3U;
    } else if ((0x37U != (0x7fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        if ((0x17U == (0x7fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
            vlSelf->__PVT__u_exec__DOT__alu_func_r = 4U;
        } else if (((0x6fU == (0x7fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                    | (0x67U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            vlSelf->__PVT__u_exec__DOT__alu_func_r = 4U;
        }
    }
    vlSelf->__PVT__u_exec__DOT__imm12_r = (((- (IData)(
                                                       (vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                        >> 0x1fU))) 
                                            << 0xcU) 
                                           | (vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                              >> 0x14U));
    vlSelf->__PVT__fetch_instr_rd_valid_w = (((((((
                                                   ((((((((((((((((((((((((((((((((((((0x67U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                                                | (0x6fU 
                                                                                == 
                                                                                (0x7fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                                | (0x37U 
                                                                                == 
                                                                                (0x7fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                                | (0x17U 
                                                                                == 
                                                                                (0x7fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                                | (0x13U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                                | (0x1013U 
                                                                                == 
                                                                                (0xfc00707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                                | (0x2013U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                                | (0x3013U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                               | (0x4013U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                              | (0x5013U 
                                                                                == 
                                                                                (0xfc00707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                             | (0x40005013U 
                                                                                == 
                                                                                (0xfc00707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                            | (0x6013U 
                                                                               == 
                                                                               (0x707fU 
                                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                           | (0x7013U 
                                                                              == 
                                                                              (0x707fU 
                                                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                          | (0x33U 
                                                                             == 
                                                                             (0xfe00707fU 
                                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                         | (0x40000033U 
                                                                            == 
                                                                            (0xfe00707fU 
                                                                             & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                        | (0x1033U 
                                                                           == 
                                                                           (0xfe00707fU 
                                                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                       | (0x2033U 
                                                                          == 
                                                                          (0xfe00707fU 
                                                                           & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                      | (0x3033U 
                                                                         == 
                                                                         (0xfe00707fU 
                                                                          & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                     | (0x4033U 
                                                                        == 
                                                                        (0xfe00707fU 
                                                                         & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                    | (0x5033U 
                                                                       == 
                                                                       (0xfe00707fU 
                                                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                   | (0x40005033U 
                                                                      == 
                                                                      (0xfe00707fU 
                                                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                  | (0x6033U 
                                                                     == 
                                                                     (0xfe00707fU 
                                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                 | (0x7033U 
                                                                    == 
                                                                    (0xfe00707fU 
                                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                | (3U 
                                                                   == 
                                                                   (0x707fU 
                                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                               | (0x1003U 
                                                                  == 
                                                                  (0x707fU 
                                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                              | (0x2003U 
                                                                 == 
                                                                 (0x707fU 
                                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                             | (0x4003U 
                                                                == 
                                                                (0x707fU 
                                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                            | (0x5003U 
                                                               == 
                                                               (0x707fU 
                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                           | (0x6003U 
                                                              == 
                                                              (0x707fU 
                                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                          | (0x2000033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                         | (0x2001033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                        | (0x2002033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                       | (0x2003033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                      | (0x2004033U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                     | (0x2005033U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                    | (0x2006033U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                   | (0x2007033U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                  | (0x1073U 
                                                     == 
                                                     (0x707fU 
                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                 | (0x2073U 
                                                    == 
                                                    (0x707fU 
                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                | (0x3073U 
                                                   == 
                                                   (0x707fU 
                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                               | (0x5073U 
                                                  == 
                                                  (0x707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                              | (0x6073U 
                                                 == 
                                                 (0x707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                             | (0x7073U 
                                                == 
                                                (0x707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
    vlSelf->__PVT__fetch_instr_mul_w = ((((0x2000033U 
                                           == (0xfe00707fU 
                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                          | (0x2001033U 
                                             == (0xfe00707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                         | (0x2002033U 
                                            == (0xfe00707fU 
                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                        | (0x2003033U 
                                           == (0xfe00707fU 
                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
    vlSelf->__PVT__fetch_instr_div_w = ((((0x2004033U 
                                           == (0xfe00707fU 
                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                          | (0x2005033U 
                                             == (0xfe00707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                         | (0x2006033U 
                                            == (0xfe00707fU 
                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                        | (0x2007033U 
                                           == (0xfe00707fU 
                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
    vlSelf->__PVT__u_decode__DOT__genblk1__DOT__u_dec__DOT__invalid_w 
        = ((IData)(vlSelf->__PVT__fetch_dec_valid_w) 
           & (~ (((((((((((((((((((((((((((((((((((
                                                   ((((((((((((((((((((((((0x7013U 
                                                                           == 
                                                                           (0x707fU 
                                                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                                          | (0x13U 
                                                                             == 
                                                                             (0x707fU 
                                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                         | (0x2013U 
                                                                            == 
                                                                            (0x707fU 
                                                                             & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                        | (0x3013U 
                                                                           == 
                                                                           (0x707fU 
                                                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                       | (0x6013U 
                                                                          == 
                                                                          (0x707fU 
                                                                           & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                      | (0x4013U 
                                                                         == 
                                                                         (0x707fU 
                                                                          & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                     | (0x1013U 
                                                                        == 
                                                                        (0xfc00707fU 
                                                                         & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                    | (0x5013U 
                                                                       == 
                                                                       (0xfc00707fU 
                                                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                   | (0x40005013U 
                                                                      == 
                                                                      (0xfc00707fU 
                                                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                  | (0x37U 
                                                                     == 
                                                                     (0x7fU 
                                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                 | (0x17U 
                                                                    == 
                                                                    (0x7fU 
                                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                                | (0x33U 
                                                                   == 
                                                                   (0xfe00707fU 
                                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                               | (0x40000033U 
                                                                  == 
                                                                  (0xfe00707fU 
                                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                              | (0x2033U 
                                                                 == 
                                                                 (0xfe00707fU 
                                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                             | (0x3033U 
                                                                == 
                                                                (0xfe00707fU 
                                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                            | (0x4033U 
                                                               == 
                                                               (0xfe00707fU 
                                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                           | (0x6033U 
                                                              == 
                                                              (0xfe00707fU 
                                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                          | (0x7033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                         | (0x1033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                        | (0x5033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                       | (0x40005033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                      | (0x6fU 
                                                         == 
                                                         (0x7fU 
                                                          & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                     | (0x67U 
                                                        == 
                                                        (0x707fU 
                                                         & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                    | (0x63U 
                                                       == 
                                                       (0x707fU 
                                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                   | (0x1063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                  | (0x4063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                 | (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                | (0x6063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                               | (0x7063U 
                                                  == 
                                                  (0x707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                              | (3U 
                                                 == 
                                                 (0x707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                             | (0x1003U 
                                                == 
                                                (0x707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                            | (0x2003U 
                                               == (0x707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                           | (0x4003U 
                                              == (0x707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                          | (0x5003U 
                                             == (0x707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                         | (0x6003U 
                                            == (0x707fU 
                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                        | (0x23U == 
                                           (0x707fU 
                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                       | (0x1023U == 
                                          (0x707fU 
                                           & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                      | (0x2023U == 
                                         (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                     | (0x73U == vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                    | (0x100073U == vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                   | (0x200073U == 
                                      (0xcfffffffU 
                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x1073U == (0x707fU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x2073U == (0x707fU 
                                                & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x3073U == (0x707fU 
                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                               | (0x5073U == (0x707fU 
                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x6073U == (0x707fU 
                                             & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x7073U == (0x707fU 
                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                            | (0x10500073U == (0xffff8fffU 
                                               & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0xfU == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x100fU == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x12000073U == (0xfe007fffU 
                                            & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x2000033U == (0xfe00707fU 
                                          & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x2001033U == (0xfe00707fU 
                                         & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x2002033U == (0xfe00707fU 
                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x2003033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x2004033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                   | (0x2005033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                  | (0x2006033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                 | (0x2007033U == (0xfe00707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    vlSelf->__PVT__u_exec__DOT__branch_call_r = 0U;
    vlSelf->__PVT__u_exec__DOT__branch_ret_r = 0U;
    vlSelf->__PVT__u_exec__DOT__branch_jmp_r = 0U;
    if ((0x6fU == (0x7fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
        vlSelf->__PVT__u_exec__DOT__branch_call_r = 
            (1U == (0x1fU & (vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                             >> 7U)));
        vlSelf->__PVT__u_exec__DOT__branch_jmp_r = 1U;
    } else if ((0x67U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
        vlSelf->__PVT__u_exec__DOT__branch_ret_r = (IData)(
                                                           ((0x8000U 
                                                             == 
                                                             (0xf8000U 
                                                              & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                            & (0U 
                                                               == 
                                                               (0xfffU 
                                                                & vlSelf->__PVT__u_exec__DOT__imm12_r))));
        vlSelf->__PVT__u_exec__DOT__branch_call_r = 
            ((~ (IData)(vlSelf->__PVT__u_exec__DOT__branch_ret_r)) 
             & (0x80U == (0xf80U & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)));
        vlSelf->__PVT__u_exec__DOT__branch_jmp_r = 
            (1U & (~ ((IData)(vlSelf->__PVT__u_exec__DOT__branch_call_r) 
                      | (IData)(vlSelf->__PVT__u_exec__DOT__branch_ret_r))));
    } else if ((0x63U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
    } else if ((0x1063U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
    } else if ((0x4063U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
    } else if ((0x5063U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
    } else if ((0x6063U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
    } else if ((0x7063U == (0x707fU & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
        vlSelf->__PVT__u_exec__DOT__branch_r = 1U;
    }
    vlSelf->__PVT__fetch_instr_csr_w = ((((((((((((
                                                   (((0x73U 
                                                      == vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w) 
                                                     | (0x100073U 
                                                        == vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                    | (0x200073U 
                                                       == 
                                                       (0xcfffffffU 
                                                        & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                   | (0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                  | (0x2073U 
                                                     == 
                                                     (0x707fU 
                                                      & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                 | (0x3073U 
                                                    == 
                                                    (0x707fU 
                                                     & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                | (0x5073U 
                                                   == 
                                                   (0x707fU 
                                                    & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                               | (0x6073U 
                                                  == 
                                                  (0x707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                              | (0x7073U 
                                                 == 
                                                 (0x707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                             | (0x10500073U 
                                                == 
                                                (0xffff8fffU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                            | (0xfU 
                                               == (0x707fU 
                                                   & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                           | (0x100fU 
                                              == (0x707fU 
                                                  & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                          | (0x12000073U 
                                             == (0xfe007fffU 
                                                 & vlSelf->__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                         | (IData)(vlSelf->__PVT__u_decode__DOT__genblk1__DOT__u_dec__DOT__invalid_w)) 
                                        | ((IData)(vlSelf->__PVT__fetch_dec_fault_fetch_w) 
                                           | (IData)(vlSelf->__PVT__fetch_dec_fault_page_w)));
}
