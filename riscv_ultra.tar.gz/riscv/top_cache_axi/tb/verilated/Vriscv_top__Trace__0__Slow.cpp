// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "Vriscv_top__Syms.h"


VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+684,"CORE_ID", false,-1, 31,0);
    tracep->declBus(c+684,"MEM_CACHE_ADDR_MIN", false,-1, 31,0);
    tracep->declBus(c+685,"MEM_CACHE_ADDR_MAX", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+3,"axi_i_awready_i", false,-1);
    tracep->declBit(c+4,"axi_i_wready_i", false,-1);
    tracep->declBit(c+5,"axi_i_bvalid_i", false,-1);
    tracep->declBus(c+6,"axi_i_bresp_i", false,-1, 1,0);
    tracep->declBus(c+7,"axi_i_bid_i", false,-1, 3,0);
    tracep->declBit(c+8,"axi_i_arready_i", false,-1);
    tracep->declBit(c+9,"axi_i_rvalid_i", false,-1);
    tracep->declBus(c+10,"axi_i_rdata_i", false,-1, 31,0);
    tracep->declBus(c+11,"axi_i_rresp_i", false,-1, 1,0);
    tracep->declBus(c+12,"axi_i_rid_i", false,-1, 3,0);
    tracep->declBit(c+13,"axi_i_rlast_i", false,-1);
    tracep->declBit(c+14,"axi_d_awready_i", false,-1);
    tracep->declBit(c+15,"axi_d_wready_i", false,-1);
    tracep->declBit(c+16,"axi_d_bvalid_i", false,-1);
    tracep->declBus(c+17,"axi_d_bresp_i", false,-1, 1,0);
    tracep->declBus(c+18,"axi_d_bid_i", false,-1, 3,0);
    tracep->declBit(c+19,"axi_d_arready_i", false,-1);
    tracep->declBit(c+20,"axi_d_rvalid_i", false,-1);
    tracep->declBus(c+21,"axi_d_rdata_i", false,-1, 31,0);
    tracep->declBus(c+22,"axi_d_rresp_i", false,-1, 1,0);
    tracep->declBus(c+23,"axi_d_rid_i", false,-1, 3,0);
    tracep->declBit(c+24,"axi_d_rlast_i", false,-1);
    tracep->declBit(c+25,"intr_i", false,-1);
    tracep->declBus(c+26,"reset_vector_i", false,-1, 31,0);
    tracep->declBit(c+686,"axi_i_awvalid_o", false,-1);
    tracep->declBus(c+687,"axi_i_awaddr_o", false,-1, 31,0);
    tracep->declBus(c+688,"axi_i_awid_o", false,-1, 3,0);
    tracep->declBus(c+689,"axi_i_awlen_o", false,-1, 7,0);
    tracep->declBus(c+690,"axi_i_awburst_o", false,-1, 1,0);
    tracep->declBit(c+686,"axi_i_wvalid_o", false,-1);
    tracep->declBus(c+687,"axi_i_wdata_o", false,-1, 31,0);
    tracep->declBus(c+688,"axi_i_wstrb_o", false,-1, 3,0);
    tracep->declBit(c+686,"axi_i_wlast_o", false,-1);
    tracep->declBit(c+686,"axi_i_bready_o", false,-1);
    tracep->declBit(c+27,"axi_i_arvalid_o", false,-1);
    tracep->declBus(c+275,"axi_i_araddr_o", false,-1, 31,0);
    tracep->declBus(c+688,"axi_i_arid_o", false,-1, 3,0);
    tracep->declBus(c+691,"axi_i_arlen_o", false,-1, 7,0);
    tracep->declBus(c+692,"axi_i_arburst_o", false,-1, 1,0);
    tracep->declBit(c+693,"axi_i_rready_o", false,-1);
    tracep->declBit(c+276,"axi_d_awvalid_o", false,-1);
    tracep->declBus(c+277,"axi_d_awaddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"axi_d_awid_o", false,-1, 3,0);
    tracep->declBus(c+279,"axi_d_awlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"axi_d_awburst_o", false,-1, 1,0);
    tracep->declBit(c+281,"axi_d_wvalid_o", false,-1);
    tracep->declBus(c+282,"axi_d_wdata_o", false,-1, 31,0);
    tracep->declBus(c+283,"axi_d_wstrb_o", false,-1, 3,0);
    tracep->declBit(c+284,"axi_d_wlast_o", false,-1);
    tracep->declBit(c+693,"axi_d_bready_o", false,-1);
    tracep->declBit(c+285,"axi_d_arvalid_o", false,-1);
    tracep->declBus(c+277,"axi_d_araddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"axi_d_arid_o", false,-1, 3,0);
    tracep->declBus(c+279,"axi_d_arlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"axi_d_arburst_o", false,-1, 1,0);
    tracep->declBit(c+693,"axi_d_rready_o", false,-1);
    tracep->declBit(c+286,"icache_valid_w", false,-1);
    tracep->declBit(c+287,"icache_flush_w", false,-1);
    tracep->declBit(c+288,"dcache_flush_w", false,-1);
    tracep->declBit(c+289,"dcache_invalidate_w", false,-1);
    tracep->declBit(c+28,"dcache_ack_w", false,-1);
    tracep->declBus(c+290,"dcache_resp_tag_w", false,-1, 10,0);
    tracep->declBus(c+291,"icache_inst_w", false,-1, 31,0);
    tracep->declBus(c+684,"cpu_id_w", false,-1, 31,0);
    tracep->declBit(c+29,"dcache_rd_w", false,-1);
    tracep->declBus(c+292,"dcache_addr_w", false,-1, 31,0);
    tracep->declBit(c+30,"dcache_accept_w", false,-1);
    tracep->declBit(c+686,"icache_invalidate_w", false,-1);
    tracep->declBit(c+293,"dcache_writeback_w", false,-1);
    tracep->declBus(c+694,"dcache_req_tag_w", false,-1, 10,0);
    tracep->declBit(c+294,"dcache_cacheable_w", false,-1);
    tracep->declBit(c+295,"icache_error_w", false,-1);
    tracep->declBus(c+186,"dcache_data_rd_w", false,-1, 31,0);
    tracep->declBit(c+31,"icache_accept_w", false,-1);
    tracep->declBus(c+32,"dcache_wr_w", false,-1, 3,0);
    tracep->declBus(c+296,"icache_pc_w", false,-1, 31,0);
    tracep->declBit(c+33,"icache_rd_w", false,-1);
    tracep->declBit(c+34,"dcache_error_w", false,-1);
    tracep->declBus(c+297,"dcache_data_wr_w", false,-1, 31,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+684,"AXI_ID", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+292,"mem_addr_i", false,-1, 31,0);
    tracep->declBus(c+297,"mem_data_wr_i", false,-1, 31,0);
    tracep->declBit(c+29,"mem_rd_i", false,-1);
    tracep->declBus(c+32,"mem_wr_i", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cacheable_i", false,-1);
    tracep->declBus(c+694,"mem_req_tag_i", false,-1, 10,0);
    tracep->declBit(c+289,"mem_invalidate_i", false,-1);
    tracep->declBit(c+293,"mem_writeback_i", false,-1);
    tracep->declBit(c+288,"mem_flush_i", false,-1);
    tracep->declBit(c+14,"axi_awready_i", false,-1);
    tracep->declBit(c+15,"axi_wready_i", false,-1);
    tracep->declBit(c+16,"axi_bvalid_i", false,-1);
    tracep->declBus(c+17,"axi_bresp_i", false,-1, 1,0);
    tracep->declBus(c+18,"axi_bid_i", false,-1, 3,0);
    tracep->declBit(c+19,"axi_arready_i", false,-1);
    tracep->declBit(c+20,"axi_rvalid_i", false,-1);
    tracep->declBus(c+21,"axi_rdata_i", false,-1, 31,0);
    tracep->declBus(c+22,"axi_rresp_i", false,-1, 1,0);
    tracep->declBus(c+23,"axi_rid_i", false,-1, 3,0);
    tracep->declBit(c+24,"axi_rlast_i", false,-1);
    tracep->declBus(c+186,"mem_data_rd_o", false,-1, 31,0);
    tracep->declBit(c+30,"mem_accept_o", false,-1);
    tracep->declBit(c+28,"mem_ack_o", false,-1);
    tracep->declBit(c+34,"mem_error_o", false,-1);
    tracep->declBus(c+290,"mem_resp_tag_o", false,-1, 10,0);
    tracep->declBit(c+276,"axi_awvalid_o", false,-1);
    tracep->declBus(c+277,"axi_awaddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"axi_awid_o", false,-1, 3,0);
    tracep->declBus(c+279,"axi_awlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"axi_awburst_o", false,-1, 1,0);
    tracep->declBit(c+281,"axi_wvalid_o", false,-1);
    tracep->declBus(c+282,"axi_wdata_o", false,-1, 31,0);
    tracep->declBus(c+283,"axi_wstrb_o", false,-1, 3,0);
    tracep->declBit(c+284,"axi_wlast_o", false,-1);
    tracep->declBit(c+693,"axi_bready_o", false,-1);
    tracep->declBit(c+285,"axi_arvalid_o", false,-1);
    tracep->declBus(c+277,"axi_araddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"axi_arid_o", false,-1, 3,0);
    tracep->declBus(c+279,"axi_arlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"axi_arburst_o", false,-1, 1,0);
    tracep->declBit(c+693,"axi_rready_o", false,-1);
    tracep->declBit(c+298,"mem_uncached_invalidate_w", false,-1);
    tracep->declBit(c+299,"pmem_cache_accept_w", false,-1);
    tracep->declBit(c+300,"mem_uncached_accept_w", false,-1);
    tracep->declBus(c+35,"pmem_cache_len_w", false,-1, 7,0);
    tracep->declBus(c+187,"mem_cached_wr_w", false,-1, 3,0);
    tracep->declBus(c+21,"pmem_cache_read_data_w", false,-1, 31,0);
    tracep->declBit(c+301,"mem_cached_invalidate_w", false,-1);
    tracep->declBit(c+188,"pmem_uncached_ack_w", false,-1);
    tracep->declBus(c+189,"pmem_len_w", false,-1, 7,0);
    tracep->declBit(c+302,"pmem_uncached_accept_w", false,-1);
    tracep->declBit(c+36,"mem_cached_accept_w", false,-1);
    tracep->declBit(c+37,"pmem_cache_ack_w", false,-1);
    tracep->declBus(c+38,"pmem_cache_addr_w", false,-1, 31,0);
    tracep->declBit(c+39,"pmem_cache_rd_w", false,-1);
    tracep->declBit(c+40,"pmem_error_w", false,-1);
    tracep->declBus(c+190,"pmem_addr_w", false,-1, 31,0);
    tracep->declBus(c+694,"mem_cached_req_tag_w", false,-1, 10,0);
    tracep->declBit(c+41,"mem_uncached_ack_w", false,-1);
    tracep->declBit(c+42,"pmem_ack_w", false,-1);
    tracep->declBus(c+297,"mem_uncached_data_wr_w", false,-1, 31,0);
    tracep->declBus(c+303,"pmem_uncached_addr_w", false,-1, 31,0);
    tracep->declBus(c+304,"mem_cached_data_rd_w", false,-1, 31,0);
    tracep->declBus(c+21,"pmem_uncached_read_data_w", false,-1, 31,0);
    tracep->declBit(c+305,"mem_uncached_flush_w", false,-1);
    tracep->declBit(c+191,"pmem_uncached_error_w", false,-1);
    tracep->declBus(c+21,"mem_uncached_data_rd_w", false,-1, 31,0);
    tracep->declBus(c+306,"pmem_write_data_w", false,-1, 31,0);
    tracep->declBus(c+43,"pmem_uncached_wr_w", false,-1, 3,0);
    tracep->declBit(c+44,"mem_cached_rd_w", false,-1);
    tracep->declBus(c+307,"mem_cached_resp_tag_w", false,-1, 10,0);
    tracep->declBus(c+689,"pmem_uncached_len_w", false,-1, 7,0);
    tracep->declBus(c+297,"mem_cached_data_wr_w", false,-1, 31,0);
    tracep->declBus(c+45,"pmem_wr_w", false,-1, 3,0);
    tracep->declBit(c+308,"pmem_select_w", false,-1);
    tracep->declBit(c+309,"mem_cached_flush_w", false,-1);
    tracep->declBit(c+294,"mem_uncached_cacheable_w", false,-1);
    tracep->declBus(c+292,"mem_cached_addr_w", false,-1, 31,0);
    tracep->declBit(c+310,"mem_uncached_writeback_w", false,-1);
    tracep->declBus(c+311,"pmem_cache_wr_w", false,-1, 3,0);
    tracep->declBit(c+192,"pmem_cache_error_w", false,-1);
    tracep->declBus(c+694,"mem_uncached_req_tag_w", false,-1, 10,0);
    tracep->declBus(c+312,"pmem_uncached_write_data_w", false,-1, 31,0);
    tracep->declBus(c+313,"mem_uncached_resp_tag_w", false,-1, 10,0);
    tracep->declBit(c+46,"pmem_rd_w", false,-1);
    tracep->declBit(c+294,"mem_cached_cacheable_w", false,-1);
    tracep->declBus(c+47,"mem_uncached_wr_w", false,-1, 3,0);
    tracep->declBit(c+191,"mem_uncached_error_w", false,-1);
    tracep->declBit(c+48,"mem_uncached_rd_w", false,-1);
    tracep->declBit(c+314,"pmem_accept_w", false,-1);
    tracep->declBus(c+315,"pmem_cache_write_data_w", false,-1, 31,0);
    tracep->declBit(c+316,"mem_cached_error_w", false,-1);
    tracep->declBus(c+292,"mem_uncached_addr_w", false,-1, 31,0);
    tracep->declBit(c+49,"pmem_uncached_rd_w", false,-1);
    tracep->declBus(c+21,"pmem_read_data_w", false,-1, 31,0);
    tracep->declBit(c+317,"mem_cached_ack_w", false,-1);
    tracep->declBit(c+318,"mem_cached_writeback_w", false,-1);
    tracep->pushNamePrefix("u_axi ");
    tracep->declBus(c+684,"AXI_ID", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+14,"outport_awready_i", false,-1);
    tracep->declBit(c+15,"outport_wready_i", false,-1);
    tracep->declBit(c+16,"outport_bvalid_i", false,-1);
    tracep->declBus(c+17,"outport_bresp_i", false,-1, 1,0);
    tracep->declBus(c+18,"outport_bid_i", false,-1, 3,0);
    tracep->declBit(c+19,"outport_arready_i", false,-1);
    tracep->declBit(c+20,"outport_rvalid_i", false,-1);
    tracep->declBus(c+21,"outport_rdata_i", false,-1, 31,0);
    tracep->declBus(c+22,"outport_rresp_i", false,-1, 1,0);
    tracep->declBus(c+23,"outport_rid_i", false,-1, 3,0);
    tracep->declBit(c+24,"outport_rlast_i", false,-1);
    tracep->declBus(c+45,"inport_wr_i", false,-1, 3,0);
    tracep->declBit(c+46,"inport_rd_i", false,-1);
    tracep->declBus(c+189,"inport_len_i", false,-1, 7,0);
    tracep->declBus(c+190,"inport_addr_i", false,-1, 31,0);
    tracep->declBus(c+306,"inport_write_data_i", false,-1, 31,0);
    tracep->declBit(c+276,"outport_awvalid_o", false,-1);
    tracep->declBus(c+277,"outport_awaddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"outport_awid_o", false,-1, 3,0);
    tracep->declBus(c+279,"outport_awlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"outport_awburst_o", false,-1, 1,0);
    tracep->declBit(c+281,"outport_wvalid_o", false,-1);
    tracep->declBus(c+282,"outport_wdata_o", false,-1, 31,0);
    tracep->declBus(c+283,"outport_wstrb_o", false,-1, 3,0);
    tracep->declBit(c+284,"outport_wlast_o", false,-1);
    tracep->declBit(c+693,"outport_bready_o", false,-1);
    tracep->declBit(c+285,"outport_arvalid_o", false,-1);
    tracep->declBus(c+277,"outport_araddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"outport_arid_o", false,-1, 3,0);
    tracep->declBus(c+279,"outport_arlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"outport_arburst_o", false,-1, 1,0);
    tracep->declBit(c+693,"outport_rready_o", false,-1);
    tracep->declBit(c+314,"inport_accept_o", false,-1);
    tracep->declBit(c+42,"inport_ack_o", false,-1);
    tracep->declBit(c+40,"inport_error_o", false,-1);
    tracep->declBus(c+21,"inport_read_data_o", false,-1, 31,0);
    tracep->declBit(c+16,"bvalid_w", false,-1);
    tracep->declBit(c+20,"rvalid_w", false,-1);
    tracep->declBus(c+17,"bresp_w", false,-1, 1,0);
    tracep->declBus(c+22,"rresp_w", false,-1, 1,0);
    tracep->declBit(c+50,"accept_w", false,-1);
    tracep->declBit(c+319,"res_accept_w", false,-1);
    tracep->declBit(c+314,"req_accept_w", false,-1);
    tracep->declBit(c+320,"res_valid_w", false,-1);
    tracep->declBit(c+321,"req_valid_w", false,-1);
    tracep->declArray(c+322,"req_w", false,-1, 76,0);
    tracep->declBit(c+51,"req_push_w", false,-1);
    tracep->declArray(c+193,"req_data_in_w", false,-1, 76,0);
    tracep->declBit(c+325,"req_can_issue_w", false,-1);
    tracep->declBit(c+326,"req_is_read_w", false,-1);
    tracep->declBit(c+327,"req_is_write_w", false,-1);
    tracep->declBus(c+328,"req_len_w", false,-1, 7,0);
    tracep->declBus(c+329,"req_cnt_q", false,-1, 7,0);
    tracep->declBit(c+330,"req_last_w", false,-1);
    tracep->declBit(c+52,"res_push_w", false,-1);
    tracep->declBit(c+53,"resp_pop_w", false,-1);
    tracep->declBus(c+331,"resp_outstanding_q", false,-1, 1,0);
    tracep->pushNamePrefix("u_axi ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+325,"inport_valid_i", false,-1);
    tracep->declBit(c+327,"inport_write_i", false,-1);
    tracep->declBus(c+332,"inport_addr_i", false,-1, 31,0);
    tracep->declBus(c+688,"inport_id_i", false,-1, 3,0);
    tracep->declBus(c+328,"inport_len_i", false,-1, 7,0);
    tracep->declBus(c+692,"inport_burst_i", false,-1, 1,0);
    tracep->declBus(c+333,"inport_wdata_i", false,-1, 31,0);
    tracep->declBus(c+334,"inport_wstrb_i", false,-1, 3,0);
    tracep->declBit(c+693,"inport_bready_i", false,-1);
    tracep->declBit(c+693,"inport_rready_i", false,-1);
    tracep->declBit(c+14,"outport_awready_i", false,-1);
    tracep->declBit(c+15,"outport_wready_i", false,-1);
    tracep->declBit(c+16,"outport_bvalid_i", false,-1);
    tracep->declBus(c+17,"outport_bresp_i", false,-1, 1,0);
    tracep->declBus(c+18,"outport_bid_i", false,-1, 3,0);
    tracep->declBit(c+19,"outport_arready_i", false,-1);
    tracep->declBit(c+20,"outport_rvalid_i", false,-1);
    tracep->declBus(c+21,"outport_rdata_i", false,-1, 31,0);
    tracep->declBus(c+22,"outport_rresp_i", false,-1, 1,0);
    tracep->declBus(c+23,"outport_rid_i", false,-1, 3,0);
    tracep->declBit(c+24,"outport_rlast_i", false,-1);
    tracep->declBit(c+50,"inport_accept_o", false,-1);
    tracep->declBit(c+16,"inport_bvalid_o", false,-1);
    tracep->declBus(c+17,"inport_bresp_o", false,-1, 1,0);
    tracep->declBus(c+18,"inport_bid_o", false,-1, 3,0);
    tracep->declBit(c+20,"inport_rvalid_o", false,-1);
    tracep->declBus(c+21,"inport_rdata_o", false,-1, 31,0);
    tracep->declBus(c+22,"inport_rresp_o", false,-1, 1,0);
    tracep->declBus(c+23,"inport_rid_o", false,-1, 3,0);
    tracep->declBit(c+24,"inport_rlast_o", false,-1);
    tracep->declBit(c+276,"outport_awvalid_o", false,-1);
    tracep->declBus(c+277,"outport_awaddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"outport_awid_o", false,-1, 3,0);
    tracep->declBus(c+279,"outport_awlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"outport_awburst_o", false,-1, 1,0);
    tracep->declBit(c+281,"outport_wvalid_o", false,-1);
    tracep->declBus(c+282,"outport_wdata_o", false,-1, 31,0);
    tracep->declBus(c+283,"outport_wstrb_o", false,-1, 3,0);
    tracep->declBit(c+284,"outport_wlast_o", false,-1);
    tracep->declBit(c+693,"outport_bready_o", false,-1);
    tracep->declBit(c+285,"outport_arvalid_o", false,-1);
    tracep->declBus(c+277,"outport_araddr_o", false,-1, 31,0);
    tracep->declBus(c+278,"outport_arid_o", false,-1, 3,0);
    tracep->declBus(c+279,"outport_arlen_o", false,-1, 7,0);
    tracep->declBus(c+280,"outport_arburst_o", false,-1, 1,0);
    tracep->declBit(c+693,"outport_rready_o", false,-1);
    tracep->declBus(c+335,"req_cnt_q", false,-1, 7,0);
    tracep->declBit(c+336,"valid_q", false,-1);
    tracep->declArray(c+337,"buf_q", false,-1, 83,0);
    tracep->declBit(c+340,"inport_valid_w", false,-1);
    tracep->declBit(c+341,"inport_write_w", false,-1);
    tracep->declBus(c+277,"inport_addr_w", false,-1, 31,0);
    tracep->declBus(c+278,"inport_id_w", false,-1, 3,0);
    tracep->declBus(c+279,"inport_len_w", false,-1, 7,0);
    tracep->declBus(c+280,"inport_burst_w", false,-1, 1,0);
    tracep->declBus(c+282,"inport_wdata_w", false,-1, 31,0);
    tracep->declBus(c+283,"inport_wstrb_w", false,-1, 3,0);
    tracep->declBit(c+284,"inport_wlast_w", false,-1);
    tracep->declBit(c+336,"skid_busy_w", false,-1);
    tracep->declBit(c+342,"awvalid_q", false,-1);
    tracep->declBit(c+343,"wvalid_q", false,-1);
    tracep->declBit(c+344,"wlast_q", false,-1);
    tracep->declBit(c+54,"wr_cmd_accepted_w", false,-1);
    tracep->declBit(c+55,"wr_data_accepted_w", false,-1);
    tracep->declBit(c+56,"wr_data_last_w", false,-1);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_req ");
    tracep->declBus(c+695,"WIDTH", false,-1, 31,0);
    tracep->declBus(c+696,"DEPTH", false,-1, 31,0);
    tracep->declBus(c+697,"ADDR_W", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declArray(c+193,"data_in_i", false,-1, 76,0);
    tracep->declBit(c+51,"push_i", false,-1);
    tracep->declBit(c+50,"pop_i", false,-1);
    tracep->declArray(c+322,"data_out_o", false,-1, 76,0);
    tracep->declBit(c+314,"accept_o", false,-1);
    tracep->declBit(c+321,"valid_o", false,-1);
    tracep->declBus(c+696,"COUNT_W", false,-1, 31,0);
    for (int i = 0; i < 2; ++i) {
        tracep->declArray(c+345+i*3,"ram_q", true,(i+0), 76,0);
    }
    tracep->declBus(c+351,"rd_ptr_q", false,-1, 0,0);
    tracep->declBus(c+352,"wr_ptr_q", false,-1, 0,0);
    tracep->declBus(c+353,"count_q", false,-1, 1,0);
    tracep->popNamePrefix(2);
    tracep->pushNamePrefix("u_mux ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+292,"mem_addr_i", false,-1, 31,0);
    tracep->declBus(c+297,"mem_data_wr_i", false,-1, 31,0);
    tracep->declBit(c+29,"mem_rd_i", false,-1);
    tracep->declBus(c+32,"mem_wr_i", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cacheable_i", false,-1);
    tracep->declBus(c+694,"mem_req_tag_i", false,-1, 10,0);
    tracep->declBit(c+289,"mem_invalidate_i", false,-1);
    tracep->declBit(c+293,"mem_writeback_i", false,-1);
    tracep->declBit(c+288,"mem_flush_i", false,-1);
    tracep->declBus(c+304,"mem_cached_data_rd_i", false,-1, 31,0);
    tracep->declBit(c+36,"mem_cached_accept_i", false,-1);
    tracep->declBit(c+317,"mem_cached_ack_i", false,-1);
    tracep->declBit(c+316,"mem_cached_error_i", false,-1);
    tracep->declBus(c+307,"mem_cached_resp_tag_i", false,-1, 10,0);
    tracep->declBus(c+21,"mem_uncached_data_rd_i", false,-1, 31,0);
    tracep->declBit(c+300,"mem_uncached_accept_i", false,-1);
    tracep->declBit(c+41,"mem_uncached_ack_i", false,-1);
    tracep->declBit(c+191,"mem_uncached_error_i", false,-1);
    tracep->declBus(c+313,"mem_uncached_resp_tag_i", false,-1, 10,0);
    tracep->declBus(c+186,"mem_data_rd_o", false,-1, 31,0);
    tracep->declBit(c+30,"mem_accept_o", false,-1);
    tracep->declBit(c+28,"mem_ack_o", false,-1);
    tracep->declBit(c+34,"mem_error_o", false,-1);
    tracep->declBus(c+290,"mem_resp_tag_o", false,-1, 10,0);
    tracep->declBus(c+292,"mem_cached_addr_o", false,-1, 31,0);
    tracep->declBus(c+297,"mem_cached_data_wr_o", false,-1, 31,0);
    tracep->declBit(c+44,"mem_cached_rd_o", false,-1);
    tracep->declBus(c+187,"mem_cached_wr_o", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cached_cacheable_o", false,-1);
    tracep->declBus(c+694,"mem_cached_req_tag_o", false,-1, 10,0);
    tracep->declBit(c+301,"mem_cached_invalidate_o", false,-1);
    tracep->declBit(c+318,"mem_cached_writeback_o", false,-1);
    tracep->declBit(c+309,"mem_cached_flush_o", false,-1);
    tracep->declBus(c+292,"mem_uncached_addr_o", false,-1, 31,0);
    tracep->declBus(c+297,"mem_uncached_data_wr_o", false,-1, 31,0);
    tracep->declBit(c+48,"mem_uncached_rd_o", false,-1);
    tracep->declBus(c+47,"mem_uncached_wr_o", false,-1, 3,0);
    tracep->declBit(c+294,"mem_uncached_cacheable_o", false,-1);
    tracep->declBus(c+694,"mem_uncached_req_tag_o", false,-1, 10,0);
    tracep->declBit(c+298,"mem_uncached_invalidate_o", false,-1);
    tracep->declBit(c+310,"mem_uncached_writeback_o", false,-1);
    tracep->declBit(c+305,"mem_uncached_flush_o", false,-1);
    tracep->declBit(c+308,"cache_active_o", false,-1);
    tracep->declBit(c+354,"hold_w", false,-1);
    tracep->declBit(c+355,"cache_access_q", false,-1);
    tracep->declBit(c+57,"request_w", false,-1);
    tracep->declBus(c+58,"pending_r", false,-1, 4,0);
    tracep->declBus(c+356,"pending_q", false,-1, 4,0);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_pmem_mux ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+314,"outport_accept_i", false,-1);
    tracep->declBit(c+42,"outport_ack_i", false,-1);
    tracep->declBit(c+40,"outport_error_i", false,-1);
    tracep->declBus(c+21,"outport_read_data_i", false,-1, 31,0);
    tracep->declBit(c+308,"select_i", false,-1);
    tracep->declBus(c+43,"inport0_wr_i", false,-1, 3,0);
    tracep->declBit(c+49,"inport0_rd_i", false,-1);
    tracep->declBus(c+689,"inport0_len_i", false,-1, 7,0);
    tracep->declBus(c+303,"inport0_addr_i", false,-1, 31,0);
    tracep->declBus(c+312,"inport0_write_data_i", false,-1, 31,0);
    tracep->declBus(c+311,"inport1_wr_i", false,-1, 3,0);
    tracep->declBit(c+39,"inport1_rd_i", false,-1);
    tracep->declBus(c+35,"inport1_len_i", false,-1, 7,0);
    tracep->declBus(c+38,"inport1_addr_i", false,-1, 31,0);
    tracep->declBus(c+315,"inport1_write_data_i", false,-1, 31,0);
    tracep->declBus(c+45,"outport_wr_o", false,-1, 3,0);
    tracep->declBit(c+46,"outport_rd_o", false,-1);
    tracep->declBus(c+189,"outport_len_o", false,-1, 7,0);
    tracep->declBus(c+190,"outport_addr_o", false,-1, 31,0);
    tracep->declBus(c+306,"outport_write_data_o", false,-1, 31,0);
    tracep->declBit(c+302,"inport0_accept_o", false,-1);
    tracep->declBit(c+188,"inport0_ack_o", false,-1);
    tracep->declBit(c+191,"inport0_error_o", false,-1);
    tracep->declBus(c+21,"inport0_read_data_o", false,-1, 31,0);
    tracep->declBit(c+299,"inport1_accept_o", false,-1);
    tracep->declBit(c+37,"inport1_ack_o", false,-1);
    tracep->declBit(c+192,"inport1_error_o", false,-1);
    tracep->declBus(c+21,"inport1_read_data_o", false,-1, 31,0);
    tracep->declBus(c+45,"outport_wr_r", false,-1, 3,0);
    tracep->declBit(c+46,"outport_rd_r", false,-1);
    tracep->declBus(c+189,"outport_len_r", false,-1, 7,0);
    tracep->declBus(c+190,"outport_addr_r", false,-1, 31,0);
    tracep->declBus(c+306,"outport_write_data_r", false,-1, 31,0);
    tracep->declBit(c+357,"select_q", false,-1);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_uncached ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+292,"mem_addr_i", false,-1, 31,0);
    tracep->declBus(c+297,"mem_data_wr_i", false,-1, 31,0);
    tracep->declBit(c+48,"mem_rd_i", false,-1);
    tracep->declBus(c+47,"mem_wr_i", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cacheable_i", false,-1);
    tracep->declBus(c+694,"mem_req_tag_i", false,-1, 10,0);
    tracep->declBit(c+298,"mem_invalidate_i", false,-1);
    tracep->declBit(c+310,"mem_writeback_i", false,-1);
    tracep->declBit(c+305,"mem_flush_i", false,-1);
    tracep->declBit(c+302,"outport_accept_i", false,-1);
    tracep->declBit(c+188,"outport_ack_i", false,-1);
    tracep->declBit(c+191,"outport_error_i", false,-1);
    tracep->declBus(c+21,"outport_read_data_i", false,-1, 31,0);
    tracep->declBus(c+21,"mem_data_rd_o", false,-1, 31,0);
    tracep->declBit(c+300,"mem_accept_o", false,-1);
    tracep->declBit(c+41,"mem_ack_o", false,-1);
    tracep->declBit(c+191,"mem_error_o", false,-1);
    tracep->declBus(c+313,"mem_resp_tag_o", false,-1, 10,0);
    tracep->declBus(c+43,"outport_wr_o", false,-1, 3,0);
    tracep->declBit(c+49,"outport_rd_o", false,-1);
    tracep->declBus(c+689,"outport_len_o", false,-1, 7,0);
    tracep->declBus(c+303,"outport_addr_o", false,-1, 31,0);
    tracep->declBus(c+312,"outport_write_data_o", false,-1, 31,0);
    tracep->declBit(c+358,"res_accept_w", false,-1);
    tracep->declBit(c+359,"req_accept_w", false,-1);
    tracep->declBit(c+59,"request_complete_w", false,-1);
    tracep->declBit(c+59,"req_pop_w", false,-1);
    tracep->declBit(c+360,"req_valid_w", false,-1);
    tracep->declArray(c+361,"req_w", false,-1, 69,0);
    tracep->declBit(c+364,"drop_req_w", false,-1);
    tracep->declBit(c+60,"request_w", false,-1);
    tracep->declBit(c+61,"req_push_w", false,-1);
    tracep->declBit(c+62,"res_push_w", false,-1);
    tracep->declBit(c+365,"request_pending_q", false,-1);
    tracep->declBit(c+63,"request_in_progress_w", false,-1);
    tracep->declBit(c+49,"req_is_read_w", false,-1);
    tracep->declBit(c+196,"req_is_write_w", false,-1);
    tracep->declBit(c+64,"req_is_drop_w", false,-1);
    tracep->declBit(c+366,"dropped_q", false,-1);
    tracep->pushNamePrefix("u_req ");
    tracep->declBus(c+698,"WIDTH", false,-1, 31,0);
    tracep->declBus(c+696,"DEPTH", false,-1, 31,0);
    tracep->declBus(c+697,"ADDR_W", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declArray(c+197,"data_in_i", false,-1, 69,0);
    tracep->declBit(c+61,"push_i", false,-1);
    tracep->declBit(c+59,"pop_i", false,-1);
    tracep->declArray(c+361,"data_out_o", false,-1, 69,0);
    tracep->declBit(c+359,"accept_o", false,-1);
    tracep->declBit(c+360,"valid_o", false,-1);
    tracep->declBus(c+696,"COUNT_W", false,-1, 31,0);
    for (int i = 0; i < 2; ++i) {
        tracep->declArray(c+367+i*3,"ram_q", true,(i+0), 69,0);
    }
    tracep->declBus(c+373,"rd_ptr_q", false,-1, 0,0);
    tracep->declBus(c+374,"wr_ptr_q", false,-1, 0,0);
    tracep->declBus(c+375,"count_q", false,-1, 1,0);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_resp ");
    tracep->declBus(c+699,"WIDTH", false,-1, 31,0);
    tracep->declBus(c+696,"DEPTH", false,-1, 31,0);
    tracep->declBus(c+697,"ADDR_W", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+694,"data_in_i", false,-1, 10,0);
    tracep->declBit(c+62,"push_i", false,-1);
    tracep->declBit(c+41,"pop_i", false,-1);
    tracep->declBus(c+313,"data_out_o", false,-1, 10,0);
    tracep->declBit(c+358,"accept_o", false,-1);
    tracep->declBit(c+376,"valid_o", false,-1);
    tracep->declBus(c+696,"COUNT_W", false,-1, 31,0);
    for (int i = 0; i < 2; ++i) {
        tracep->declBus(c+377+i*1,"ram_q", true,(i+0), 10,0);
    }
    tracep->declBus(c+379,"rd_ptr_q", false,-1, 0,0);
    tracep->declBus(c+380,"wr_ptr_q", false,-1, 0,0);
    tracep->declBus(c+381,"count_q", false,-1, 1,0);
    tracep->popNamePrefix(2);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+684,"AXI_ID", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+33,"req_rd_i", false,-1);
    tracep->declBit(c+287,"req_flush_i", false,-1);
    tracep->declBit(c+686,"req_invalidate_i", false,-1);
    tracep->declBus(c+296,"req_pc_i", false,-1, 31,0);
    tracep->declBit(c+3,"axi_awready_i", false,-1);
    tracep->declBit(c+4,"axi_wready_i", false,-1);
    tracep->declBit(c+5,"axi_bvalid_i", false,-1);
    tracep->declBus(c+6,"axi_bresp_i", false,-1, 1,0);
    tracep->declBus(c+7,"axi_bid_i", false,-1, 3,0);
    tracep->declBit(c+8,"axi_arready_i", false,-1);
    tracep->declBit(c+9,"axi_rvalid_i", false,-1);
    tracep->declBus(c+10,"axi_rdata_i", false,-1, 31,0);
    tracep->declBus(c+11,"axi_rresp_i", false,-1, 1,0);
    tracep->declBus(c+12,"axi_rid_i", false,-1, 3,0);
    tracep->declBit(c+13,"axi_rlast_i", false,-1);
    tracep->declBit(c+31,"req_accept_o", false,-1);
    tracep->declBit(c+286,"req_valid_o", false,-1);
    tracep->declBit(c+295,"req_error_o", false,-1);
    tracep->declBus(c+291,"req_inst_o", false,-1, 31,0);
    tracep->declBit(c+686,"axi_awvalid_o", false,-1);
    tracep->declBus(c+687,"axi_awaddr_o", false,-1, 31,0);
    tracep->declBus(c+688,"axi_awid_o", false,-1, 3,0);
    tracep->declBus(c+689,"axi_awlen_o", false,-1, 7,0);
    tracep->declBus(c+690,"axi_awburst_o", false,-1, 1,0);
    tracep->declBit(c+686,"axi_wvalid_o", false,-1);
    tracep->declBus(c+687,"axi_wdata_o", false,-1, 31,0);
    tracep->declBus(c+688,"axi_wstrb_o", false,-1, 3,0);
    tracep->declBit(c+686,"axi_wlast_o", false,-1);
    tracep->declBit(c+686,"axi_bready_o", false,-1);
    tracep->declBit(c+27,"axi_arvalid_o", false,-1);
    tracep->declBus(c+275,"axi_araddr_o", false,-1, 31,0);
    tracep->declBus(c+688,"axi_arid_o", false,-1, 3,0);
    tracep->declBus(c+691,"axi_arlen_o", false,-1, 7,0);
    tracep->declBus(c+692,"axi_arburst_o", false,-1, 1,0);
    tracep->declBit(c+693,"axi_rready_o", false,-1);
    tracep->declBus(c+696,"ICACHE_NUM_WAYS", false,-1, 31,0);
    tracep->declBus(c+700,"ICACHE_NUM_LINES", false,-1, 31,0);
    tracep->declBus(c+701,"ICACHE_LINE_ADDR_W", false,-1, 31,0);
    tracep->declBus(c+702,"ICACHE_LINE_SIZE_W", false,-1, 31,0);
    tracep->declBus(c+703,"ICACHE_LINE_SIZE", false,-1, 31,0);
    tracep->declBus(c+701,"ICACHE_LINE_WORDS", false,-1, 31,0);
    tracep->declBus(c+702,"ICACHE_TAG_REQ_LINE_L", false,-1, 31,0);
    tracep->declBus(c+704,"ICACHE_TAG_REQ_LINE_H", false,-1, 31,0);
    tracep->declBus(c+701,"ICACHE_TAG_REQ_LINE_W", false,-1, 31,0);
    tracep->declBus(c+705,"CACHE_TAG_ADDR_BITS", false,-1, 31,0);
    tracep->declBus(c+705,"CACHE_TAG_VALID_BIT", false,-1, 31,0);
    tracep->declBus(c+706,"CACHE_TAG_DATA_W", false,-1, 31,0);
    tracep->declBus(c+707,"ICACHE_TAG_CMP_ADDR_L", false,-1, 31,0);
    tracep->declBus(c+708,"ICACHE_TAG_CMP_ADDR_H", false,-1, 31,0);
    tracep->declBus(c+705,"ICACHE_TAG_CMP_ADDR_W", false,-1, 31,0);
    tracep->declBus(c+382,"req_line_addr_w", false,-1, 7,0);
    tracep->declBus(c+699,"CACHE_DATA_ADDR_W", false,-1, 31,0);
    tracep->declBus(c+383,"req_data_addr_w", false,-1, 10,0);
    tracep->declBus(c+696,"STATE_W", false,-1, 31,0);
    tracep->declBus(c+690,"STATE_FLUSH", false,-1, 1,0);
    tracep->declBus(c+692,"STATE_LOOKUP", false,-1, 1,0);
    tracep->declBus(c+709,"STATE_REFILL", false,-1, 1,0);
    tracep->declBus(c+710,"STATE_RELOOKUP", false,-1, 1,0);
    tracep->declBus(c+65,"next_state_r", false,-1, 1,0);
    tracep->declBus(c+384,"state_q", false,-1, 1,0);
    tracep->declBit(c+385,"invalidate_q", false,-1);
    tracep->declBus(c+386,"replace_way_q", false,-1, 0,0);
    tracep->declBit(c+387,"lookup_valid_q", false,-1);
    tracep->declBus(c+388,"lookup_addr_q", false,-1, 31,0);
    tracep->declBus(c+389,"req_pc_tag_cmp_w", false,-1, 18,0);
    tracep->declBus(c+390,"tag_addr_r", false,-1, 7,0);
    tracep->declBus(c+391,"tag_data_in_r", false,-1, 19,0);
    tracep->declBit(c+66,"tag0_write_r", false,-1);
    tracep->declBus(c+224,"tag0_data_out_w", false,-1, 19,0);
    tracep->declBit(c+225,"tag0_valid_w", false,-1);
    tracep->declBus(c+226,"tag0_addr_bits_w", false,-1, 18,0);
    tracep->declBit(c+392,"tag0_hit_w", false,-1);
    tracep->declBit(c+67,"tag1_write_r", false,-1);
    tracep->declBus(c+227,"tag1_data_out_w", false,-1, 19,0);
    tracep->declBit(c+228,"tag1_valid_w", false,-1);
    tracep->declBus(c+229,"tag1_addr_bits_w", false,-1, 18,0);
    tracep->declBit(c+393,"tag1_hit_w", false,-1);
    tracep->declBit(c+394,"tag_hit_any_w", false,-1);
    tracep->declBus(c+395,"data_addr_r", false,-1, 10,0);
    tracep->declBus(c+396,"data_write_addr_q", false,-1, 10,0);
    tracep->declBit(c+200,"data0_write_r", false,-1);
    tracep->declBus(c+230,"data0_data_out_w", false,-1, 31,0);
    tracep->declBit(c+201,"data1_write_r", false,-1);
    tracep->declBus(c+231,"data1_data_out_w", false,-1, 31,0);
    tracep->declBus(c+397,"flush_addr_q", false,-1, 7,0);
    tracep->declBus(c+291,"inst_r", false,-1, 31,0);
    tracep->declBit(c+398,"axi_arvalid_q", false,-1);
    tracep->declBit(c+295,"axi_error_q", false,-1);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_core__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+697,"SUPPORT_MULDIV", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_SUPER", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_MMU", false,-1, 31,0);
    tracep->declBus(c+697,"SUPPORT_LOAD_BYPASS", false,-1, 31,0);
    tracep->declBus(c+697,"SUPPORT_MUL_BYPASS", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_REGFILE_XILINX", false,-1, 31,0);
    tracep->declBus(c+684,"EXTRA_DECODE_STAGE", false,-1, 31,0);
    tracep->declBus(c+684,"MEM_CACHE_ADDR_MIN", false,-1, 31,0);
    tracep->declBus(c+685,"MEM_CACHE_ADDR_MAX", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+186,"mem_d_data_rd_i", false,-1, 31,0);
    tracep->declBit(c+30,"mem_d_accept_i", false,-1);
    tracep->declBit(c+28,"mem_d_ack_i", false,-1);
    tracep->declBit(c+34,"mem_d_error_i", false,-1);
    tracep->declBus(c+290,"mem_d_resp_tag_i", false,-1, 10,0);
    tracep->declBit(c+31,"mem_i_accept_i", false,-1);
    tracep->declBit(c+286,"mem_i_valid_i", false,-1);
    tracep->declBit(c+295,"mem_i_error_i", false,-1);
    tracep->declBus(c+291,"mem_i_inst_i", false,-1, 31,0);
    tracep->declBit(c+25,"intr_i", false,-1);
    tracep->declBus(c+26,"reset_vector_i", false,-1, 31,0);
    tracep->declBus(c+687,"cpu_id_i", false,-1, 31,0);
    tracep->declBus(c+292,"mem_d_addr_o", false,-1, 31,0);
    tracep->declBus(c+297,"mem_d_data_wr_o", false,-1, 31,0);
    tracep->declBit(c+29,"mem_d_rd_o", false,-1);
    tracep->declBus(c+32,"mem_d_wr_o", false,-1, 3,0);
    tracep->declBit(c+294,"mem_d_cacheable_o", false,-1);
    tracep->declBus(c+694,"mem_d_req_tag_o", false,-1, 10,0);
    tracep->declBit(c+289,"mem_d_invalidate_o", false,-1);
    tracep->declBit(c+293,"mem_d_writeback_o", false,-1);
    tracep->declBit(c+288,"mem_d_flush_o", false,-1);
    tracep->declBit(c+33,"mem_i_rd_o", false,-1);
    tracep->declBit(c+287,"mem_i_flush_o", false,-1);
    tracep->declBit(c+686,"mem_i_invalidate_o", false,-1);
    tracep->declBus(c+296,"mem_i_pc_o", false,-1, 31,0);
    tracep->declBit(c+293,"mmu_lsu_writeback_w", false,-1);
    tracep->declBus(c+399,"fetch_in_priv_w", false,-1, 1,0);
    tracep->declBus(c+400,"mul_opcode_rd_idx_w", false,-1, 4,0);
    tracep->declBit(c+401,"mmu_flush_w", false,-1);
    tracep->declBus(c+402,"lsu_opcode_pc_w", false,-1, 31,0);
    tracep->declBit(c+68,"fetch_accept_w", false,-1);
    tracep->declBus(c+400,"csr_opcode_rd_idx_w", false,-1, 4,0);
    tracep->declBus(c+403,"branch_exec_source_w", false,-1, 31,0);
    tracep->declBus(c+69,"csr_opcode_rb_operand_w", false,-1, 31,0);
    tracep->declBus(c+404,"writeback_div_value_w", false,-1, 31,0);
    tracep->declBit(c+70,"csr_opcode_valid_w", false,-1);
    tracep->declBit(c+405,"branch_csr_request_w", false,-1);
    tracep->declBus(c+291,"mmu_ifetch_inst_w", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_w", false,-1, 31,0);
    tracep->declBus(c+406,"opcode_rb_idx_w", false,-1, 4,0);
    tracep->declBit(c+34,"mmu_lsu_error_w", false,-1);
    tracep->declBit(c+71,"mul_opcode_valid_w", false,-1);
    tracep->declBit(c+407,"mmu_mxr_w", false,-1);
    tracep->declBus(c+690,"branch_d_exec_priv_w", false,-1, 1,0);
    tracep->declBit(c+286,"mmu_ifetch_valid_w", false,-1);
    tracep->declBit(c+72,"csr_opcode_invalid_w", false,-1);
    tracep->declBus(c+408,"csr_writeback_exception_w", false,-1, 5,0);
    tracep->declBit(c+409,"fetch_instr_mul_w", false,-1);
    tracep->declBit(c+410,"branch_exec_is_ret_w", false,-1);
    tracep->declBus(c+411,"csr_writeback_exception_addr_w", false,-1, 31,0);
    tracep->declBus(c+32,"mmu_lsu_wr_w", false,-1, 3,0);
    tracep->declBit(c+686,"fetch_in_fault_w", false,-1);
    tracep->declBit(c+73,"branch_request_w", false,-1);
    tracep->declBus(c+402,"csr_opcode_pc_w", false,-1, 31,0);
    tracep->declBit(c+74,"writeback_mem_valid_w", false,-1);
    tracep->declBus(c+412,"csr_result_e1_exception_w", false,-1, 5,0);
    tracep->declBus(c+413,"branch_csr_pc_w", false,-1, 31,0);
    tracep->declBus(c+297,"mmu_lsu_data_wr_w", false,-1, 31,0);
    tracep->declBit(c+414,"fetch_fault_page_w", false,-1);
    tracep->declBus(c+290,"mmu_lsu_resp_tag_w", false,-1, 10,0);
    tracep->declBus(c+694,"mmu_lsu_req_tag_w", false,-1, 10,0);
    tracep->declBus(c+75,"opcode_ra_operand_w", false,-1, 31,0);
    tracep->declBit(c+73,"squash_decode_w", false,-1);
    tracep->declBit(c+414,"fetch_dec_fault_page_w", false,-1);
    tracep->declBus(c+415,"mul_opcode_opcode_w", false,-1, 31,0);
    tracep->declBit(c+76,"exec_hold_w", false,-1);
    tracep->declBit(c+416,"fetch_instr_invalid_w", false,-1);
    tracep->declBus(c+202,"branch_pc_w", false,-1, 31,0);
    tracep->declBus(c+417,"mul_opcode_ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+406,"csr_opcode_rb_idx_w", false,-1, 4,0);
    tracep->declBit(c+203,"lsu_stall_w", false,-1);
    tracep->declBit(c+418,"branch_exec_is_not_taken_w", false,-1);
    tracep->declBus(c+419,"branch_exec_pc_w", false,-1, 31,0);
    tracep->declBus(c+415,"opcode_opcode_w", false,-1, 31,0);
    tracep->declBus(c+402,"mul_opcode_pc_w", false,-1, 31,0);
    tracep->declBit(c+77,"branch_d_exec_request_w", false,-1);
    tracep->declBus(c+75,"mul_opcode_ra_operand_w", false,-1, 31,0);
    tracep->declBit(c+420,"branch_exec_is_taken_w", false,-1);
    tracep->declBit(c+421,"fetch_dec_fault_fetch_w", false,-1);
    tracep->declBit(c+422,"fetch_dec_valid_w", false,-1);
    tracep->declBit(c+421,"fetch_fault_fetch_w", false,-1);
    tracep->declBit(c+686,"lsu_opcode_invalid_w", false,-1);
    tracep->declBus(c+292,"mmu_lsu_addr_w", false,-1, 31,0);
    tracep->declBit(c+76,"mul_hold_w", false,-1);
    tracep->declBit(c+31,"mmu_ifetch_accept_w", false,-1);
    tracep->declBit(c+28,"mmu_lsu_ack_w", false,-1);
    tracep->declBus(c+402,"fetch_pc_w", false,-1, 31,0);
    tracep->declBit(c+686,"mmu_ifetch_invalidate_w", false,-1);
    tracep->declBus(c+69,"mul_opcode_rb_operand_w", false,-1, 31,0);
    tracep->declBus(c+423,"branch_csr_priv_w", false,-1, 1,0);
    tracep->declBit(c+424,"branch_exec_request_w", false,-1);
    tracep->declBus(c+75,"lsu_opcode_ra_operand_w", false,-1, 31,0);
    tracep->declBit(c+71,"div_opcode_valid_w", false,-1);
    tracep->declBus(c+425,"branch_priv_w", false,-1, 1,0);
    tracep->declBit(c+29,"mmu_lsu_rd_w", false,-1);
    tracep->declBus(c+402,"fetch_dec_pc_w", false,-1, 31,0);
    tracep->declBit(c+426,"interrupt_inhibit_w", false,-1);
    tracep->declBit(c+295,"mmu_ifetch_error_w", false,-1);
    tracep->declBus(c+204,"writeback_mem_exception_w", false,-1, 5,0);
    tracep->declBit(c+427,"fetch_instr_lsu_w", false,-1);
    tracep->declBus(c+428,"mmu_priv_d_w", false,-1, 1,0);
    tracep->declBus(c+417,"opcode_ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+75,"csr_opcode_ra_operand_w", false,-1, 31,0);
    tracep->declBus(c+78,"writeback_mem_value_w", false,-1, 31,0);
    tracep->declBit(c+429,"writeback_div_valid_w", false,-1);
    tracep->declBus(c+406,"mul_opcode_rb_idx_w", false,-1, 4,0);
    tracep->declBit(c+686,"opcode_invalid_w", false,-1);
    tracep->declBit(c+430,"fetch_instr_branch_w", false,-1);
    tracep->declBus(c+296,"mmu_ifetch_pc_w", false,-1, 31,0);
    tracep->declBit(c+33,"mmu_ifetch_rd_w", false,-1);
    tracep->declBit(c+287,"mmu_ifetch_flush_w", false,-1);
    tracep->declBus(c+400,"lsu_opcode_rd_idx_w", false,-1, 4,0);
    tracep->declBus(c+415,"lsu_opcode_opcode_w", false,-1, 31,0);
    tracep->declBit(c+686,"mmu_load_fault_w", false,-1);
    tracep->declBus(c+431,"mmu_satp_w", false,-1, 31,0);
    tracep->declBus(c+432,"csr_result_e1_wdata_w", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_w", false,-1, 31,0);
    tracep->declBit(c+289,"mmu_lsu_invalidate_w", false,-1);
    tracep->declBit(c+68,"fetch_dec_accept_w", false,-1);
    tracep->declBus(c+417,"csr_opcode_ra_idx_w", false,-1, 4,0);
    tracep->declBit(c+433,"ifence_w", false,-1);
    tracep->declBit(c+434,"fetch_instr_exec_w", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_w", false,-1, 4,0);
    tracep->declBus(c+435,"csr_writeback_wdata_w", false,-1, 31,0);
    tracep->declBit(c+436,"csr_writeback_write_w", false,-1);
    tracep->declBit(c+437,"take_interrupt_w", false,-1);
    tracep->declBus(c+438,"csr_result_e1_value_w", false,-1, 31,0);
    tracep->declBus(c+79,"branch_d_exec_pc_w", false,-1, 31,0);
    tracep->declBit(c+422,"fetch_valid_w", false,-1);
    tracep->declBus(c+439,"csr_writeback_waddr_w", false,-1, 11,0);
    tracep->declBit(c+440,"branch_exec_is_jmp_w", false,-1);
    tracep->declBit(c+294,"mmu_lsu_cacheable_w", false,-1);
    tracep->declBit(c+441,"fetch_instr_csr_w", false,-1);
    tracep->declBit(c+70,"lsu_opcode_valid_w", false,-1);
    tracep->declBus(c+442,"fetch_dec_instr_w", false,-1, 31,0);
    tracep->declBit(c+443,"csr_result_e1_write_w", false,-1);
    tracep->declBus(c+415,"csr_opcode_opcode_w", false,-1, 31,0);
    tracep->declBit(c+444,"fetch_instr_div_w", false,-1);
    tracep->declBus(c+415,"fetch_instr_w", false,-1, 31,0);
    tracep->declBit(c+686,"mul_opcode_invalid_w", false,-1);
    tracep->declBit(c+445,"fetch_instr_rd_valid_w", false,-1);
    tracep->declBus(c+186,"mmu_lsu_data_rd_w", false,-1, 31,0);
    tracep->declBit(c+71,"exec_opcode_valid_w", false,-1);
    tracep->declBus(c+446,"writeback_mul_value_w", false,-1, 31,0);
    tracep->declBit(c+288,"mmu_lsu_flush_w", false,-1);
    tracep->declBus(c+406,"lsu_opcode_rb_idx_w", false,-1, 4,0);
    tracep->declBit(c+30,"mmu_lsu_accept_w", false,-1);
    tracep->declBus(c+69,"lsu_opcode_rb_operand_w", false,-1, 31,0);
    tracep->declBit(c+447,"mmu_sum_w", false,-1);
    tracep->declBus(c+448,"writeback_exec_value_w", false,-1, 31,0);
    tracep->declBus(c+417,"lsu_opcode_ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+449,"csr_writeback_exception_pc_w", false,-1, 31,0);
    tracep->declBit(c+686,"mmu_store_fault_w", false,-1);
    tracep->declBit(c+450,"branch_exec_is_call_w", false,-1);
    tracep->pushNamePrefix("u_decode ");
    tracep->declBus(c+697,"SUPPORT_MULDIV", false,-1, 31,0);
    tracep->declBus(c+684,"EXTRA_DECODE_STAGE", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+422,"fetch_in_valid_i", false,-1);
    tracep->declBus(c+442,"fetch_in_instr_i", false,-1, 31,0);
    tracep->declBus(c+402,"fetch_in_pc_i", false,-1, 31,0);
    tracep->declBit(c+421,"fetch_in_fault_fetch_i", false,-1);
    tracep->declBit(c+414,"fetch_in_fault_page_i", false,-1);
    tracep->declBit(c+68,"fetch_out_accept_i", false,-1);
    tracep->declBit(c+73,"squash_decode_i", false,-1);
    tracep->declBit(c+68,"fetch_in_accept_o", false,-1);
    tracep->declBit(c+422,"fetch_out_valid_o", false,-1);
    tracep->declBus(c+415,"fetch_out_instr_o", false,-1, 31,0);
    tracep->declBus(c+402,"fetch_out_pc_o", false,-1, 31,0);
    tracep->declBit(c+421,"fetch_out_fault_fetch_o", false,-1);
    tracep->declBit(c+414,"fetch_out_fault_page_o", false,-1);
    tracep->declBit(c+434,"fetch_out_instr_exec_o", false,-1);
    tracep->declBit(c+427,"fetch_out_instr_lsu_o", false,-1);
    tracep->declBit(c+430,"fetch_out_instr_branch_o", false,-1);
    tracep->declBit(c+409,"fetch_out_instr_mul_o", false,-1);
    tracep->declBit(c+444,"fetch_out_instr_div_o", false,-1);
    tracep->declBit(c+441,"fetch_out_instr_csr_o", false,-1);
    tracep->declBit(c+445,"fetch_out_instr_rd_valid_o", false,-1);
    tracep->declBit(c+416,"fetch_out_instr_invalid_o", false,-1);
    tracep->declBit(c+693,"enable_muldiv_w", false,-1);
    tracep->pushNamePrefix("genblk1 ");
    tracep->declBus(c+415,"fetch_in_instr_w", false,-1, 31,0);
    tracep->pushNamePrefix("u_dec ");
    tracep->declBit(c+422,"valid_i", false,-1);
    tracep->declBit(c+451,"fetch_fault_i", false,-1);
    tracep->declBit(c+693,"enable_muldiv_i", false,-1);
    tracep->declBus(c+415,"opcode_i", false,-1, 31,0);
    tracep->declBit(c+416,"invalid_o", false,-1);
    tracep->declBit(c+434,"exec_o", false,-1);
    tracep->declBit(c+427,"lsu_o", false,-1);
    tracep->declBit(c+430,"branch_o", false,-1);
    tracep->declBit(c+409,"mul_o", false,-1);
    tracep->declBit(c+444,"div_o", false,-1);
    tracep->declBit(c+441,"csr_o", false,-1);
    tracep->declBit(c+445,"rd_valid_o", false,-1);
    tracep->declBit(c+416,"invalid_w", false,-1);
    tracep->popNamePrefix(3);
    tracep->pushNamePrefix("u_div ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+71,"opcode_valid_i", false,-1);
    tracep->declBus(c+415,"opcode_opcode_i", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_i", false,-1, 31,0);
    tracep->declBit(c+686,"opcode_invalid_i", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_i", false,-1, 4,0);
    tracep->declBus(c+417,"opcode_ra_idx_i", false,-1, 4,0);
    tracep->declBus(c+406,"opcode_rb_idx_i", false,-1, 4,0);
    tracep->declBus(c+75,"opcode_ra_operand_i", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_i", false,-1, 31,0);
    tracep->declBit(c+429,"writeback_valid_o", false,-1);
    tracep->declBus(c+404,"writeback_value_o", false,-1, 31,0);
    tracep->declBit(c+429,"valid_q", false,-1);
    tracep->declBus(c+404,"wb_result_q", false,-1, 31,0);
    tracep->declBit(c+452,"inst_div_w", false,-1);
    tracep->declBit(c+453,"inst_divu_w", false,-1);
    tracep->declBit(c+454,"inst_rem_w", false,-1);
    tracep->declBit(c+455,"inst_remu_w", false,-1);
    tracep->declBit(c+456,"div_rem_inst_w", false,-1);
    tracep->declBit(c+457,"signed_operation_w", false,-1);
    tracep->declBit(c+458,"div_operation_w", false,-1);
    tracep->declBus(c+459,"dividend_q", false,-1, 31,0);
    tracep->declQuad(c+460,"divisor_q", false,-1, 62,0);
    tracep->declBus(c+462,"quotient_q", false,-1, 31,0);
    tracep->declBus(c+463,"q_mask_q", false,-1, 31,0);
    tracep->declBit(c+464,"div_inst_q", false,-1);
    tracep->declBit(c+465,"div_busy_q", false,-1);
    tracep->declBit(c+466,"invert_res_q", false,-1);
    tracep->declBit(c+80,"div_start_w", false,-1);
    tracep->declBit(c+467,"div_complete_w", false,-1);
    tracep->declBus(c+468,"div_result_r", false,-1, 31,0);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_exec ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+71,"opcode_valid_i", false,-1);
    tracep->declBus(c+415,"opcode_opcode_i", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_i", false,-1, 31,0);
    tracep->declBit(c+686,"opcode_invalid_i", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_i", false,-1, 4,0);
    tracep->declBus(c+417,"opcode_ra_idx_i", false,-1, 4,0);
    tracep->declBus(c+406,"opcode_rb_idx_i", false,-1, 4,0);
    tracep->declBus(c+75,"opcode_ra_operand_i", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_i", false,-1, 31,0);
    tracep->declBit(c+76,"hold_i", false,-1);
    tracep->declBit(c+424,"branch_request_o", false,-1);
    tracep->declBit(c+420,"branch_is_taken_o", false,-1);
    tracep->declBit(c+418,"branch_is_not_taken_o", false,-1);
    tracep->declBus(c+403,"branch_source_o", false,-1, 31,0);
    tracep->declBit(c+450,"branch_is_call_o", false,-1);
    tracep->declBit(c+410,"branch_is_ret_o", false,-1);
    tracep->declBit(c+440,"branch_is_jmp_o", false,-1);
    tracep->declBus(c+419,"branch_pc_o", false,-1, 31,0);
    tracep->declBit(c+77,"branch_d_request_o", false,-1);
    tracep->declBus(c+79,"branch_d_pc_o", false,-1, 31,0);
    tracep->declBus(c+690,"branch_d_priv_o", false,-1, 1,0);
    tracep->declBus(c+448,"writeback_value_o", false,-1, 31,0);
    tracep->declBus(c+469,"imm20_r", false,-1, 31,0);
    tracep->declBus(c+470,"imm12_r", false,-1, 31,0);
    tracep->declBus(c+471,"bimm_r", false,-1, 31,0);
    tracep->declBus(c+472,"jimm20_r", false,-1, 31,0);
    tracep->declBus(c+406,"shamt_r", false,-1, 4,0);
    tracep->declBus(c+473,"alu_func_r", false,-1, 3,0);
    tracep->declBus(c+81,"alu_input_a_r", false,-1, 31,0);
    tracep->declBus(c+82,"alu_input_b_r", false,-1, 31,0);
    tracep->declBus(c+83,"alu_p_w", false,-1, 31,0);
    tracep->declBus(c+448,"result_q", false,-1, 31,0);
    tracep->declBit(c+474,"branch_r", false,-1);
    tracep->declBit(c+84,"branch_taken_r", false,-1);
    tracep->declBus(c+79,"branch_target_r", false,-1, 31,0);
    tracep->declBit(c+475,"branch_call_r", false,-1);
    tracep->declBit(c+476,"branch_ret_r", false,-1);
    tracep->declBit(c+477,"branch_jmp_r", false,-1);
    tracep->declBit(c+420,"branch_taken_q", false,-1);
    tracep->declBit(c+418,"branch_ntaken_q", false,-1);
    tracep->declBus(c+419,"pc_x_q", false,-1, 31,0);
    tracep->declBus(c+403,"pc_m_q", false,-1, 31,0);
    tracep->declBit(c+450,"branch_call_q", false,-1);
    tracep->declBit(c+410,"branch_ret_q", false,-1);
    tracep->declBit(c+440,"branch_jmp_q", false,-1);
    tracep->pushNamePrefix("u_alu ");
    tracep->declBus(c+473,"alu_op_i", false,-1, 3,0);
    tracep->declBus(c+81,"alu_a_i", false,-1, 31,0);
    tracep->declBus(c+82,"alu_b_i", false,-1, 31,0);
    tracep->declBus(c+83,"alu_p_o", false,-1, 31,0);
    tracep->declBus(c+83,"result_r", false,-1, 31,0);
    tracep->declBus(c+85,"shift_right_fill_r", false,-1, 31,16);
    tracep->declBus(c+86,"shift_right_1_r", false,-1, 31,0);
    tracep->declBus(c+87,"shift_right_2_r", false,-1, 31,0);
    tracep->declBus(c+88,"shift_right_4_r", false,-1, 31,0);
    tracep->declBus(c+89,"shift_right_8_r", false,-1, 31,0);
    tracep->declBus(c+90,"shift_left_1_r", false,-1, 31,0);
    tracep->declBus(c+91,"shift_left_2_r", false,-1, 31,0);
    tracep->declBus(c+92,"shift_left_4_r", false,-1, 31,0);
    tracep->declBus(c+93,"shift_left_8_r", false,-1, 31,0);
    tracep->declBus(c+94,"sub_res_w", false,-1, 31,0);
    tracep->popNamePrefix(2);
    tracep->pushNamePrefix("u_fetch ");
    tracep->declBus(c+684,"SUPPORT_MMU", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+68,"fetch_accept_i", false,-1);
    tracep->declBit(c+31,"icache_accept_i", false,-1);
    tracep->declBit(c+286,"icache_valid_i", false,-1);
    tracep->declBit(c+295,"icache_error_i", false,-1);
    tracep->declBus(c+291,"icache_inst_i", false,-1, 31,0);
    tracep->declBit(c+686,"icache_page_fault_i", false,-1);
    tracep->declBit(c+433,"fetch_invalidate_i", false,-1);
    tracep->declBit(c+73,"branch_request_i", false,-1);
    tracep->declBus(c+202,"branch_pc_i", false,-1, 31,0);
    tracep->declBus(c+425,"branch_priv_i", false,-1, 1,0);
    tracep->declBit(c+422,"fetch_valid_o", false,-1);
    tracep->declBus(c+442,"fetch_instr_o", false,-1, 31,0);
    tracep->declBus(c+402,"fetch_pc_o", false,-1, 31,0);
    tracep->declBit(c+421,"fetch_fault_fetch_o", false,-1);
    tracep->declBit(c+414,"fetch_fault_page_o", false,-1);
    tracep->declBit(c+33,"icache_rd_o", false,-1);
    tracep->declBit(c+287,"icache_flush_o", false,-1);
    tracep->declBit(c+686,"icache_invalidate_o", false,-1);
    tracep->declBus(c+296,"icache_pc_o", false,-1, 31,0);
    tracep->declBus(c+399,"icache_priv_o", false,-1, 1,0);
    tracep->declBit(c+73,"squash_decode_o", false,-1);
    tracep->declBit(c+478,"active_q", false,-1);
    tracep->declBit(c+479,"icache_busy_w", false,-1);
    tracep->declBit(c+95,"stall_w", false,-1);
    tracep->declBit(c+480,"branch_q", false,-1);
    tracep->declBus(c+481,"branch_pc_q", false,-1, 31,0);
    tracep->declBus(c+482,"branch_priv_q", false,-1, 1,0);
    tracep->declBit(c+480,"branch_w", false,-1);
    tracep->declBus(c+481,"branch_pc_w", false,-1, 31,0);
    tracep->declBus(c+482,"branch_priv_w", false,-1, 1,0);
    tracep->declBit(c+483,"stall_q", false,-1);
    tracep->declBit(c+484,"icache_fetch_q", false,-1);
    tracep->declBit(c+485,"icache_invalidate_q", false,-1);
    tracep->declBus(c+486,"pc_f_q", false,-1, 31,0);
    tracep->declBus(c+487,"pc_d_q", false,-1, 31,0);
    tracep->declBus(c+486,"icache_pc_w", false,-1, 31,0);
    tracep->declBus(c+399,"icache_priv_w", false,-1, 1,0);
    tracep->declBit(c+488,"fetch_resp_drop_w", false,-1);
    tracep->declBus(c+399,"priv_f_q", false,-1, 1,0);
    tracep->declBit(c+489,"branch_d_q", false,-1);
    tracep->declArray(c+490,"skid_buffer_q", false,-1, 65,0);
    tracep->declBit(c+493,"skid_valid_q", false,-1);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_lsu ");
    tracep->declBus(c+684,"MEM_CACHE_ADDR_MIN", false,-1, 31,0);
    tracep->declBus(c+685,"MEM_CACHE_ADDR_MAX", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+70,"opcode_valid_i", false,-1);
    tracep->declBus(c+415,"opcode_opcode_i", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_i", false,-1, 31,0);
    tracep->declBit(c+686,"opcode_invalid_i", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_i", false,-1, 4,0);
    tracep->declBus(c+417,"opcode_ra_idx_i", false,-1, 4,0);
    tracep->declBus(c+406,"opcode_rb_idx_i", false,-1, 4,0);
    tracep->declBus(c+75,"opcode_ra_operand_i", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_i", false,-1, 31,0);
    tracep->declBus(c+186,"mem_data_rd_i", false,-1, 31,0);
    tracep->declBit(c+30,"mem_accept_i", false,-1);
    tracep->declBit(c+28,"mem_ack_i", false,-1);
    tracep->declBit(c+34,"mem_error_i", false,-1);
    tracep->declBus(c+290,"mem_resp_tag_i", false,-1, 10,0);
    tracep->declBit(c+686,"mem_load_fault_i", false,-1);
    tracep->declBit(c+686,"mem_store_fault_i", false,-1);
    tracep->declBus(c+292,"mem_addr_o", false,-1, 31,0);
    tracep->declBus(c+297,"mem_data_wr_o", false,-1, 31,0);
    tracep->declBit(c+29,"mem_rd_o", false,-1);
    tracep->declBus(c+32,"mem_wr_o", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cacheable_o", false,-1);
    tracep->declBus(c+694,"mem_req_tag_o", false,-1, 10,0);
    tracep->declBit(c+289,"mem_invalidate_o", false,-1);
    tracep->declBit(c+293,"mem_writeback_o", false,-1);
    tracep->declBit(c+288,"mem_flush_o", false,-1);
    tracep->declBit(c+74,"writeback_valid_o", false,-1);
    tracep->declBus(c+78,"writeback_value_o", false,-1, 31,0);
    tracep->declBus(c+204,"writeback_exception_o", false,-1, 5,0);
    tracep->declBit(c+203,"stall_o", false,-1);
    tracep->declBus(c+494,"mem_addr_q", false,-1, 31,0);
    tracep->declBus(c+297,"mem_data_wr_q", false,-1, 31,0);
    tracep->declBit(c+495,"mem_rd_q", false,-1);
    tracep->declBus(c+496,"mem_wr_q", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cacheable_q", false,-1);
    tracep->declBit(c+289,"mem_invalidate_q", false,-1);
    tracep->declBit(c+293,"mem_writeback_q", false,-1);
    tracep->declBit(c+288,"mem_flush_q", false,-1);
    tracep->declBit(c+497,"mem_unaligned_e1_q", false,-1);
    tracep->declBit(c+498,"mem_unaligned_e2_q", false,-1);
    tracep->declBit(c+499,"mem_load_q", false,-1);
    tracep->declBit(c+500,"mem_xb_q", false,-1);
    tracep->declBit(c+501,"mem_xh_q", false,-1);
    tracep->declBit(c+502,"mem_ls_q", false,-1);
    tracep->declBit(c+503,"pending_lsu_e2_q", false,-1);
    tracep->declBit(c+205,"issue_lsu_e1_w", false,-1);
    tracep->declBit(c+96,"complete_ok_e2_w", false,-1);
    tracep->declBit(c+97,"complete_err_e2_w", false,-1);
    tracep->declBit(c+98,"delay_lsu_e2_w", false,-1);
    tracep->declBit(c+504,"load_inst_w", false,-1);
    tracep->declBit(c+505,"load_signed_inst_w", false,-1);
    tracep->declBit(c+506,"store_inst_w", false,-1);
    tracep->declBit(c+507,"req_lb_w", false,-1);
    tracep->declBit(c+508,"req_lh_w", false,-1);
    tracep->declBit(c+509,"req_lw_w", false,-1);
    tracep->declBit(c+510,"req_sb_w", false,-1);
    tracep->declBit(c+511,"req_sh_w", false,-1);
    tracep->declBit(c+512,"req_sw_w", false,-1);
    tracep->declBit(c+513,"req_sw_lw_w", false,-1);
    tracep->declBit(c+514,"req_sh_lh_w", false,-1);
    tracep->declBus(c+99,"mem_addr_r", false,-1, 31,0);
    tracep->declBit(c+100,"mem_unaligned_r", false,-1);
    tracep->declBus(c+101,"mem_data_r", false,-1, 31,0);
    tracep->declBit(c+102,"mem_rd_r", false,-1);
    tracep->declBus(c+103,"mem_wr_r", false,-1, 3,0);
    tracep->declBit(c+515,"dcache_flush_w", false,-1);
    tracep->declBit(c+516,"dcache_writeback_w", false,-1);
    tracep->declBit(c+517,"dcache_invalidate_w", false,-1);
    tracep->declBit(c+518,"resp_load_w", false,-1);
    tracep->declBus(c+519,"resp_addr_w", false,-1, 31,0);
    tracep->declBit(c+520,"resp_byte_w", false,-1);
    tracep->declBit(c+521,"resp_half_w", false,-1);
    tracep->declBit(c+522,"resp_signed_w", false,-1);
    tracep->declBus(c+104,"addr_lsb_r", false,-1, 1,0);
    tracep->declBit(c+105,"load_byte_r", false,-1);
    tracep->declBit(c+106,"load_half_r", false,-1);
    tracep->declBit(c+107,"load_signed_r", false,-1);
    tracep->declBus(c+78,"wb_result_r", false,-1, 31,0);
    tracep->declBit(c+523,"fault_load_align_w", false,-1);
    tracep->declBit(c+524,"fault_store_align_w", false,-1);
    tracep->declBit(c+206,"fault_load_bus_w", false,-1);
    tracep->declBit(c+207,"fault_store_bus_w", false,-1);
    tracep->declBit(c+686,"fault_load_page_w", false,-1);
    tracep->declBit(c+686,"fault_store_page_w", false,-1);
    tracep->pushNamePrefix("u_lsu_request ");
    tracep->declBus(c+711,"WIDTH", false,-1, 31,0);
    tracep->declBus(c+696,"DEPTH", false,-1, 31,0);
    tracep->declBus(c+697,"ADDR_W", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declQuad(c+525,"data_in_i", false,-1, 35,0);
    tracep->declBit(c+108,"push_i", false,-1);
    tracep->declBit(c+109,"pop_i", false,-1);
    tracep->declQuad(c+527,"data_out_o", false,-1, 35,0);
    tracep->declBit(c+529,"accept_o", false,-1);
    tracep->declBit(c+530,"valid_o", false,-1);
    tracep->declBus(c+696,"COUNT_W", false,-1, 31,0);
    for (int i = 0; i < 2; ++i) {
        tracep->declQuad(c+531+i*2,"ram_q", true,(i+0), 35,0);
    }
    tracep->declBus(c+535,"rd_ptr_q", false,-1, 0,0);
    tracep->declBus(c+536,"wr_ptr_q", false,-1, 0,0);
    tracep->declBus(c+537,"count_q", false,-1, 1,0);
    tracep->declBus(c+538,"i", false,-1, 31,0);
    tracep->popNamePrefix(2);
    tracep->pushNamePrefix("u_mmu ");
    tracep->declBus(c+684,"MEM_CACHE_ADDR_MIN", false,-1, 31,0);
    tracep->declBus(c+685,"MEM_CACHE_ADDR_MAX", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_MMU", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+428,"priv_d_i", false,-1, 1,0);
    tracep->declBit(c+447,"sum_i", false,-1);
    tracep->declBit(c+407,"mxr_i", false,-1);
    tracep->declBit(c+401,"flush_i", false,-1);
    tracep->declBus(c+431,"satp_i", false,-1, 31,0);
    tracep->declBit(c+33,"fetch_in_rd_i", false,-1);
    tracep->declBit(c+287,"fetch_in_flush_i", false,-1);
    tracep->declBit(c+686,"fetch_in_invalidate_i", false,-1);
    tracep->declBus(c+296,"fetch_in_pc_i", false,-1, 31,0);
    tracep->declBus(c+399,"fetch_in_priv_i", false,-1, 1,0);
    tracep->declBit(c+31,"fetch_out_accept_i", false,-1);
    tracep->declBit(c+286,"fetch_out_valid_i", false,-1);
    tracep->declBit(c+295,"fetch_out_error_i", false,-1);
    tracep->declBus(c+291,"fetch_out_inst_i", false,-1, 31,0);
    tracep->declBus(c+292,"lsu_in_addr_i", false,-1, 31,0);
    tracep->declBus(c+297,"lsu_in_data_wr_i", false,-1, 31,0);
    tracep->declBit(c+29,"lsu_in_rd_i", false,-1);
    tracep->declBus(c+32,"lsu_in_wr_i", false,-1, 3,0);
    tracep->declBit(c+294,"lsu_in_cacheable_i", false,-1);
    tracep->declBus(c+694,"lsu_in_req_tag_i", false,-1, 10,0);
    tracep->declBit(c+289,"lsu_in_invalidate_i", false,-1);
    tracep->declBit(c+293,"lsu_in_writeback_i", false,-1);
    tracep->declBit(c+288,"lsu_in_flush_i", false,-1);
    tracep->declBus(c+186,"lsu_out_data_rd_i", false,-1, 31,0);
    tracep->declBit(c+30,"lsu_out_accept_i", false,-1);
    tracep->declBit(c+28,"lsu_out_ack_i", false,-1);
    tracep->declBit(c+34,"lsu_out_error_i", false,-1);
    tracep->declBus(c+290,"lsu_out_resp_tag_i", false,-1, 10,0);
    tracep->declBit(c+31,"fetch_in_accept_o", false,-1);
    tracep->declBit(c+286,"fetch_in_valid_o", false,-1);
    tracep->declBit(c+295,"fetch_in_error_o", false,-1);
    tracep->declBus(c+291,"fetch_in_inst_o", false,-1, 31,0);
    tracep->declBit(c+33,"fetch_out_rd_o", false,-1);
    tracep->declBit(c+287,"fetch_out_flush_o", false,-1);
    tracep->declBit(c+686,"fetch_out_invalidate_o", false,-1);
    tracep->declBus(c+296,"fetch_out_pc_o", false,-1, 31,0);
    tracep->declBit(c+686,"fetch_in_fault_o", false,-1);
    tracep->declBus(c+186,"lsu_in_data_rd_o", false,-1, 31,0);
    tracep->declBit(c+30,"lsu_in_accept_o", false,-1);
    tracep->declBit(c+28,"lsu_in_ack_o", false,-1);
    tracep->declBit(c+34,"lsu_in_error_o", false,-1);
    tracep->declBus(c+290,"lsu_in_resp_tag_o", false,-1, 10,0);
    tracep->declBus(c+292,"lsu_out_addr_o", false,-1, 31,0);
    tracep->declBus(c+297,"lsu_out_data_wr_o", false,-1, 31,0);
    tracep->declBit(c+29,"lsu_out_rd_o", false,-1);
    tracep->declBus(c+32,"lsu_out_wr_o", false,-1, 3,0);
    tracep->declBit(c+294,"lsu_out_cacheable_o", false,-1);
    tracep->declBus(c+694,"lsu_out_req_tag_o", false,-1, 10,0);
    tracep->declBit(c+289,"lsu_out_invalidate_o", false,-1);
    tracep->declBit(c+293,"lsu_out_writeback_o", false,-1);
    tracep->declBit(c+288,"lsu_out_flush_o", false,-1);
    tracep->declBit(c+686,"lsu_in_load_fault_o", false,-1);
    tracep->declBit(c+686,"lsu_in_store_fault_o", false,-1);
    tracep->declBus(c+696,"STATE_W", false,-1, 31,0);
    tracep->declBus(c+684,"STATE_IDLE", false,-1, 31,0);
    tracep->declBus(c+697,"STATE_LEVEL_FIRST", false,-1, 31,0);
    tracep->declBus(c+696,"STATE_LEVEL_SECOND", false,-1, 31,0);
    tracep->declBus(c+712,"STATE_UPDATE", false,-1, 31,0);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_mul ");
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+71,"opcode_valid_i", false,-1);
    tracep->declBus(c+415,"opcode_opcode_i", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_i", false,-1, 31,0);
    tracep->declBit(c+686,"opcode_invalid_i", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_i", false,-1, 4,0);
    tracep->declBus(c+417,"opcode_ra_idx_i", false,-1, 4,0);
    tracep->declBus(c+406,"opcode_rb_idx_i", false,-1, 4,0);
    tracep->declBus(c+75,"opcode_ra_operand_i", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_i", false,-1, 31,0);
    tracep->declBit(c+76,"hold_i", false,-1);
    tracep->declBus(c+446,"writeback_value_o", false,-1, 31,0);
    tracep->declBus(c+696,"MULT_STAGES", false,-1, 31,0);
    tracep->declBus(c+446,"result_e2_q", false,-1, 31,0);
    tracep->declBus(c+539,"result_e3_q", false,-1, 31,0);
    tracep->declQuad(c+540,"operand_a_e1_q", false,-1, 32,0);
    tracep->declQuad(c+542,"operand_b_e1_q", false,-1, 32,0);
    tracep->declBit(c+544,"mulhi_sel_e1_q", false,-1);
    tracep->declArray(c+545,"mult_result_w", false,-1, 64,0);
    tracep->declQuad(c+208,"operand_b_r", false,-1, 32,0);
    tracep->declQuad(c+210,"operand_a_r", false,-1, 32,0);
    tracep->declBus(c+548,"result_r", false,-1, 31,0);
    tracep->declBit(c+409,"mult_inst_w", false,-1);
    tracep->popNamePrefix(1);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+292,"mem_addr_i", false,-1, 31,0);
    tracep->declBus(c+297,"mem_data_wr_i", false,-1, 31,0);
    tracep->declBit(c+44,"mem_rd_i", false,-1);
    tracep->declBus(c+187,"mem_wr_i", false,-1, 3,0);
    tracep->declBit(c+294,"mem_cacheable_i", false,-1);
    tracep->declBus(c+694,"mem_req_tag_i", false,-1, 10,0);
    tracep->declBit(c+301,"mem_invalidate_i", false,-1);
    tracep->declBit(c+318,"mem_writeback_i", false,-1);
    tracep->declBit(c+309,"mem_flush_i", false,-1);
    tracep->declBit(c+299,"outport_accept_i", false,-1);
    tracep->declBit(c+37,"outport_ack_i", false,-1);
    tracep->declBit(c+192,"outport_error_i", false,-1);
    tracep->declBus(c+21,"outport_read_data_i", false,-1, 31,0);
    tracep->declBus(c+304,"mem_data_rd_o", false,-1, 31,0);
    tracep->declBit(c+36,"mem_accept_o", false,-1);
    tracep->declBit(c+317,"mem_ack_o", false,-1);
    tracep->declBit(c+316,"mem_error_o", false,-1);
    tracep->declBus(c+307,"mem_resp_tag_o", false,-1, 10,0);
    tracep->declBus(c+311,"outport_wr_o", false,-1, 3,0);
    tracep->declBit(c+39,"outport_rd_o", false,-1);
    tracep->declBus(c+35,"outport_len_o", false,-1, 7,0);
    tracep->declBus(c+38,"outport_addr_o", false,-1, 31,0);
    tracep->declBus(c+315,"outport_write_data_o", false,-1, 31,0);
    tracep->declBus(c+696,"DCACHE_NUM_WAYS", false,-1, 31,0);
    tracep->declBus(c+700,"DCACHE_NUM_LINES", false,-1, 31,0);
    tracep->declBus(c+701,"DCACHE_LINE_ADDR_W", false,-1, 31,0);
    tracep->declBus(c+702,"DCACHE_LINE_SIZE_W", false,-1, 31,0);
    tracep->declBus(c+703,"DCACHE_LINE_SIZE", false,-1, 31,0);
    tracep->declBus(c+701,"DCACHE_LINE_WORDS", false,-1, 31,0);
    tracep->declBus(c+702,"DCACHE_TAG_REQ_LINE_L", false,-1, 31,0);
    tracep->declBus(c+704,"DCACHE_TAG_REQ_LINE_H", false,-1, 31,0);
    tracep->declBus(c+701,"DCACHE_TAG_REQ_LINE_W", false,-1, 31,0);
    tracep->declBus(c+705,"CACHE_TAG_ADDR_BITS", false,-1, 31,0);
    tracep->declBus(c+705,"CACHE_TAG_DIRTY_BIT", false,-1, 31,0);
    tracep->declBus(c+706,"CACHE_TAG_VALID_BIT", false,-1, 31,0);
    tracep->declBus(c+713,"CACHE_TAG_DATA_W", false,-1, 31,0);
    tracep->declBus(c+707,"DCACHE_TAG_CMP_ADDR_L", false,-1, 31,0);
    tracep->declBus(c+708,"DCACHE_TAG_CMP_ADDR_H", false,-1, 31,0);
    tracep->declBus(c+705,"DCACHE_TAG_CMP_ADDR_W", false,-1, 31,0);
    tracep->declBus(c+714,"STATE_W", false,-1, 31,0);
    tracep->declBus(c+688,"STATE_RESET", false,-1, 3,0);
    tracep->declBus(c+715,"STATE_FLUSH_ADDR", false,-1, 3,0);
    tracep->declBus(c+716,"STATE_FLUSH", false,-1, 3,0);
    tracep->declBus(c+717,"STATE_LOOKUP", false,-1, 3,0);
    tracep->declBus(c+718,"STATE_READ", false,-1, 3,0);
    tracep->declBus(c+719,"STATE_WRITE", false,-1, 3,0);
    tracep->declBus(c+720,"STATE_REFILL", false,-1, 3,0);
    tracep->declBus(c+721,"STATE_EVICT", false,-1, 3,0);
    tracep->declBus(c+722,"STATE_EVICT_WAIT", false,-1, 3,0);
    tracep->declBus(c+723,"STATE_INVALIDATE", false,-1, 3,0);
    tracep->declBus(c+724,"STATE_WRITEBACK", false,-1, 3,0);
    tracep->declBus(c+110,"next_state_r", false,-1, 3,0);
    tracep->declBus(c+549,"state_q", false,-1, 3,0);
    tracep->declBus(c+550,"mem_addr_m_q", false,-1, 31,0);
    tracep->declBus(c+551,"mem_data_m_q", false,-1, 31,0);
    tracep->declBus(c+552,"mem_wr_m_q", false,-1, 3,0);
    tracep->declBit(c+553,"mem_rd_m_q", false,-1);
    tracep->declBus(c+307,"mem_tag_m_q", false,-1, 10,0);
    tracep->declBit(c+554,"mem_inval_m_q", false,-1);
    tracep->declBit(c+555,"mem_writeback_m_q", false,-1);
    tracep->declBit(c+556,"mem_flush_m_q", false,-1);
    tracep->declBit(c+36,"mem_accept_r", false,-1);
    tracep->declBus(c+557,"req_addr_tag_cmp_m_w", false,-1, 18,0);
    tracep->declBus(c+558,"replace_way_q", false,-1, 0,0);
    tracep->declBus(c+311,"pmem_wr_w", false,-1, 3,0);
    tracep->declBit(c+39,"pmem_rd_w", false,-1);
    tracep->declBus(c+35,"pmem_len_w", false,-1, 7,0);
    tracep->declBit(c+559,"pmem_last_w", false,-1);
    tracep->declBus(c+38,"pmem_addr_w", false,-1, 31,0);
    tracep->declBus(c+315,"pmem_write_data_w", false,-1, 31,0);
    tracep->declBit(c+299,"pmem_accept_w", false,-1);
    tracep->declBit(c+37,"pmem_ack_w", false,-1);
    tracep->declBit(c+192,"pmem_error_w", false,-1);
    tracep->declBus(c+21,"pmem_read_data_w", false,-1, 31,0);
    tracep->declBit(c+560,"evict_way_w", false,-1);
    tracep->declBit(c+682,"tag_dirty_any_m_w", false,-1);
    tracep->declBit(c+683,"tag_hit_and_dirty_m_w", false,-1);
    tracep->declBit(c+561,"flushing_q", false,-1);
    tracep->declBus(c+111,"tag_addr_x_r", false,-1, 7,0);
    tracep->declBus(c+562,"tag_addr_m_r", false,-1, 7,0);
    tracep->declBus(c+563,"tag_data_in_m_r", false,-1, 20,0);
    tracep->declBit(c+112,"tag0_write_m_r", false,-1);
    tracep->declBus(c+232,"tag0_data_out_m_w", false,-1, 20,0);
    tracep->declBit(c+233,"tag0_valid_m_w", false,-1);
    tracep->declBit(c+234,"tag0_dirty_m_w", false,-1);
    tracep->declBus(c+235,"tag0_addr_bits_m_w", false,-1, 18,0);
    tracep->declBit(c+564,"tag0_hit_m_w", false,-1);
    tracep->declBit(c+113,"tag1_write_m_r", false,-1);
    tracep->declBus(c+236,"tag1_data_out_m_w", false,-1, 20,0);
    tracep->declBit(c+237,"tag1_valid_m_w", false,-1);
    tracep->declBit(c+238,"tag1_dirty_m_w", false,-1);
    tracep->declBus(c+239,"tag1_addr_bits_m_w", false,-1, 18,0);
    tracep->declBit(c+565,"tag1_hit_m_w", false,-1);
    tracep->declBit(c+566,"tag_hit_any_m_w", false,-1);
    tracep->declBus(c+725,"EVICT_ADDR_W", false,-1, 31,0);
    tracep->declBit(c+567,"evict_way_r", false,-1);
    tracep->declBus(c+568,"evict_data_r", false,-1, 31,0);
    tracep->declBus(c+569,"evict_addr_r", false,-1, 26,0);
    tracep->declBus(c+569,"evict_addr_w", false,-1, 26,0);
    tracep->declBus(c+568,"evict_data_w", false,-1, 31,0);
    tracep->declBus(c+699,"CACHE_DATA_ADDR_W", false,-1, 31,0);
    tracep->declBus(c+114,"data_addr_x_r", false,-1, 10,0);
    tracep->declBus(c+115,"data_addr_m_r", false,-1, 10,0);
    tracep->declBus(c+570,"data_write_addr_q", false,-1, 10,0);
    tracep->declBus(c+116,"data0_write_m_r", false,-1, 3,0);
    tracep->declBus(c+240,"data0_data_out_m_w", false,-1, 31,0);
    tracep->declBus(c+212,"data0_data_in_m_w", false,-1, 31,0);
    tracep->declBus(c+117,"data1_write_m_r", false,-1, 3,0);
    tracep->declBus(c+241,"data1_data_out_m_w", false,-1, 31,0);
    tracep->declBus(c+212,"data1_data_in_m_w", false,-1, 31,0);
    tracep->declBus(c+571,"flush_addr_q", false,-1, 7,0);
    tracep->declBit(c+572,"flush_last_q", false,-1);
    tracep->declBus(c+304,"data_r", false,-1, 31,0);
    tracep->declBit(c+317,"mem_ack_r", false,-1);
    tracep->declBit(c+573,"pmem_rd_q", false,-1);
    tracep->declBit(c+574,"pmem_wr0_q", false,-1);
    tracep->declBus(c+575,"pmem_len_q", false,-1, 7,0);
    tracep->declBus(c+576,"pmem_addr_q", false,-1, 31,0);
    tracep->declBus(c+577,"pmem_wr_q", false,-1, 3,0);
    tracep->declBus(c+578,"pmem_write_data_q", false,-1, 31,0);
    tracep->declBit(c+316,"error_q", false,-1);
    tracep->declBit(c+118,"refill_request_w", false,-1);
    tracep->declBit(c+579,"evict_request_w", false,-1);
    tracep->declArray(c+580,"dbg_state", false,-1, 79,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_issue__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_issue__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+697,"SUPPORT_MULDIV", false,-1, 31,0);
    tracep->declBus(c+697,"SUPPORT_DUAL_ISSUE", false,-1, 31,0);
    tracep->declBus(c+697,"SUPPORT_LOAD_BYPASS", false,-1, 31,0);
    tracep->declBus(c+697,"SUPPORT_MUL_BYPASS", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_REGFILE_XILINX", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+422,"fetch_valid_i", false,-1);
    tracep->declBus(c+415,"fetch_instr_i", false,-1, 31,0);
    tracep->declBus(c+402,"fetch_pc_i", false,-1, 31,0);
    tracep->declBit(c+421,"fetch_fault_fetch_i", false,-1);
    tracep->declBit(c+414,"fetch_fault_page_i", false,-1);
    tracep->declBit(c+434,"fetch_instr_exec_i", false,-1);
    tracep->declBit(c+427,"fetch_instr_lsu_i", false,-1);
    tracep->declBit(c+430,"fetch_instr_branch_i", false,-1);
    tracep->declBit(c+409,"fetch_instr_mul_i", false,-1);
    tracep->declBit(c+444,"fetch_instr_div_i", false,-1);
    tracep->declBit(c+441,"fetch_instr_csr_i", false,-1);
    tracep->declBit(c+445,"fetch_instr_rd_valid_i", false,-1);
    tracep->declBit(c+416,"fetch_instr_invalid_i", false,-1);
    tracep->declBit(c+424,"branch_exec_request_i", false,-1);
    tracep->declBit(c+420,"branch_exec_is_taken_i", false,-1);
    tracep->declBit(c+418,"branch_exec_is_not_taken_i", false,-1);
    tracep->declBus(c+403,"branch_exec_source_i", false,-1, 31,0);
    tracep->declBit(c+450,"branch_exec_is_call_i", false,-1);
    tracep->declBit(c+410,"branch_exec_is_ret_i", false,-1);
    tracep->declBit(c+440,"branch_exec_is_jmp_i", false,-1);
    tracep->declBus(c+419,"branch_exec_pc_i", false,-1, 31,0);
    tracep->declBit(c+77,"branch_d_exec_request_i", false,-1);
    tracep->declBus(c+79,"branch_d_exec_pc_i", false,-1, 31,0);
    tracep->declBus(c+690,"branch_d_exec_priv_i", false,-1, 1,0);
    tracep->declBit(c+405,"branch_csr_request_i", false,-1);
    tracep->declBus(c+413,"branch_csr_pc_i", false,-1, 31,0);
    tracep->declBus(c+423,"branch_csr_priv_i", false,-1, 1,0);
    tracep->declBus(c+448,"writeback_exec_value_i", false,-1, 31,0);
    tracep->declBit(c+74,"writeback_mem_valid_i", false,-1);
    tracep->declBus(c+78,"writeback_mem_value_i", false,-1, 31,0);
    tracep->declBus(c+204,"writeback_mem_exception_i", false,-1, 5,0);
    tracep->declBus(c+446,"writeback_mul_value_i", false,-1, 31,0);
    tracep->declBit(c+429,"writeback_div_valid_i", false,-1);
    tracep->declBus(c+404,"writeback_div_value_i", false,-1, 31,0);
    tracep->declBus(c+438,"csr_result_e1_value_i", false,-1, 31,0);
    tracep->declBit(c+443,"csr_result_e1_write_i", false,-1);
    tracep->declBus(c+432,"csr_result_e1_wdata_i", false,-1, 31,0);
    tracep->declBus(c+412,"csr_result_e1_exception_i", false,-1, 5,0);
    tracep->declBit(c+203,"lsu_stall_i", false,-1);
    tracep->declBit(c+437,"take_interrupt_i", false,-1);
    tracep->declBit(c+68,"fetch_accept_o", false,-1);
    tracep->declBit(c+73,"branch_request_o", false,-1);
    tracep->declBus(c+202,"branch_pc_o", false,-1, 31,0);
    tracep->declBus(c+425,"branch_priv_o", false,-1, 1,0);
    tracep->declBit(c+71,"exec_opcode_valid_o", false,-1);
    tracep->declBit(c+70,"lsu_opcode_valid_o", false,-1);
    tracep->declBit(c+70,"csr_opcode_valid_o", false,-1);
    tracep->declBit(c+71,"mul_opcode_valid_o", false,-1);
    tracep->declBit(c+71,"div_opcode_valid_o", false,-1);
    tracep->declBus(c+415,"opcode_opcode_o", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_o", false,-1, 31,0);
    tracep->declBit(c+686,"opcode_invalid_o", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_o", false,-1, 4,0);
    tracep->declBus(c+417,"opcode_ra_idx_o", false,-1, 4,0);
    tracep->declBus(c+406,"opcode_rb_idx_o", false,-1, 4,0);
    tracep->declBus(c+75,"opcode_ra_operand_o", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_o", false,-1, 31,0);
    tracep->declBus(c+415,"lsu_opcode_opcode_o", false,-1, 31,0);
    tracep->declBus(c+402,"lsu_opcode_pc_o", false,-1, 31,0);
    tracep->declBit(c+686,"lsu_opcode_invalid_o", false,-1);
    tracep->declBus(c+400,"lsu_opcode_rd_idx_o", false,-1, 4,0);
    tracep->declBus(c+417,"lsu_opcode_ra_idx_o", false,-1, 4,0);
    tracep->declBus(c+406,"lsu_opcode_rb_idx_o", false,-1, 4,0);
    tracep->declBus(c+75,"lsu_opcode_ra_operand_o", false,-1, 31,0);
    tracep->declBus(c+69,"lsu_opcode_rb_operand_o", false,-1, 31,0);
    tracep->declBus(c+415,"mul_opcode_opcode_o", false,-1, 31,0);
    tracep->declBus(c+402,"mul_opcode_pc_o", false,-1, 31,0);
    tracep->declBit(c+686,"mul_opcode_invalid_o", false,-1);
    tracep->declBus(c+400,"mul_opcode_rd_idx_o", false,-1, 4,0);
    tracep->declBus(c+417,"mul_opcode_ra_idx_o", false,-1, 4,0);
    tracep->declBus(c+406,"mul_opcode_rb_idx_o", false,-1, 4,0);
    tracep->declBus(c+75,"mul_opcode_ra_operand_o", false,-1, 31,0);
    tracep->declBus(c+69,"mul_opcode_rb_operand_o", false,-1, 31,0);
    tracep->declBus(c+415,"csr_opcode_opcode_o", false,-1, 31,0);
    tracep->declBus(c+402,"csr_opcode_pc_o", false,-1, 31,0);
    tracep->declBit(c+72,"csr_opcode_invalid_o", false,-1);
    tracep->declBus(c+400,"csr_opcode_rd_idx_o", false,-1, 4,0);
    tracep->declBus(c+417,"csr_opcode_ra_idx_o", false,-1, 4,0);
    tracep->declBus(c+406,"csr_opcode_rb_idx_o", false,-1, 4,0);
    tracep->declBus(c+75,"csr_opcode_ra_operand_o", false,-1, 31,0);
    tracep->declBus(c+69,"csr_opcode_rb_operand_o", false,-1, 31,0);
    tracep->declBit(c+436,"csr_writeback_write_o", false,-1);
    tracep->declBus(c+439,"csr_writeback_waddr_o", false,-1, 11,0);
    tracep->declBus(c+435,"csr_writeback_wdata_o", false,-1, 31,0);
    tracep->declBus(c+408,"csr_writeback_exception_o", false,-1, 5,0);
    tracep->declBus(c+449,"csr_writeback_exception_pc_o", false,-1, 31,0);
    tracep->declBus(c+411,"csr_writeback_exception_addr_o", false,-1, 31,0);
    tracep->declBit(c+76,"exec_hold_o", false,-1);
    tracep->declBit(c+76,"mul_hold_o", false,-1);
    tracep->declBit(c+426,"interrupt_inhibit_o", false,-1);
    tracep->declBit(c+693,"enable_muldiv_w", false,-1);
    tracep->declBit(c+693,"enable_mul_bypass_w", false,-1);
    tracep->declBit(c+76,"stall_w", false,-1);
    tracep->declBit(c+119,"squash_w", false,-1);
    tracep->declBus(c+583,"priv_x_q", false,-1, 1,0);
    tracep->declBit(c+120,"opcode_valid_w", false,-1);
    tracep->declBus(c+417,"issue_ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+406,"issue_rb_idx_w", false,-1, 4,0);
    tracep->declBus(c+400,"issue_rd_idx_w", false,-1, 4,0);
    tracep->declBit(c+445,"issue_sb_alloc_w", false,-1);
    tracep->declBit(c+434,"issue_exec_w", false,-1);
    tracep->declBit(c+427,"issue_lsu_w", false,-1);
    tracep->declBit(c+430,"issue_branch_w", false,-1);
    tracep->declBit(c+409,"issue_mul_w", false,-1);
    tracep->declBit(c+444,"issue_div_w", false,-1);
    tracep->declBit(c+441,"issue_csr_w", false,-1);
    tracep->declBit(c+416,"issue_invalid_w", false,-1);
    tracep->declBit(c+119,"pipe_squash_e1_e2_w", false,-1);
    tracep->declBit(c+71,"opcode_issue_r", false,-1);
    tracep->declBit(c+121,"opcode_accept_r", false,-1);
    tracep->declBit(c+76,"pipe_stall_raw_w", false,-1);
    tracep->declBit(c+584,"pipe_load_e1_w", false,-1);
    tracep->declBit(c+585,"pipe_store_e1_w", false,-1);
    tracep->declBit(c+586,"pipe_mul_e1_w", false,-1);
    tracep->declBit(c+587,"pipe_branch_e1_w", false,-1);
    tracep->declBus(c+588,"pipe_rd_e1_w", false,-1, 4,0);
    tracep->declBus(c+589,"pipe_pc_e1_w", false,-1, 31,0);
    tracep->declBus(c+590,"pipe_opcode_e1_w", false,-1, 31,0);
    tracep->declBus(c+591,"pipe_operand_ra_e1_w", false,-1, 31,0);
    tracep->declBus(c+592,"pipe_operand_rb_e1_w", false,-1, 31,0);
    tracep->declBit(c+593,"pipe_load_e2_w", false,-1);
    tracep->declBit(c+594,"pipe_mul_e2_w", false,-1);
    tracep->declBus(c+122,"pipe_rd_e2_w", false,-1, 4,0);
    tracep->declBus(c+123,"pipe_result_e2_w", false,-1, 31,0);
    tracep->declBit(c+124,"pipe_valid_wb_w", false,-1);
    tracep->declBit(c+213,"pipe_csr_wb_w", false,-1);
    tracep->declBus(c+125,"pipe_rd_wb_w", false,-1, 4,0);
    tracep->declBus(c+411,"pipe_result_wb_w", false,-1, 31,0);
    tracep->declBus(c+449,"pipe_pc_wb_w", false,-1, 31,0);
    tracep->declBus(c+595,"pipe_opc_wb_w", false,-1, 31,0);
    tracep->declBus(c+596,"pipe_ra_val_wb_w", false,-1, 31,0);
    tracep->declBus(c+597,"pipe_rb_val_wb_w", false,-1, 31,0);
    tracep->declBus(c+408,"pipe_exception_wb_w", false,-1, 5,0);
    tracep->declBus(c+598,"issue_fault_w", false,-1, 5,0);
    tracep->declBit(c+599,"div_pending_q", false,-1);
    tracep->declBit(c+600,"csr_pending_q", false,-1);
    tracep->declBus(c+126,"scoreboard_r", false,-1, 31,0);
    tracep->declBus(c+601,"issue_ra_value_w", false,-1, 31,0);
    tracep->declBus(c+602,"issue_rb_value_w", false,-1, 31,0);
    tracep->declBus(c+726,"issue_b_ra_value_w", false,-1, 31,0);
    tracep->declBus(c+727,"issue_b_rb_value_w", false,-1, 31,0);
    tracep->declBus(c+75,"issue_ra_value_r", false,-1, 31,0);
    tracep->declBus(c+69,"issue_rb_value_r", false,-1, 31,0);
    tracep->declBus(c+603,"v_pipe_rs1_w", false,-1, 4,0);
    tracep->declBus(c+604,"v_pipe_rs2_w", false,-1, 4,0);
    tracep->pushNamePrefix("u_pipe_ctrl ");
    tracep->declBus(c+697,"SUPPORT_LOAD_BYPASS", false,-1, 31,0);
    tracep->declBus(c+697,"SUPPORT_MUL_BYPASS", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+71,"issue_valid_i", false,-1);
    tracep->declBit(c+121,"issue_accept_i", false,-1);
    tracep->declBit(c+76,"issue_stall_i", false,-1);
    tracep->declBit(c+427,"issue_lsu_i", false,-1);
    tracep->declBit(c+441,"issue_csr_i", false,-1);
    tracep->declBit(c+444,"issue_div_i", false,-1);
    tracep->declBit(c+409,"issue_mul_i", false,-1);
    tracep->declBit(c+430,"issue_branch_i", false,-1);
    tracep->declBit(c+445,"issue_rd_valid_i", false,-1);
    tracep->declBus(c+400,"issue_rd_i", false,-1, 4,0);
    tracep->declBus(c+598,"issue_exception_i", false,-1, 5,0);
    tracep->declBit(c+437,"take_interrupt_i", false,-1);
    tracep->declBit(c+77,"issue_branch_taken_i", false,-1);
    tracep->declBus(c+79,"issue_branch_target_i", false,-1, 31,0);
    tracep->declBus(c+402,"issue_pc_i", false,-1, 31,0);
    tracep->declBus(c+415,"issue_opcode_i", false,-1, 31,0);
    tracep->declBus(c+75,"issue_operand_ra_i", false,-1, 31,0);
    tracep->declBus(c+69,"issue_operand_rb_i", false,-1, 31,0);
    tracep->declBus(c+448,"alu_result_e1_i", false,-1, 31,0);
    tracep->declBus(c+438,"csr_result_value_e1_i", false,-1, 31,0);
    tracep->declBit(c+443,"csr_result_write_e1_i", false,-1);
    tracep->declBus(c+432,"csr_result_wdata_e1_i", false,-1, 31,0);
    tracep->declBus(c+412,"csr_result_exception_e1_i", false,-1, 5,0);
    tracep->declBit(c+584,"load_e1_o", false,-1);
    tracep->declBit(c+585,"store_e1_o", false,-1);
    tracep->declBit(c+586,"mul_e1_o", false,-1);
    tracep->declBit(c+587,"branch_e1_o", false,-1);
    tracep->declBus(c+588,"rd_e1_o", false,-1, 4,0);
    tracep->declBus(c+589,"pc_e1_o", false,-1, 31,0);
    tracep->declBus(c+590,"opcode_e1_o", false,-1, 31,0);
    tracep->declBus(c+591,"operand_ra_e1_o", false,-1, 31,0);
    tracep->declBus(c+592,"operand_rb_e1_o", false,-1, 31,0);
    tracep->declBit(c+74,"mem_complete_i", false,-1);
    tracep->declBus(c+78,"mem_result_e2_i", false,-1, 31,0);
    tracep->declBus(c+204,"mem_exception_e2_i", false,-1, 5,0);
    tracep->declBus(c+446,"mul_result_e2_i", false,-1, 31,0);
    tracep->declBit(c+593,"load_e2_o", false,-1);
    tracep->declBit(c+594,"mul_e2_o", false,-1);
    tracep->declBus(c+122,"rd_e2_o", false,-1, 4,0);
    tracep->declBus(c+123,"result_e2_o", false,-1, 31,0);
    tracep->declBit(c+429,"div_complete_i", false,-1);
    tracep->declBus(c+404,"div_result_i", false,-1, 31,0);
    tracep->declBit(c+124,"valid_wb_o", false,-1);
    tracep->declBit(c+213,"csr_wb_o", false,-1);
    tracep->declBus(c+125,"rd_wb_o", false,-1, 4,0);
    tracep->declBus(c+411,"result_wb_o", false,-1, 31,0);
    tracep->declBus(c+449,"pc_wb_o", false,-1, 31,0);
    tracep->declBus(c+595,"opcode_wb_o", false,-1, 31,0);
    tracep->declBus(c+596,"operand_ra_wb_o", false,-1, 31,0);
    tracep->declBus(c+597,"operand_rb_wb_o", false,-1, 31,0);
    tracep->declBus(c+408,"exception_wb_o", false,-1, 5,0);
    tracep->declBit(c+436,"csr_write_wb_o", false,-1);
    tracep->declBus(c+439,"csr_waddr_wb_o", false,-1, 11,0);
    tracep->declBus(c+435,"csr_wdata_wb_o", false,-1, 31,0);
    tracep->declBit(c+76,"stall_o", false,-1);
    tracep->declBit(c+119,"squash_e1_e2_o", false,-1);
    tracep->declBit(c+686,"squash_e1_e2_i", false,-1);
    tracep->declBit(c+686,"squash_wb_i", false,-1);
    tracep->declBit(c+127,"squash_e1_e2_w", false,-1);
    tracep->declBit(c+128,"branch_misaligned_w", false,-1);
    tracep->declBit(c+605,"valid_e1_q", false,-1);
    tracep->declBus(c+606,"ctrl_e1_q", false,-1, 9,0);
    tracep->declBus(c+589,"pc_e1_q", false,-1, 31,0);
    tracep->declBus(c+607,"npc_e1_q", false,-1, 31,0);
    tracep->declBus(c+590,"opcode_e1_q", false,-1, 31,0);
    tracep->declBus(c+591,"operand_ra_e1_q", false,-1, 31,0);
    tracep->declBus(c+592,"operand_rb_e1_q", false,-1, 31,0);
    tracep->declBus(c+608,"exception_e1_q", false,-1, 5,0);
    tracep->declBit(c+609,"alu_e1_w", false,-1);
    tracep->declBit(c+610,"csr_e1_w", false,-1);
    tracep->declBit(c+611,"div_e1_w", false,-1);
    tracep->declBit(c+612,"valid_e2_q", false,-1);
    tracep->declBus(c+613,"ctrl_e2_q", false,-1, 9,0);
    tracep->declBit(c+614,"csr_wr_e2_q", false,-1);
    tracep->declBus(c+615,"csr_wdata_e2_q", false,-1, 31,0);
    tracep->declBus(c+616,"result_e2_q", false,-1, 31,0);
    tracep->declBus(c+617,"pc_e2_q", false,-1, 31,0);
    tracep->declBus(c+618,"npc_e2_q", false,-1, 31,0);
    tracep->declBus(c+619,"opcode_e2_q", false,-1, 31,0);
    tracep->declBus(c+620,"operand_ra_e2_q", false,-1, 31,0);
    tracep->declBus(c+621,"operand_rb_e2_q", false,-1, 31,0);
    tracep->declBus(c+622,"exception_e2_q", false,-1, 5,0);
    tracep->declBus(c+123,"result_e2_r", false,-1, 31,0);
    tracep->declBit(c+129,"valid_e2_w", false,-1);
    tracep->declBit(c+623,"load_store_e2_w", false,-1);
    tracep->declBus(c+130,"exception_e2_r", false,-1, 5,0);
    tracep->declBit(c+624,"squash_e1_e2_q", false,-1);
    tracep->declBit(c+625,"valid_wb_q", false,-1);
    tracep->declBus(c+626,"ctrl_wb_q", false,-1, 9,0);
    tracep->declBit(c+436,"csr_wr_wb_q", false,-1);
    tracep->declBus(c+435,"csr_wdata_wb_q", false,-1, 31,0);
    tracep->declBus(c+411,"result_wb_q", false,-1, 31,0);
    tracep->declBus(c+449,"pc_wb_q", false,-1, 31,0);
    tracep->declBus(c+627,"npc_wb_q", false,-1, 31,0);
    tracep->declBus(c+595,"opcode_wb_q", false,-1, 31,0);
    tracep->declBus(c+596,"operand_ra_wb_q", false,-1, 31,0);
    tracep->declBus(c+597,"operand_rb_wb_q", false,-1, 31,0);
    tracep->declBus(c+408,"exception_wb_q", false,-1, 5,0);
    tracep->declBit(c+214,"complete_wb_w", false,-1);
    tracep->pushNamePrefix("u_trace_d ");
    tracep->declBit(c+71,"valid_i", false,-1);
    tracep->declBus(c+402,"pc_i", false,-1, 31,0);
    tracep->declBus(c+415,"opcode_i", false,-1, 31,0);
    tracep->declArray(c+131,"dbg_inst_str", false,-1, 79,0);
    tracep->declArray(c+134,"dbg_inst_ra", false,-1, 79,0);
    tracep->declArray(c+137,"dbg_inst_rb", false,-1, 79,0);
    tracep->declArray(c+140,"dbg_inst_rd", false,-1, 79,0);
    tracep->declBus(c+143,"dbg_inst_imm", false,-1, 31,0);
    tracep->declBus(c+144,"dbg_inst_pc", false,-1, 31,0);
    tracep->declBus(c+417,"ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+406,"rb_idx_w", false,-1, 4,0);
    tracep->declBus(c+400,"rd_idx_w", false,-1, 4,0);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_trace_wb ");
    tracep->declBit(c+124,"valid_i", false,-1);
    tracep->declBus(c+449,"pc_i", false,-1, 31,0);
    tracep->declBus(c+595,"opcode_i", false,-1, 31,0);
    tracep->declArray(c+145,"dbg_inst_str", false,-1, 79,0);
    tracep->declArray(c+148,"dbg_inst_ra", false,-1, 79,0);
    tracep->declArray(c+151,"dbg_inst_rb", false,-1, 79,0);
    tracep->declArray(c+154,"dbg_inst_rd", false,-1, 79,0);
    tracep->declBus(c+157,"dbg_inst_imm", false,-1, 31,0);
    tracep->declBus(c+158,"dbg_inst_pc", false,-1, 31,0);
    tracep->declBus(c+603,"ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+604,"rb_idx_w", false,-1, 4,0);
    tracep->declBus(c+628,"rd_idx_w", false,-1, 4,0);
    tracep->popNamePrefix(2);
    tracep->pushNamePrefix("u_pipe_dec0_verif ");
    tracep->declBit(c+124,"valid_i", false,-1);
    tracep->declBus(c+449,"pc_i", false,-1, 31,0);
    tracep->declBus(c+595,"opcode_i", false,-1, 31,0);
    tracep->declArray(c+159,"dbg_inst_str", false,-1, 79,0);
    tracep->declArray(c+162,"dbg_inst_ra", false,-1, 79,0);
    tracep->declArray(c+165,"dbg_inst_rb", false,-1, 79,0);
    tracep->declArray(c+168,"dbg_inst_rd", false,-1, 79,0);
    tracep->declBus(c+171,"dbg_inst_imm", false,-1, 31,0);
    tracep->declBus(c+172,"dbg_inst_pc", false,-1, 31,0);
    tracep->declBus(c+603,"ra_idx_w", false,-1, 4,0);
    tracep->declBus(c+604,"rb_idx_w", false,-1, 4,0);
    tracep->declBus(c+628,"rd_idx_w", false,-1, 4,0);
    tracep->popNamePrefix(1);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_tag0__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_tag0__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+390,"addr_i", false,-1, 7,0);
    tracep->declBus(c+391,"data_i", false,-1, 19,0);
    tracep->declBit(c+66,"wr_i", false,-1);
    tracep->declBus(c+224,"data_o", false,-1, 19,0);
    tracep->declBus(c+224,"ram_read_q", false,-1, 19,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_tag1__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_tag1__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+390,"addr_i", false,-1, 7,0);
    tracep->declBus(c+391,"data_i", false,-1, 19,0);
    tracep->declBit(c+67,"wr_i", false,-1);
    tracep->declBus(c+227,"data_o", false,-1, 19,0);
    tracep->declBus(c+227,"ram_read_q", false,-1, 19,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_data0__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_data0__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+395,"addr_i", false,-1, 10,0);
    tracep->declBus(c+10,"data_i", false,-1, 31,0);
    tracep->declBit(c+200,"wr_i", false,-1);
    tracep->declBus(c+230,"data_o", false,-1, 31,0);
    tracep->declBus(c+230,"ram_read_q", false,-1, 31,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_data1__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_data1__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+395,"addr_i", false,-1, 10,0);
    tracep->declBus(c+10,"data_i", false,-1, 31,0);
    tracep->declBit(c+201,"wr_i", false,-1);
    tracep->declBus(c+231,"data_o", false,-1, 31,0);
    tracep->declBus(c+231,"ram_read_q", false,-1, 31,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_csr__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_csr__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+697,"SUPPORT_MULDIV", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_SUPER", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+25,"intr_i", false,-1);
    tracep->declBit(c+70,"opcode_valid_i", false,-1);
    tracep->declBus(c+415,"opcode_opcode_i", false,-1, 31,0);
    tracep->declBus(c+402,"opcode_pc_i", false,-1, 31,0);
    tracep->declBit(c+72,"opcode_invalid_i", false,-1);
    tracep->declBus(c+400,"opcode_rd_idx_i", false,-1, 4,0);
    tracep->declBus(c+417,"opcode_ra_idx_i", false,-1, 4,0);
    tracep->declBus(c+406,"opcode_rb_idx_i", false,-1, 4,0);
    tracep->declBus(c+75,"opcode_ra_operand_i", false,-1, 31,0);
    tracep->declBus(c+69,"opcode_rb_operand_i", false,-1, 31,0);
    tracep->declBit(c+436,"csr_writeback_write_i", false,-1);
    tracep->declBus(c+439,"csr_writeback_waddr_i", false,-1, 11,0);
    tracep->declBus(c+435,"csr_writeback_wdata_i", false,-1, 31,0);
    tracep->declBus(c+408,"csr_writeback_exception_i", false,-1, 5,0);
    tracep->declBus(c+449,"csr_writeback_exception_pc_i", false,-1, 31,0);
    tracep->declBus(c+411,"csr_writeback_exception_addr_i", false,-1, 31,0);
    tracep->declBus(c+687,"cpu_id_i", false,-1, 31,0);
    tracep->declBus(c+26,"reset_vector_i", false,-1, 31,0);
    tracep->declBit(c+426,"interrupt_inhibit_i", false,-1);
    tracep->declBus(c+438,"csr_result_e1_value_o", false,-1, 31,0);
    tracep->declBit(c+443,"csr_result_e1_write_o", false,-1);
    tracep->declBus(c+432,"csr_result_e1_wdata_o", false,-1, 31,0);
    tracep->declBus(c+412,"csr_result_e1_exception_o", false,-1, 5,0);
    tracep->declBit(c+405,"branch_csr_request_o", false,-1);
    tracep->declBus(c+413,"branch_csr_pc_o", false,-1, 31,0);
    tracep->declBus(c+423,"branch_csr_priv_o", false,-1, 1,0);
    tracep->declBit(c+437,"take_interrupt_o", false,-1);
    tracep->declBit(c+433,"ifence_o", false,-1);
    tracep->declBus(c+428,"mmu_priv_d_o", false,-1, 1,0);
    tracep->declBit(c+447,"mmu_sum_o", false,-1);
    tracep->declBit(c+407,"mmu_mxr_o", false,-1);
    tracep->declBit(c+401,"mmu_flush_o", false,-1);
    tracep->declBus(c+431,"mmu_satp_o", false,-1, 31,0);
    tracep->declBit(c+215,"ecall_w", false,-1);
    tracep->declBit(c+216,"ebreak_w", false,-1);
    tracep->declBit(c+217,"eret_w", false,-1);
    tracep->declBus(c+629,"eret_priv_w", false,-1, 1,0);
    tracep->declBit(c+173,"csrrw_w", false,-1);
    tracep->declBit(c+218,"csrrs_w", false,-1);
    tracep->declBit(c+219,"csrrc_w", false,-1);
    tracep->declBit(c+174,"csrrwi_w", false,-1);
    tracep->declBit(c+175,"csrrsi_w", false,-1);
    tracep->declBit(c+176,"csrrci_w", false,-1);
    tracep->declBit(c+220,"wfi_w", false,-1);
    tracep->declBit(c+221,"fence_w", false,-1);
    tracep->declBit(c+177,"sfence_w", false,-1);
    tracep->declBit(c+178,"ifence_w", false,-1);
    tracep->declBus(c+630,"current_priv_w", false,-1, 1,0);
    tracep->declBus(c+629,"csr_priv_r", false,-1, 1,0);
    tracep->declBit(c+631,"csr_readonly_r", false,-1);
    tracep->declBit(c+222,"csr_write_r", false,-1);
    tracep->declBit(c+179,"set_r", false,-1);
    tracep->declBit(c+180,"clr_r", false,-1);
    tracep->declBit(c+686,"csr_fault_r", false,-1);
    tracep->declBus(c+181,"data_r", false,-1, 31,0);
    tracep->declBit(c+182,"satp_update_w", false,-1);
    tracep->declBit(c+686,"timer_irq_w", false,-1);
    tracep->declBus(c+728,"misa_w", false,-1, 31,0);
    tracep->declBus(c+632,"csr_rdata_w", false,-1, 31,0);
    tracep->declBit(c+633,"csr_branch_w", false,-1);
    tracep->declBus(c+634,"csr_target_w", false,-1, 31,0);
    tracep->declBus(c+635,"interrupt_w", false,-1, 31,0);
    tracep->declBus(c+636,"status_reg_w", false,-1, 31,0);
    tracep->declBus(c+431,"satp_reg_w", false,-1, 31,0);
    tracep->declBit(c+443,"rd_valid_e1_q", false,-1);
    tracep->declBus(c+438,"rd_result_e1_q", false,-1, 31,0);
    tracep->declBus(c+432,"csr_wdata_e1_q", false,-1, 31,0);
    tracep->declBus(c+412,"exception_e1_q", false,-1, 5,0);
    tracep->declBit(c+183,"eret_fault_w", false,-1);
    tracep->declBit(c+437,"take_interrupt_q", false,-1);
    tracep->declBit(c+401,"tlb_flush_q", false,-1);
    tracep->declBit(c+433,"ifence_q", false,-1);
    tracep->declBit(c+405,"branch_q", false,-1);
    tracep->declBus(c+413,"branch_target_q", false,-1, 31,0);
    tracep->declBit(c+637,"reset_q", false,-1);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_tag0__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_tag0__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk0_i", false,-1);
    tracep->declBit(c+2,"rst0_i", false,-1);
    tracep->declBus(c+111,"addr0_i", false,-1, 7,0);
    tracep->declBit(c+1,"clk1_i", false,-1);
    tracep->declBit(c+2,"rst1_i", false,-1);
    tracep->declBus(c+562,"addr1_i", false,-1, 7,0);
    tracep->declBus(c+563,"data1_i", false,-1, 20,0);
    tracep->declBit(c+112,"wr1_i", false,-1);
    tracep->declBus(c+232,"data0_o", false,-1, 20,0);
    tracep->declBus(c+232,"ram_read0_q", false,-1, 20,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_tag1__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_tag1__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk0_i", false,-1);
    tracep->declBit(c+2,"rst0_i", false,-1);
    tracep->declBus(c+111,"addr0_i", false,-1, 7,0);
    tracep->declBit(c+1,"clk1_i", false,-1);
    tracep->declBit(c+2,"rst1_i", false,-1);
    tracep->declBus(c+562,"addr1_i", false,-1, 7,0);
    tracep->declBus(c+563,"data1_i", false,-1, 20,0);
    tracep->declBit(c+113,"wr1_i", false,-1);
    tracep->declBus(c+236,"data0_o", false,-1, 20,0);
    tracep->declBus(c+236,"ram_read0_q", false,-1, 20,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_data0__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_data0__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk0_i", false,-1);
    tracep->declBit(c+2,"rst0_i", false,-1);
    tracep->declBus(c+114,"addr0_i", false,-1, 10,0);
    tracep->declBus(c+687,"data0_i", false,-1, 31,0);
    tracep->declBus(c+688,"wr0_i", false,-1, 3,0);
    tracep->declBit(c+1,"clk1_i", false,-1);
    tracep->declBit(c+2,"rst1_i", false,-1);
    tracep->declBus(c+115,"addr1_i", false,-1, 10,0);
    tracep->declBus(c+212,"data1_i", false,-1, 31,0);
    tracep->declBus(c+116,"wr1_i", false,-1, 3,0);
    tracep->declBus(c+240,"data0_o", false,-1, 31,0);
    tracep->declBus(c+242,"data1_o", false,-1, 31,0);
    tracep->declBus(c+240,"ram_read0_q", false,-1, 31,0);
    tracep->declBus(c+242,"ram_read1_q", false,-1, 31,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_data1__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_data1__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+1,"clk0_i", false,-1);
    tracep->declBit(c+2,"rst0_i", false,-1);
    tracep->declBus(c+114,"addr0_i", false,-1, 10,0);
    tracep->declBus(c+687,"data0_i", false,-1, 31,0);
    tracep->declBus(c+688,"wr0_i", false,-1, 3,0);
    tracep->declBit(c+1,"clk1_i", false,-1);
    tracep->declBit(c+2,"rst1_i", false,-1);
    tracep->declBus(c+115,"addr1_i", false,-1, 10,0);
    tracep->declBus(c+212,"data1_i", false,-1, 31,0);
    tracep->declBus(c+117,"wr1_i", false,-1, 3,0);
    tracep->declBus(c+241,"data0_o", false,-1, 31,0);
    tracep->declBus(c+243,"data1_o", false,-1, 31,0);
    tracep->declBus(c+241,"ram_read0_q", false,-1, 31,0);
    tracep->declBus(c+243,"ram_read1_q", false,-1, 31,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_csr__u_csrfile__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_csr__u_csrfile__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+697,"SUPPORT_MTIMECMP", false,-1, 31,0);
    tracep->declBus(c+684,"SUPPORT_SUPER", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBit(c+25,"ext_intr_i", false,-1);
    tracep->declBit(c+686,"timer_intr_i", false,-1);
    tracep->declBus(c+687,"cpu_id_i", false,-1, 31,0);
    tracep->declBus(c+728,"misa_i", false,-1, 31,0);
    tracep->declBus(c+408,"exception_i", false,-1, 5,0);
    tracep->declBus(c+449,"exception_pc_i", false,-1, 31,0);
    tracep->declBus(c+411,"exception_addr_i", false,-1, 31,0);
    tracep->declBit(c+70,"csr_ren_i", false,-1);
    tracep->declBus(c+638,"csr_raddr_i", false,-1, 11,0);
    tracep->declBus(c+632,"csr_rdata_o", false,-1, 31,0);
    tracep->declBus(c+639,"csr_waddr_i", false,-1, 11,0);
    tracep->declBus(c+435,"csr_wdata_i", false,-1, 31,0);
    tracep->declBit(c+633,"csr_branch_o", false,-1);
    tracep->declBus(c+634,"csr_target_o", false,-1, 31,0);
    tracep->declBus(c+630,"priv_o", false,-1, 1,0);
    tracep->declBus(c+636,"status_o", false,-1, 31,0);
    tracep->declBus(c+431,"satp_o", false,-1, 31,0);
    tracep->declBus(c+635,"interrupt_o", false,-1, 31,0);
    tracep->declBus(c+640,"csr_mepc_q", false,-1, 31,0);
    tracep->declBus(c+641,"csr_mcause_q", false,-1, 31,0);
    tracep->declBus(c+636,"csr_sr_q", false,-1, 31,0);
    tracep->declBus(c+642,"csr_mtvec_q", false,-1, 31,0);
    tracep->declBus(c+643,"csr_mip_q", false,-1, 31,0);
    tracep->declBus(c+644,"csr_mie_q", false,-1, 31,0);
    tracep->declBus(c+630,"csr_mpriv_q", false,-1, 1,0);
    tracep->declBus(c+645,"csr_mcycle_q", false,-1, 31,0);
    tracep->declBus(c+646,"csr_mcycle_h_q", false,-1, 31,0);
    tracep->declBus(c+647,"csr_mscratch_q", false,-1, 31,0);
    tracep->declBus(c+648,"csr_mtval_q", false,-1, 31,0);
    tracep->declBus(c+649,"csr_mtimecmp_q", false,-1, 31,0);
    tracep->declBit(c+650,"csr_mtime_ie_q", false,-1);
    tracep->declBus(c+651,"csr_medeleg_q", false,-1, 31,0);
    tracep->declBus(c+652,"csr_mideleg_q", false,-1, 31,0);
    tracep->declBus(c+653,"csr_sepc_q", false,-1, 31,0);
    tracep->declBus(c+654,"csr_stvec_q", false,-1, 31,0);
    tracep->declBus(c+655,"csr_scause_q", false,-1, 31,0);
    tracep->declBus(c+656,"csr_stval_q", false,-1, 31,0);
    tracep->declBus(c+431,"csr_satp_q", false,-1, 31,0);
    tracep->declBus(c+657,"csr_sscratch_q", false,-1, 31,0);
    tracep->declBus(c+658,"irq_pending_r", false,-1, 31,0);
    tracep->declBus(c+635,"irq_masked_r", false,-1, 31,0);
    tracep->declBus(c+710,"irq_priv_r", false,-1, 1,0);
    tracep->declBit(c+729,"m_enabled_r", false,-1);
    tracep->declBus(c+730,"m_interrupts_r", false,-1, 31,0);
    tracep->declBit(c+731,"s_enabled_r", false,-1);
    tracep->declBus(c+732,"s_interrupts_r", false,-1, 31,0);
    tracep->declBus(c+659,"irq_priv_q", false,-1, 1,0);
    tracep->declBit(c+660,"csr_mip_upd_q", false,-1);
    tracep->declBit(c+223,"buffer_mip_w", false,-1);
    tracep->declBus(c+632,"rdata_r", false,-1, 31,0);
    tracep->declBus(c+661,"csr_mepc_r", false,-1, 31,0);
    tracep->declBus(c+662,"csr_mcause_r", false,-1, 31,0);
    tracep->declBus(c+663,"csr_mtval_r", false,-1, 31,0);
    tracep->declBus(c+664,"csr_sr_r", false,-1, 31,0);
    tracep->declBus(c+665,"csr_mtvec_r", false,-1, 31,0);
    tracep->declBus(c+184,"csr_mip_r", false,-1, 31,0);
    tracep->declBus(c+666,"csr_mie_r", false,-1, 31,0);
    tracep->declBus(c+667,"csr_mpriv_r", false,-1, 1,0);
    tracep->declBus(c+668,"csr_mcycle_r", false,-1, 31,0);
    tracep->declBus(c+669,"csr_mscratch_r", false,-1, 31,0);
    tracep->declBus(c+670,"csr_mtimecmp_r", false,-1, 31,0);
    tracep->declBit(c+671,"csr_mtime_ie_r", false,-1);
    tracep->declBus(c+672,"csr_medeleg_r", false,-1, 31,0);
    tracep->declBus(c+673,"csr_mideleg_r", false,-1, 31,0);
    tracep->declBus(c+674,"csr_mip_next_q", false,-1, 31,0);
    tracep->declBus(c+185,"csr_mip_next_r", false,-1, 31,0);
    tracep->declBus(c+675,"csr_sepc_r", false,-1, 31,0);
    tracep->declBus(c+676,"csr_stvec_r", false,-1, 31,0);
    tracep->declBus(c+677,"csr_scause_r", false,-1, 31,0);
    tracep->declBus(c+678,"csr_stval_r", false,-1, 31,0);
    tracep->declBus(c+679,"csr_satp_r", false,-1, 31,0);
    tracep->declBus(c+680,"csr_sscratch_r", false,-1, 31,0);
    tracep->declBit(c+681,"is_exception_w", false,-1);
    tracep->declBit(c+686,"exception_s_w", false,-1);
    tracep->declBit(c+633,"branch_r", false,-1);
    tracep->declBus(c+634,"branch_target_r", false,-1, 31,0);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_issue__u_regfile__0(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_issue__u_regfile__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBus(c+684,"SUPPORT_REGFILE_XILINX", false,-1, 31,0);
    tracep->declBit(c+1,"clk_i", false,-1);
    tracep->declBit(c+2,"rst_i", false,-1);
    tracep->declBus(c+125,"rd0_i", false,-1, 4,0);
    tracep->declBus(c+411,"rd0_value_i", false,-1, 31,0);
    tracep->declBus(c+417,"ra0_i", false,-1, 4,0);
    tracep->declBus(c+406,"rb0_i", false,-1, 4,0);
    tracep->declBus(c+601,"ra0_value_o", false,-1, 31,0);
    tracep->declBus(c+602,"rb0_value_o", false,-1, 31,0);
    tracep->pushNamePrefix("REGFILE ");
    tracep->declBus(c+244,"reg_r1_q", false,-1, 31,0);
    tracep->declBus(c+245,"reg_r2_q", false,-1, 31,0);
    tracep->declBus(c+246,"reg_r3_q", false,-1, 31,0);
    tracep->declBus(c+247,"reg_r4_q", false,-1, 31,0);
    tracep->declBus(c+248,"reg_r5_q", false,-1, 31,0);
    tracep->declBus(c+249,"reg_r6_q", false,-1, 31,0);
    tracep->declBus(c+250,"reg_r7_q", false,-1, 31,0);
    tracep->declBus(c+251,"reg_r8_q", false,-1, 31,0);
    tracep->declBus(c+252,"reg_r9_q", false,-1, 31,0);
    tracep->declBus(c+253,"reg_r10_q", false,-1, 31,0);
    tracep->declBus(c+254,"reg_r11_q", false,-1, 31,0);
    tracep->declBus(c+255,"reg_r12_q", false,-1, 31,0);
    tracep->declBus(c+256,"reg_r13_q", false,-1, 31,0);
    tracep->declBus(c+257,"reg_r14_q", false,-1, 31,0);
    tracep->declBus(c+258,"reg_r15_q", false,-1, 31,0);
    tracep->declBus(c+259,"reg_r16_q", false,-1, 31,0);
    tracep->declBus(c+260,"reg_r17_q", false,-1, 31,0);
    tracep->declBus(c+261,"reg_r18_q", false,-1, 31,0);
    tracep->declBus(c+262,"reg_r19_q", false,-1, 31,0);
    tracep->declBus(c+263,"reg_r20_q", false,-1, 31,0);
    tracep->declBus(c+264,"reg_r21_q", false,-1, 31,0);
    tracep->declBus(c+265,"reg_r22_q", false,-1, 31,0);
    tracep->declBus(c+266,"reg_r23_q", false,-1, 31,0);
    tracep->declBus(c+267,"reg_r24_q", false,-1, 31,0);
    tracep->declBus(c+268,"reg_r25_q", false,-1, 31,0);
    tracep->declBus(c+269,"reg_r26_q", false,-1, 31,0);
    tracep->declBus(c+270,"reg_r27_q", false,-1, 31,0);
    tracep->declBus(c+271,"reg_r28_q", false,-1, 31,0);
    tracep->declBus(c+272,"reg_r29_q", false,-1, 31,0);
    tracep->declBus(c+273,"reg_r30_q", false,-1, 31,0);
    tracep->declBus(c+274,"reg_r31_q", false,-1, 31,0);
    tracep->declBus(c+687,"x0_zero_w", false,-1, 31,0);
    tracep->declBus(c+244,"x1_ra_w", false,-1, 31,0);
    tracep->declBus(c+245,"x2_sp_w", false,-1, 31,0);
    tracep->declBus(c+246,"x3_gp_w", false,-1, 31,0);
    tracep->declBus(c+247,"x4_tp_w", false,-1, 31,0);
    tracep->declBus(c+248,"x5_t0_w", false,-1, 31,0);
    tracep->declBus(c+249,"x6_t1_w", false,-1, 31,0);
    tracep->declBus(c+250,"x7_t2_w", false,-1, 31,0);
    tracep->declBus(c+251,"x8_s0_w", false,-1, 31,0);
    tracep->declBus(c+252,"x9_s1_w", false,-1, 31,0);
    tracep->declBus(c+253,"x10_a0_w", false,-1, 31,0);
    tracep->declBus(c+254,"x11_a1_w", false,-1, 31,0);
    tracep->declBus(c+255,"x12_a2_w", false,-1, 31,0);
    tracep->declBus(c+256,"x13_a3_w", false,-1, 31,0);
    tracep->declBus(c+257,"x14_a4_w", false,-1, 31,0);
    tracep->declBus(c+258,"x15_a5_w", false,-1, 31,0);
    tracep->declBus(c+259,"x16_a6_w", false,-1, 31,0);
    tracep->declBus(c+260,"x17_a7_w", false,-1, 31,0);
    tracep->declBus(c+261,"x18_s2_w", false,-1, 31,0);
    tracep->declBus(c+262,"x19_s3_w", false,-1, 31,0);
    tracep->declBus(c+263,"x20_s4_w", false,-1, 31,0);
    tracep->declBus(c+264,"x21_s5_w", false,-1, 31,0);
    tracep->declBus(c+265,"x22_s6_w", false,-1, 31,0);
    tracep->declBus(c+266,"x23_s7_w", false,-1, 31,0);
    tracep->declBus(c+267,"x24_s8_w", false,-1, 31,0);
    tracep->declBus(c+268,"x25_s9_w", false,-1, 31,0);
    tracep->declBus(c+269,"x26_s10_w", false,-1, 31,0);
    tracep->declBus(c+270,"x27_s11_w", false,-1, 31,0);
    tracep->declBus(c+271,"x28_t3_w", false,-1, 31,0);
    tracep->declBus(c+272,"x29_t4_w", false,-1, 31,0);
    tracep->declBus(c+273,"x30_t5_w", false,-1, 31,0);
    tracep->declBus(c+274,"x31_t6_w", false,-1, 31,0);
    tracep->declBus(c+601,"ra0_value_r", false,-1, 31,0);
    tracep->declBus(c+602,"rb0_value_r", false,-1, 31,0);
    tracep->popNamePrefix(1);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_init_top(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_init_top\n"); );
    // Body
    Vriscv_top___024root__trace_init_sub__TOP__0(vlSelf, tracep);
    tracep->pushNamePrefix("v ");
    Vriscv_top___024root__trace_init_sub__TOP__v__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_core ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_csr ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_csr__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_csrfile ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_csr__u_csrfile__0(vlSelf, tracep);
    tracep->popNamePrefix(2);
    tracep->pushNamePrefix("u_issue ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_issue__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_regfile ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_core__u_issue__u_regfile__0(vlSelf, tracep);
    tracep->popNamePrefix(3);
    tracep->pushNamePrefix("u_dcache ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_core ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_data0 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_data0__0(vlSelf, tracep);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_data1 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_data1__0(vlSelf, tracep);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_tag0 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_tag0__0(vlSelf, tracep);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_tag1 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_dcache__u_core__u_tag1__0(vlSelf, tracep);
    tracep->popNamePrefix(3);
    tracep->pushNamePrefix("u_icache ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__0(vlSelf, tracep);
    tracep->pushNamePrefix("u_data0 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_data0__0(vlSelf, tracep);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_data1 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_data1__0(vlSelf, tracep);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_tag0 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_tag0__0(vlSelf, tracep);
    tracep->popNamePrefix(1);
    tracep->pushNamePrefix("u_tag1 ");
    Vriscv_top___024root__trace_init_sub__TOP__v__u_icache__u_tag1__0(vlSelf, tracep);
    tracep->popNamePrefix(3);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_full_top_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void Vriscv_top___024root__trace_chg_top_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void Vriscv_top___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/);

VL_ATTR_COLD void Vriscv_top___024root__trace_register(Vriscv_top___024root* vlSelf, VerilatedVcd* tracep) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_register\n"); );
    // Body
    tracep->addFullCb(&Vriscv_top___024root__trace_full_top_0, vlSelf, nullptr);
    tracep->addChgCb(&Vriscv_top___024root__trace_chg_top_0, vlSelf, nullptr);
    tracep->addCleanupCb(&Vriscv_top___024root__trace_cleanup, vlSelf);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_full_sub_0(Vriscv_top___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void Vriscv_top___024root__trace_full_top_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_full_top_0\n"); );
    // Init
    Vriscv_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_top___024root*>(voidSelf);
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    Vriscv_top___024root__trace_full_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void Vriscv_top___024root__trace_full_sub_0(Vriscv_top___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_full_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    VlWide<3>/*95:0*/ __Vtemp_hac1c4767__0;
    VlWide<3>/*95:0*/ __Vtemp_h484948a1__0;
    // Body
    bufp->fullBit(oldp+1,(vlSelf->__Vcellinp__v__clk_i));
    bufp->fullBit(oldp+2,(vlSelf->__Vcellinp__v__rst_i));
    bufp->fullBit(oldp+3,(vlSelf->__Vcellinp__v__axi_i_awready_i));
    bufp->fullBit(oldp+4,(vlSelf->__Vcellinp__v__axi_i_wready_i));
    bufp->fullBit(oldp+5,(vlSelf->__Vcellinp__v__axi_i_bvalid_i));
    bufp->fullCData(oldp+6,(vlSelf->__Vcellinp__v__axi_i_bresp_i),2);
    bufp->fullCData(oldp+7,(vlSelf->__Vcellinp__v__axi_i_bid_i),4);
    bufp->fullBit(oldp+8,(vlSelf->__Vcellinp__v__axi_i_arready_i));
    bufp->fullBit(oldp+9,(vlSelf->__Vcellinp__v__axi_i_rvalid_i));
    bufp->fullIData(oldp+10,(vlSelf->__Vcellinp__v__axi_i_rdata_i),32);
    bufp->fullCData(oldp+11,(vlSelf->__Vcellinp__v__axi_i_rresp_i),2);
    bufp->fullCData(oldp+12,(vlSelf->__Vcellinp__v__axi_i_rid_i),4);
    bufp->fullBit(oldp+13,(vlSelf->__Vcellinp__v__axi_i_rlast_i));
    bufp->fullBit(oldp+14,(vlSelf->__Vcellinp__v__axi_d_awready_i));
    bufp->fullBit(oldp+15,(vlSelf->__Vcellinp__v__axi_d_wready_i));
    bufp->fullBit(oldp+16,(vlSelf->__Vcellinp__v__axi_d_bvalid_i));
    bufp->fullCData(oldp+17,(vlSelf->__Vcellinp__v__axi_d_bresp_i),2);
    bufp->fullCData(oldp+18,(vlSelf->__Vcellinp__v__axi_d_bid_i),4);
    bufp->fullBit(oldp+19,(vlSelf->__Vcellinp__v__axi_d_arready_i));
    bufp->fullBit(oldp+20,(vlSelf->__Vcellinp__v__axi_d_rvalid_i));
    bufp->fullIData(oldp+21,(vlSelf->__Vcellinp__v__axi_d_rdata_i),32);
    bufp->fullCData(oldp+22,(vlSelf->__Vcellinp__v__axi_d_rresp_i),2);
    bufp->fullCData(oldp+23,(vlSelf->__Vcellinp__v__axi_d_rid_i),4);
    bufp->fullBit(oldp+24,(vlSelf->__Vcellinp__v__axi_d_rlast_i));
    bufp->fullBit(oldp+25,(vlSelf->__Vcellinp__v__intr_i));
    bufp->fullIData(oldp+26,(vlSelf->__Vcellinp__v__reset_vector_i),32);
    bufp->fullBit(oldp+27,(vlSymsp->TOP__v__u_icache.__PVT__axi_arvalid_o));
    bufp->fullBit(oldp+28,(vlSymsp->TOP__v__u_dcache.__PVT__mem_ack_o));
    bufp->fullBit(oldp+29,(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w));
    bufp->fullBit(oldp+30,(vlSymsp->TOP__v__u_dcache.__PVT__mem_accept_o));
    bufp->fullBit(oldp+31,(vlSymsp->TOP__v__u_icache.__PVT__req_accept_o));
    bufp->fullCData(oldp+32,(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w),4);
    bufp->fullBit(oldp+33,(vlSymsp->TOP__v__u_core.__PVT__mmu_ifetch_rd_w));
    bufp->fullBit(oldp+34,(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o));
    bufp->fullCData(oldp+35,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w),8);
    bufp->fullBit(oldp+36,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_accept_r));
    bufp->fullBit(oldp+37,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w));
    bufp->fullIData(oldp+38,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w),32);
    bufp->fullBit(oldp+39,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_rd_w));
    bufp->fullBit(oldp+40,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w));
    bufp->fullBit(oldp+41,(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_ack_w));
    bufp->fullBit(oldp+42,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_ack_w));
    bufp->fullCData(oldp+43,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_uncached_wr_w),4);
    bufp->fullBit(oldp+44,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_rd_w));
    bufp->fullCData(oldp+45,(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_wr_r),4);
    bufp->fullBit(oldp+46,(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_rd_r));
    bufp->fullCData(oldp+47,(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_wr_w),4);
    bufp->fullBit(oldp+48,(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_rd_w));
    bufp->fullBit(oldp+49,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_is_read_w));
    bufp->fullBit(oldp+50,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__accept_w));
    bufp->fullBit(oldp+51,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_push_w));
    bufp->fullBit(oldp+52,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__res_push_w));
    bufp->fullBit(oldp+53,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_pop_w));
    bufp->fullBit(oldp+54,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wr_cmd_accepted_w));
    bufp->fullBit(oldp+55,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wr_data_accepted_w));
    bufp->fullBit(oldp+56,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wr_data_last_w));
    bufp->fullBit(oldp+57,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__request_w));
    bufp->fullCData(oldp+58,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__pending_r),5);
    bufp->fullBit(oldp+59,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_complete_w));
    bufp->fullBit(oldp+60,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_w));
    bufp->fullBit(oldp+61,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_push_w));
    bufp->fullBit(oldp+62,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__res_push_w));
    bufp->fullBit(oldp+63,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_in_progress_w));
    bufp->fullBit(oldp+64,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_is_drop_w));
    bufp->fullCData(oldp+65,(vlSymsp->TOP__v__u_icache.__PVT__next_state_r),2);
    bufp->fullBit(oldp+66,(vlSymsp->TOP__v__u_icache.__PVT__tag0_write_r));
    bufp->fullBit(oldp+67,(vlSymsp->TOP__v__u_icache.__PVT__tag1_write_r));
    bufp->fullBit(oldp+68,(vlSymsp->TOP__v__u_core__u_issue.__PVT__fetch_accept_o));
    bufp->fullIData(oldp+69,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r),32);
    bufp->fullBit(oldp+70,(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o));
    bufp->fullBit(oldp+71,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_issue_r));
    bufp->fullBit(oldp+72,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_invalid_o));
    bufp->fullBit(oldp+73,(vlSymsp->TOP__v__u_core__u_issue.__PVT__branch_request_o));
    bufp->fullBit(oldp+74,(vlSymsp->TOP__v__u_core.__PVT__writeback_mem_valid_w));
    bufp->fullIData(oldp+75,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r),32);
    bufp->fullBit(oldp+76,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w));
    bufp->fullBit(oldp+77,(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w));
    bufp->fullIData(oldp+78,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__wb_result_r),32);
    bufp->fullIData(oldp+79,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r),32);
    bufp->fullBit(oldp+80,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_start_w));
    bufp->fullIData(oldp+81,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_input_a_r),32);
    bufp->fullIData(oldp+82,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_input_b_r),32);
    bufp->fullIData(oldp+83,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__result_r),32);
    bufp->fullBit(oldp+84,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_r));
    bufp->fullSData(oldp+85,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_fill_r),16);
    bufp->fullIData(oldp+86,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_1_r),32);
    bufp->fullIData(oldp+87,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_2_r),32);
    bufp->fullIData(oldp+88,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_4_r),32);
    bufp->fullIData(oldp+89,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_8_r),32);
    bufp->fullIData(oldp+90,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_1_r),32);
    bufp->fullIData(oldp+91,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_2_r),32);
    bufp->fullIData(oldp+92,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_4_r),32);
    bufp->fullIData(oldp+93,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_8_r),32);
    bufp->fullIData(oldp+94,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__sub_res_w),32);
    bufp->fullBit(oldp+95,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__stall_w));
    bufp->fullBit(oldp+96,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__complete_ok_e2_w));
    bufp->fullBit(oldp+97,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__complete_err_e2_w));
    bufp->fullBit(oldp+98,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w));
    bufp->fullIData(oldp+99,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_r),32);
    bufp->fullBit(oldp+100,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_r));
    bufp->fullIData(oldp+101,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_r),32);
    bufp->fullBit(oldp+102,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_rd_r));
    bufp->fullCData(oldp+103,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_wr_r),4);
    bufp->fullCData(oldp+104,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__addr_lsb_r),2);
    bufp->fullBit(oldp+105,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_byte_r));
    bufp->fullBit(oldp+106,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_half_r));
    bufp->fullBit(oldp+107,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_signed_r));
    bufp->fullBit(oldp+108,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellinp__u_lsu_request__push_i));
    bufp->fullBit(oldp+109,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellinp__u_lsu_request__pop_i));
    bufp->fullCData(oldp+110,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__next_state_r),4);
    bufp->fullCData(oldp+111,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_addr_x_r),8);
    bufp->fullBit(oldp+112,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag0_write_m_r));
    bufp->fullBit(oldp+113,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag1_write_m_r));
    bufp->fullSData(oldp+114,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_x_r),11);
    bufp->fullSData(oldp+115,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r),11);
    bufp->fullCData(oldp+116,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data0_write_m_r),4);
    bufp->fullCData(oldp+117,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data1_write_m_r),4);
    bufp->fullBit(oldp+118,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__refill_request_w));
    bufp->fullBit(oldp+119,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_squash_e1_e2_w));
    bufp->fullBit(oldp+120,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_valid_w));
    bufp->fullBit(oldp+121,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_accept_r));
    bufp->fullCData(oldp+122,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_e2_w),5);
    bufp->fullIData(oldp+123,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_e2_r),32);
    bufp->fullBit(oldp+124,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_valid_wb_w));
    bufp->fullCData(oldp+125,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_wb_w),5);
    bufp->fullIData(oldp+126,(vlSymsp->TOP__v__u_core__u_issue.__PVT__scoreboard_r),32);
    bufp->fullBit(oldp+127,((0U != (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_r))));
    bufp->fullBit(oldp+128,(((IData)(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w) 
                             & (0U != (3U & vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)))));
    bufp->fullBit(oldp+129,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e2_w));
    bufp->fullCData(oldp+130,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_r),6);
    bufp->fullWData(oldp+131,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str),80);
    bufp->fullWData(oldp+134,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra),80);
    bufp->fullWData(oldp+137,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb),80);
    bufp->fullWData(oldp+140,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd),80);
    bufp->fullIData(oldp+143,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm),32);
    bufp->fullIData(oldp+144,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_pc),32);
    bufp->fullWData(oldp+145,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str),80);
    bufp->fullWData(oldp+148,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra),80);
    bufp->fullWData(oldp+151,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb),80);
    bufp->fullWData(oldp+154,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd),80);
    bufp->fullIData(oldp+157,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm),32);
    bufp->fullIData(oldp+158,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_pc),32);
    bufp->fullWData(oldp+159,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str),80);
    bufp->fullWData(oldp+162,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra),80);
    bufp->fullWData(oldp+165,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb),80);
    bufp->fullWData(oldp+168,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd),80);
    bufp->fullIData(oldp+171,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm),32);
    bufp->fullIData(oldp+172,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_pc),32);
    bufp->fullBit(oldp+173,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrw_w));
    bufp->fullBit(oldp+174,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrwi_w));
    bufp->fullBit(oldp+175,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrsi_w));
    bufp->fullBit(oldp+176,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrci_w));
    bufp->fullBit(oldp+177,(vlSymsp->TOP__v__u_core__u_csr.__PVT__sfence_w));
    bufp->fullBit(oldp+178,(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_w));
    bufp->fullBit(oldp+179,(vlSymsp->TOP__v__u_core__u_csr.__PVT__set_r));
    bufp->fullBit(oldp+180,(vlSymsp->TOP__v__u_core__u_csr.__PVT__clr_r));
    bufp->fullIData(oldp+181,(vlSymsp->TOP__v__u_core__u_csr.__PVT__data_r),32);
    bufp->fullBit(oldp+182,(vlSymsp->TOP__v__u_core__u_csr.__PVT__satp_update_w));
    bufp->fullBit(oldp+183,(vlSymsp->TOP__v__u_core__u_csr.__PVT__eret_fault_w));
    bufp->fullIData(oldp+184,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_r),32);
    bufp->fullIData(oldp+185,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_next_r),32);
    bufp->fullIData(oldp+186,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__cache_access_q)
                                ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_r
                                : vlSelf->__Vcellinp__v__axi_d_rdata_i)),32);
    bufp->fullCData(oldp+187,((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w)))
                                ? (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w)
                                : 0U)),4);
    bufp->fullBit(oldp+188,(((~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q)) 
                             & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_ack_w))));
    bufp->fullCData(oldp+189,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w)
                                : 0U)),8);
    bufp->fullIData(oldp+190,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                : (0xfffffffcU & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U]))),32);
    bufp->fullBit(oldp+191,(((~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q)) 
                             & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w))));
    bufp->fullBit(oldp+192,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q) 
                             & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w))));
    __Vtemp_hac1c4767__0[0U] = (IData)((((QData)((IData)(
                                                         ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                           ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                                           : 
                                                          vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U]))) 
                                         << 0x20U) 
                                        | (QData)((IData)(
                                                          ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                            ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                                            : 
                                                           (0xfffffffcU 
                                                            & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U]))))));
    __Vtemp_hac1c4767__0[1U] = (IData)(((((QData)((IData)(
                                                          ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                            ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                                            : 
                                                           vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U]))) 
                                          << 0x20U) 
                                         | (QData)((IData)(
                                                           ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                             ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                                             : 
                                                            (0xfffffffcU 
                                                             & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U]))))) 
                                        >> 0x20U));
    __Vtemp_hac1c4767__0[2U] = ((((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                   ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w)
                                   : 0U) << 5U) | (
                                                   ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_rd_r) 
                                                    << 4U) 
                                                   | (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_wr_r)));
    bufp->fullWData(oldp+193,(__Vtemp_hac1c4767__0),77);
    bufp->fullBit(oldp+196,((((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                              & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_in_progress_w))) 
                             & (~ (vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[2U] 
                                   >> 4U)))));
    __Vtemp_h484948a1__0[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                         << 0x20U) 
                                        | (QData)((IData)(
                                                          (0xfffffffcU 
                                                           & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))));
    __Vtemp_h484948a1__0[1U] = (IData)(((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                          << 0x20U) 
                                         | (QData)((IData)(
                                                           (0xfffffffcU 
                                                            & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))) 
                                        >> 0x20U));
    __Vtemp_h484948a1__0[2U] = (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__drop_req_w) 
                                 << 5U) | (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_rd_w) 
                                            << 4U) 
                                           | (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_wr_w)));
    bufp->fullWData(oldp+197,(__Vtemp_h484948a1__0),70);
    bufp->fullBit(oldp+200,(((IData)(vlSelf->__Vcellinp__v__axi_i_rvalid_i) 
                             & (~ (IData)(vlSymsp->TOP__v__u_icache.__PVT__replace_way_q)))));
    bufp->fullBit(oldp+201,(((IData)(vlSelf->__Vcellinp__v__axi_i_rvalid_i) 
                             & (IData)(vlSymsp->TOP__v__u_icache.__PVT__replace_way_q))));
    bufp->fullIData(oldp+202,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)
                                ? vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_target_q
                                : vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)),32);
    bufp->fullBit(oldp+203,(((((((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q) 
                                   | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                  | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                                 | (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w)) 
                                | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                               & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_accept_o))) 
                              | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w)) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q))));
    bufp->fullCData(oldp+204,((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                                ? 0x14U : (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                            & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                            ? 0x16U
                                            : (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                                                & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                                                ? 0x15U
                                                : (
                                                   ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                                                    & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                                    ? 0x17U
                                                    : 0U))))),6);
    bufp->fullBit(oldp+205,(((((((IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w) 
                                 | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q)) 
                               | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                              | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                             & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_accept_o))));
    bufp->fullBit(oldp+206,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                             & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
    bufp->fullBit(oldp+207,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                             & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))));
    bufp->fullQData(oldp+208,(((0x2002033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                ? (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r))
                                : ((0x2001033U == (0xfe00707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                    ? (((QData)((IData)(
                                                        (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r 
                                                         >> 0x1fU))) 
                                        << 0x20U) | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r)))
                                    : (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r))))),33);
    bufp->fullQData(oldp+210,(((0x2002033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                ? (((QData)((IData)(
                                                    (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r 
                                                     >> 0x1fU))) 
                                    << 0x20U) | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r)))
                                : ((0x2001033U == (0xfe00707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                    ? (((QData)((IData)(
                                                        (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r 
                                                         >> 0x1fU))) 
                                        << 0x20U) | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r)))
                                    : (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r))))),33);
    bufp->fullIData(oldp+212,(((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                ? vlSelf->__Vcellinp__v__axi_d_rdata_i
                                : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q)),32);
    bufp->fullBit(oldp+213,((1U & (((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                    >> 3U) & (~ (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w))))));
    bufp->fullBit(oldp+214,((IData)((((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                      >> 9U) & (~ (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w))))));
    bufp->fullBit(oldp+215,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0x73U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+216,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0x100073U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+217,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0x200073U == (0xcfffffffU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+218,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0x2073U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+219,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0x3073U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+220,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0x10500073U == (0xffff8fffU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+221,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                             & (0xfU == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+222,(((IData)(((0U != (0xf8000U 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                      | (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrw_w))) 
                             | (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrwi_w))));
    bufp->fullBit(oldp+223,((((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                              & ((0x344U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                             >> 0x14U)) 
                                 | (0x144U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                               >> 0x14U)))) 
                             | (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_upd_q))));
    bufp->fullIData(oldp+224,(vlSymsp->TOP__v__u_icache__u_tag0.__PVT__ram_read_q),20);
    bufp->fullBit(oldp+225,((1U & (vlSymsp->TOP__v__u_icache__u_tag0.__PVT__ram_read_q 
                                   >> 0x13U))));
    bufp->fullIData(oldp+226,((0x7ffffU & vlSymsp->TOP__v__u_icache__u_tag0.__PVT__ram_read_q)),19);
    bufp->fullIData(oldp+227,(vlSymsp->TOP__v__u_icache__u_tag1.__PVT__ram_read_q),20);
    bufp->fullBit(oldp+228,((1U & (vlSymsp->TOP__v__u_icache__u_tag1.__PVT__ram_read_q 
                                   >> 0x13U))));
    bufp->fullIData(oldp+229,((0x7ffffU & vlSymsp->TOP__v__u_icache__u_tag1.__PVT__ram_read_q)),19);
    bufp->fullIData(oldp+230,(vlSymsp->TOP__v__u_icache__u_data0.__PVT__ram_read_q),32);
    bufp->fullIData(oldp+231,(vlSymsp->TOP__v__u_icache__u_data1.__PVT__ram_read_q),32);
    bufp->fullIData(oldp+232,(vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q),21);
    bufp->fullBit(oldp+233,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                   >> 0x14U))));
    bufp->fullBit(oldp+234,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                   >> 0x13U))));
    bufp->fullIData(oldp+235,((0x7ffffU & vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q)),19);
    bufp->fullIData(oldp+236,(vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q),21);
    bufp->fullBit(oldp+237,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                   >> 0x14U))));
    bufp->fullBit(oldp+238,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                   >> 0x13U))));
    bufp->fullIData(oldp+239,((0x7ffffU & vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q)),19);
    bufp->fullIData(oldp+240,(vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read0_q),32);
    bufp->fullIData(oldp+241,(vlSymsp->TOP__v__u_dcache__u_core__u_data1.__PVT__ram_read0_q),32);
    bufp->fullIData(oldp+242,(vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read1_q),32);
    bufp->fullIData(oldp+243,(vlSymsp->TOP__v__u_dcache__u_core__u_data1.__PVT__ram_read1_q),32);
    bufp->fullIData(oldp+244,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r1_q),32);
    bufp->fullIData(oldp+245,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r2_q),32);
    bufp->fullIData(oldp+246,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r3_q),32);
    bufp->fullIData(oldp+247,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r4_q),32);
    bufp->fullIData(oldp+248,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r5_q),32);
    bufp->fullIData(oldp+249,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r6_q),32);
    bufp->fullIData(oldp+250,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r7_q),32);
    bufp->fullIData(oldp+251,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r8_q),32);
    bufp->fullIData(oldp+252,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r9_q),32);
    bufp->fullIData(oldp+253,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r10_q),32);
    bufp->fullIData(oldp+254,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r11_q),32);
    bufp->fullIData(oldp+255,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r12_q),32);
    bufp->fullIData(oldp+256,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r13_q),32);
    bufp->fullIData(oldp+257,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r14_q),32);
    bufp->fullIData(oldp+258,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r15_q),32);
    bufp->fullIData(oldp+259,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r16_q),32);
    bufp->fullIData(oldp+260,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r17_q),32);
    bufp->fullIData(oldp+261,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r18_q),32);
    bufp->fullIData(oldp+262,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r19_q),32);
    bufp->fullIData(oldp+263,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r20_q),32);
    bufp->fullIData(oldp+264,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r21_q),32);
    bufp->fullIData(oldp+265,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r22_q),32);
    bufp->fullIData(oldp+266,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r23_q),32);
    bufp->fullIData(oldp+267,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r24_q),32);
    bufp->fullIData(oldp+268,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r25_q),32);
    bufp->fullIData(oldp+269,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r26_q),32);
    bufp->fullIData(oldp+270,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r27_q),32);
    bufp->fullIData(oldp+271,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r28_q),32);
    bufp->fullIData(oldp+272,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r29_q),32);
    bufp->fullIData(oldp+273,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r30_q),32);
    bufp->fullIData(oldp+274,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r31_q),32);
    bufp->fullIData(oldp+275,((0xffffffe0U & vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q)),32);
    bufp->fullBit(oldp+276,(vlSymsp->TOP__v__u_dcache.__PVT__axi_awvalid_o));
    bufp->fullIData(oldp+277,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w),32);
    bufp->fullCData(oldp+278,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_id_w),4);
    bufp->fullCData(oldp+279,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_len_w),8);
    bufp->fullCData(oldp+280,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w),2);
    bufp->fullBit(oldp+281,(vlSymsp->TOP__v__u_dcache.__PVT__axi_wvalid_o));
    bufp->fullIData(oldp+282,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w),32);
    bufp->fullCData(oldp+283,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w),4);
    bufp->fullBit(oldp+284,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w));
    bufp->fullBit(oldp+285,(vlSymsp->TOP__v__u_dcache.__PVT__axi_arvalid_o));
    bufp->fullBit(oldp+286,(vlSymsp->TOP__v__u_icache.__PVT__req_valid_o));
    bufp->fullBit(oldp+287,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_q) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_invalidate_q))));
    bufp->fullBit(oldp+288,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q));
    bufp->fullBit(oldp+289,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
    bufp->fullSData(oldp+290,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__cache_access_q)
                                ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_tag_m_q)
                                : vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q
                               [vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q])),11);
    bufp->fullIData(oldp+291,(vlSymsp->TOP__v__u_icache.__PVT__inst_r),32);
    bufp->fullIData(oldp+292,((0xfffffffcU & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)),32);
    bufp->fullBit(oldp+293,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q));
    bufp->fullBit(oldp+294,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
    bufp->fullBit(oldp+295,(vlSymsp->TOP__v__u_icache.__PVT__axi_error_q));
    bufp->fullIData(oldp+296,((0xfffffffcU & vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q)),32);
    bufp->fullIData(oldp+297,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q),32);
    bufp->fullBit(oldp+298,((((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                              & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w))) 
                             & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q))));
    bufp->fullBit(oldp+299,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w));
    bufp->fullBit(oldp+300,(((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                             & (2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q)))));
    bufp->fullBit(oldp+301,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_invalidate_w));
    bufp->fullBit(oldp+302,(((~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)) 
                             & (2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q)))));
    bufp->fullIData(oldp+303,((0xfffffffcU & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U])),32);
    bufp->fullIData(oldp+304,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_r),32);
    bufp->fullBit(oldp+305,((((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                              & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w))) 
                             & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q))));
    bufp->fullIData(oldp+306,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                : vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U])),32);
    bufp->fullSData(oldp+307,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_tag_m_q),11);
    bufp->fullBit(oldp+308,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w));
    bufp->fullBit(oldp+309,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_flush_w));
    bufp->fullBit(oldp+310,((((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                              & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w))) 
                             & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q))));
    bufp->fullCData(oldp+311,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr_w),4);
    bufp->fullIData(oldp+312,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U]),32);
    bufp->fullSData(oldp+313,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q
                              [vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q]),11);
    bufp->fullBit(oldp+314,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q))));
    bufp->fullIData(oldp+315,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w),32);
    bufp->fullBit(oldp+316,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__error_q));
    bufp->fullBit(oldp+317,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_ack_r));
    bufp->fullBit(oldp+318,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_writeback_w));
    bufp->fullBit(oldp+319,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_outstanding_q))));
    bufp->fullBit(oldp+320,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_outstanding_q))));
    bufp->fullBit(oldp+321,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q))));
    bufp->fullWData(oldp+322,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w),77);
    bufp->fullBit(oldp+325,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_can_issue_w));
    bufp->fullBit(oldp+326,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_can_issue_w) 
                             & (vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U] 
                                >> 4U))));
    bufp->fullBit(oldp+327,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_is_write_w));
    bufp->fullCData(oldp+328,((0xffU & (vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U] 
                                        >> 5U))),8);
    bufp->fullCData(oldp+329,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_cnt_q),8);
    bufp->fullBit(oldp+330,((((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_is_write_w) 
                              & (0U == (0x1fe0U & vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U]))) 
                             & (0U == (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_cnt_q)))));
    bufp->fullCData(oldp+331,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_outstanding_q),2);
    bufp->fullIData(oldp+332,((0xfffffffcU & vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[0U])),32);
    bufp->fullIData(oldp+333,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[1U]),32);
    bufp->fullCData(oldp+334,((0xfU & vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U])),4);
    bufp->fullCData(oldp+335,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q),8);
    bufp->fullBit(oldp+336,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__valid_q));
    bufp->fullWData(oldp+337,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__buf_q),84);
    bufp->fullBit(oldp+340,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w));
    bufp->fullBit(oldp+341,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_write_w));
    bufp->fullBit(oldp+342,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__awvalid_q));
    bufp->fullBit(oldp+343,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wvalid_q));
    bufp->fullBit(oldp+344,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wlast_q));
    bufp->fullWData(oldp+345,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__ram_q[0]),77);
    bufp->fullWData(oldp+348,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__ram_q[1]),77);
    bufp->fullBit(oldp+351,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q));
    bufp->fullBit(oldp+352,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q));
    bufp->fullCData(oldp+353,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q),2);
    bufp->fullBit(oldp+354,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w));
    bufp->fullBit(oldp+355,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__cache_access_q));
    bufp->fullCData(oldp+356,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__pending_q),5);
    bufp->fullBit(oldp+357,(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q));
    bufp->fullBit(oldp+358,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q))));
    bufp->fullBit(oldp+359,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q))));
    bufp->fullBit(oldp+360,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q))));
    bufp->fullWData(oldp+361,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w),70);
    bufp->fullBit(oldp+364,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__drop_req_w));
    bufp->fullBit(oldp+365,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_pending_q));
    bufp->fullBit(oldp+366,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__dropped_q));
    bufp->fullWData(oldp+367,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__ram_q[0]),70);
    bufp->fullWData(oldp+370,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__ram_q[1]),70);
    bufp->fullBit(oldp+373,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q));
    bufp->fullBit(oldp+374,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__wr_ptr_q));
    bufp->fullCData(oldp+375,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q),2);
    bufp->fullBit(oldp+376,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q))));
    bufp->fullSData(oldp+377,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q[0]),11);
    bufp->fullSData(oldp+378,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q[1]),11);
    bufp->fullBit(oldp+379,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q));
    bufp->fullBit(oldp+380,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__wr_ptr_q));
    bufp->fullCData(oldp+381,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q),2);
    bufp->fullCData(oldp+382,((0xffU & (vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q 
                                        >> 5U))),8);
    bufp->fullSData(oldp+383,((0x7ffU & (vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q 
                                         >> 2U))),11);
    bufp->fullCData(oldp+384,(vlSymsp->TOP__v__u_icache.__PVT__state_q),2);
    bufp->fullBit(oldp+385,(vlSymsp->TOP__v__u_icache.__PVT__invalidate_q));
    bufp->fullBit(oldp+386,(vlSymsp->TOP__v__u_icache.__PVT__replace_way_q));
    bufp->fullBit(oldp+387,(vlSymsp->TOP__v__u_icache.__PVT__lookup_valid_q));
    bufp->fullIData(oldp+388,(vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q),32);
    bufp->fullIData(oldp+389,((vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q 
                               >> 0xdU)),19);
    bufp->fullCData(oldp+390,(vlSymsp->TOP__v__u_icache.__PVT__tag_addr_r),8);
    bufp->fullIData(oldp+391,(vlSymsp->TOP__v__u_icache.__PVT__tag_data_in_r),20);
    bufp->fullBit(oldp+392,(vlSymsp->TOP__v__u_icache.__PVT__tag0_hit_w));
    bufp->fullBit(oldp+393,(vlSymsp->TOP__v__u_icache.__PVT__tag1_hit_w));
    bufp->fullBit(oldp+394,(vlSymsp->TOP__v__u_icache.__PVT__tag_hit_any_w));
    bufp->fullSData(oldp+395,(vlSymsp->TOP__v__u_icache.__PVT__data_addr_r),11);
    bufp->fullSData(oldp+396,(vlSymsp->TOP__v__u_icache.__PVT__data_write_addr_q),11);
    bufp->fullCData(oldp+397,(vlSymsp->TOP__v__u_icache.__PVT__flush_addr_q),8);
    bufp->fullBit(oldp+398,(vlSymsp->TOP__v__u_icache.__PVT__axi_arvalid_q));
    bufp->fullCData(oldp+399,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__priv_f_q),2);
    bufp->fullCData(oldp+400,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                        >> 7U))),5);
    bufp->fullBit(oldp+401,(vlSymsp->TOP__v__u_core__u_csr.__PVT__tlb_flush_q));
    bufp->fullIData(oldp+402,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w),32);
    bufp->fullIData(oldp+403,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__pc_m_q),32);
    bufp->fullIData(oldp+404,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__wb_result_q),32);
    bufp->fullBit(oldp+405,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q));
    bufp->fullCData(oldp+406,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                        >> 0x14U))),5);
    bufp->fullBit(oldp+407,((1U & (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                   >> 0x13U))));
    bufp->fullCData(oldp+408,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_wb_q),6);
    bufp->fullBit(oldp+409,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_mul_w));
    bufp->fullBit(oldp+410,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ret_q));
    bufp->fullIData(oldp+411,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_wb_q),32);
    bufp->fullCData(oldp+412,(vlSymsp->TOP__v__u_core__u_csr.__PVT__exception_e1_q),6);
    bufp->fullIData(oldp+413,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_target_q),32);
    bufp->fullBit(oldp+414,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w));
    bufp->fullIData(oldp+415,(vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w),32);
    bufp->fullBit(oldp+416,(vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__u_dec__DOT__invalid_w));
    bufp->fullCData(oldp+417,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                        >> 0xfU))),5);
    bufp->fullBit(oldp+418,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ntaken_q));
    bufp->fullIData(oldp+419,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__pc_x_q),32);
    bufp->fullBit(oldp+420,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_q));
    bufp->fullBit(oldp+421,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w));
    bufp->fullBit(oldp+422,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_valid_w));
    bufp->fullCData(oldp+423,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o),2);
    bufp->fullBit(oldp+424,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_q) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ntaken_q))));
    bufp->fullCData(oldp+425,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)
                                ? (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o)
                                : (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__priv_x_q))),2);
    bufp->fullBit(oldp+426,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_pending_q) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w))));
    bufp->fullBit(oldp+427,((((((((((3U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                    | (0x1003U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x2003U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x4003U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x5003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x6003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                               | (0x23U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x1023U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x2023U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullCData(oldp+428,((3U & ((0x20000U & vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q)
                                      ? (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                         >> 0xbU) : (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q)))),2);
    bufp->fullBit(oldp+429,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__valid_q));
    bufp->fullBit(oldp+430,(((((((((0x6fU == (0x7fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                   | (0x67U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x63U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x1063U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x4063U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                               | (0x5063U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x6063U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x7063U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullIData(oldp+431,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_q),32);
    bufp->fullIData(oldp+432,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csr_wdata_e1_q),32);
    bufp->fullBit(oldp+433,(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_q));
    bufp->fullBit(oldp+434,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_exec_w));
    bufp->fullIData(oldp+435,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wdata_wb_q),32);
    bufp->fullBit(oldp+436,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_wb_q));
    bufp->fullBit(oldp+437,(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q));
    bufp->fullIData(oldp+438,(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_result_e1_q),32);
    bufp->fullSData(oldp+439,((vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                               >> 0x14U)),12);
    bufp->fullBit(oldp+440,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_jmp_q));
    bufp->fullBit(oldp+441,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w));
    bufp->fullIData(oldp+442,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_instr_w),32);
    bufp->fullBit(oldp+443,(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_valid_e1_q));
    bufp->fullBit(oldp+444,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w));
    bufp->fullBit(oldp+445,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w));
    bufp->fullIData(oldp+446,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e2_q),32);
    bufp->fullBit(oldp+447,((1U & (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                   >> 0x12U))));
    bufp->fullIData(oldp+448,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__result_q),32);
    bufp->fullIData(oldp+449,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_wb_q),32);
    bufp->fullBit(oldp+450,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_call_q));
    bufp->fullBit(oldp+451,(((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w))));
    bufp->fullBit(oldp+452,((0x2004033U == (0xfe00707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+453,((0x2005033U == (0xfe00707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+454,((0x2006033U == (0xfe00707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+455,((0x2007033U == (0xfe00707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+456,(((((0x2004033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                               | (0x2005033U == (0xfe00707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x2006033U == (0xfe00707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x2007033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+457,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__signed_operation_w));
    bufp->fullBit(oldp+458,(((0x2004033U == (0xfe00707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                             | (0x2005033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullIData(oldp+459,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q),32);
    bufp->fullQData(oldp+460,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__divisor_q),63);
    bufp->fullIData(oldp+462,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q),32);
    bufp->fullIData(oldp+463,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__q_mask_q),32);
    bufp->fullBit(oldp+464,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_inst_q));
    bufp->fullBit(oldp+465,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_busy_q));
    bufp->fullBit(oldp+466,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q));
    bufp->fullBit(oldp+467,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_complete_w));
    bufp->fullIData(oldp+468,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_inst_q)
                                ? ((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q)
                                    ? (- vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q)
                                    : vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q)
                                : ((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q)
                                    ? (- vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q)
                                    : vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q))),32);
    bufp->fullIData(oldp+469,((0xfffff000U & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)),32);
    bufp->fullIData(oldp+470,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__imm12_r),32);
    bufp->fullIData(oldp+471,((((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                            >> 0x1fU))) 
                                << 0xdU) | ((0x1000U 
                                             & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                >> 0x13U)) 
                                            | ((0x800U 
                                                & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                   << 4U)) 
                                               | ((0x7e0U 
                                                   & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                      >> 0x14U)) 
                                                  | (0x1eU 
                                                     & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                        >> 7U))))))),32);
    bufp->fullIData(oldp+472,((((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                            >> 0x1fU))) 
                                << 0x14U) | ((0xff000U 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w) 
                                             | ((0x800U 
                                                 & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                    >> 9U)) 
                                                | ((0x7e0U 
                                                    & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                       >> 0x14U)) 
                                                   | (0x1eU 
                                                      & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                         >> 0x14U))))))),32);
    bufp->fullCData(oldp+473,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_func_r),4);
    bufp->fullBit(oldp+474,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_r));
    bufp->fullBit(oldp+475,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_call_r));
    bufp->fullBit(oldp+476,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ret_r));
    bufp->fullBit(oldp+477,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_jmp_r));
    bufp->fullBit(oldp+478,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__active_q));
    bufp->fullBit(oldp+479,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_busy_w));
    bufp->fullBit(oldp+480,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_q));
    bufp->fullIData(oldp+481,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_pc_q),32);
    bufp->fullCData(oldp+482,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_priv_q),2);
    bufp->fullBit(oldp+483,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__stall_q));
    bufp->fullBit(oldp+484,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_fetch_q));
    bufp->fullBit(oldp+485,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_invalidate_q));
    bufp->fullIData(oldp+486,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q),32);
    bufp->fullIData(oldp+487,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_d_q),32);
    bufp->fullBit(oldp+488,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_q) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_d_q))));
    bufp->fullBit(oldp+489,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_d_q));
    bufp->fullWData(oldp+490,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__skid_buffer_q),66);
    bufp->fullBit(oldp+493,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__skid_valid_q));
    bufp->fullIData(oldp+494,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q),32);
    bufp->fullBit(oldp+495,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_rd_q));
    bufp->fullCData(oldp+496,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_wr_q),4);
    bufp->fullBit(oldp+497,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q));
    bufp->fullBit(oldp+498,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q));
    bufp->fullBit(oldp+499,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_load_q));
    bufp->fullBit(oldp+500,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xb_q));
    bufp->fullBit(oldp+501,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xh_q));
    bufp->fullBit(oldp+502,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_ls_q));
    bufp->fullBit(oldp+503,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__pending_lsu_e2_q));
    bufp->fullBit(oldp+504,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_inst_w));
    bufp->fullBit(oldp+505,((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                              | (0x1003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x2003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+506,((((0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                              | (0x1023U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x2023U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+507,(((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                             | (0x4003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+508,(((0x1003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                             | (0x5003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+509,(((0x2003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                             | (0x6003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+510,((0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+511,((0x1023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+512,((0x2023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
    bufp->fullBit(oldp+513,((((0x2023U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                              | (0x2003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x6003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+514,((((0x1023U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                              | (0x1003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x5003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+515,((IData)((0x3a001073U == 
                                     (0xfff0707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+516,((IData)((0x3a101073U == 
                                     (0xfff0707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+517,((IData)((0x3a201073U == 
                                     (0xfff0707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
    bufp->fullBit(oldp+518,((1U & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
    bufp->fullIData(oldp+519,((IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                       >> 4U))),32);
    bufp->fullBit(oldp+520,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                           >> 1U)))));
    bufp->fullBit(oldp+521,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                           >> 2U)))));
    bufp->fullBit(oldp+522,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                           >> 3U)))));
    bufp->fullBit(oldp+523,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                             & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
    bufp->fullBit(oldp+524,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                             & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))));
    bufp->fullQData(oldp+525,((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                                << 4U) | (QData)((IData)(
                                                         (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_ls_q) 
                                                           << 3U) 
                                                          | (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xh_q) 
                                                              << 2U) 
                                                             | (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xb_q) 
                                                                 << 1U) 
                                                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_load_q)))))))),36);
    bufp->fullQData(oldp+527,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o),36);
    bufp->fullBit(oldp+529,((2U != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q))));
    bufp->fullBit(oldp+530,((0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q))));
    bufp->fullQData(oldp+531,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__ram_q[0]),36);
    bufp->fullQData(oldp+533,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__ram_q[1]),36);
    bufp->fullBit(oldp+535,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__rd_ptr_q));
    bufp->fullBit(oldp+536,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__wr_ptr_q));
    bufp->fullCData(oldp+537,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q),2);
    bufp->fullIData(oldp+538,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__i),32);
    bufp->fullIData(oldp+539,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e3_q),32);
    bufp->fullQData(oldp+540,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__operand_a_e1_q),33);
    bufp->fullQData(oldp+542,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__operand_b_e1_q),33);
    bufp->fullBit(oldp+544,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mulhi_sel_e1_q));
    bufp->fullWData(oldp+545,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w),65);
    bufp->fullIData(oldp+548,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mulhi_sel_e1_q)
                                ? vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w[1U]
                                : vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w[0U])),32);
    bufp->fullCData(oldp+549,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q),4);
    bufp->fullIData(oldp+550,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_addr_m_q),32);
    bufp->fullIData(oldp+551,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q),32);
    bufp->fullCData(oldp+552,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_wr_m_q),4);
    bufp->fullBit(oldp+553,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_rd_m_q));
    bufp->fullBit(oldp+554,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_inval_m_q));
    bufp->fullBit(oldp+555,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_writeback_m_q));
    bufp->fullBit(oldp+556,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_flush_m_q));
    bufp->fullIData(oldp+557,((vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_addr_m_q 
                               >> 0xdU)),19);
    bufp->fullBit(oldp+558,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__replace_way_q));
    bufp->fullBit(oldp+559,((0U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_q))));
    bufp->fullBit(oldp+560,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_way_w));
    bufp->fullBit(oldp+561,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__flushing_q));
    bufp->fullCData(oldp+562,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_addr_m_r),8);
    bufp->fullIData(oldp+563,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_data_in_m_r),21);
    bufp->fullBit(oldp+564,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag0_hit_m_w));
    bufp->fullBit(oldp+565,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag1_hit_m_w));
    bufp->fullBit(oldp+566,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_hit_any_m_w));
    bufp->fullBit(oldp+567,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_way_r));
    bufp->fullIData(oldp+568,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_data_r),32);
    bufp->fullIData(oldp+569,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_addr_r),27);
    bufp->fullSData(oldp+570,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_write_addr_q),11);
    bufp->fullCData(oldp+571,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__flush_addr_q),8);
    bufp->fullBit(oldp+572,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__flush_last_q));
    bufp->fullBit(oldp+573,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_rd_q));
    bufp->fullBit(oldp+574,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr0_q));
    bufp->fullCData(oldp+575,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_q),8);
    bufp->fullIData(oldp+576,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_q),32);
    bufp->fullCData(oldp+577,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr_q),4);
    bufp->fullIData(oldp+578,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_q),32);
    bufp->fullBit(oldp+579,(((7U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q)) 
                             & ((IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_way_w) 
                                | (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_writeback_m_q)))));
    bufp->fullWData(oldp+580,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__dbg_state),80);
    bufp->fullCData(oldp+583,(vlSymsp->TOP__v__u_core__u_issue.__PVT__priv_x_q),2);
    bufp->fullBit(oldp+584,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                   >> 1U))));
    bufp->fullBit(oldp+585,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                   >> 2U))));
    bufp->fullBit(oldp+586,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                   >> 5U))));
    bufp->fullBit(oldp+587,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                   >> 6U))));
    bufp->fullCData(oldp+588,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_e1_w),5);
    bufp->fullIData(oldp+589,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_e1_q),32);
    bufp->fullIData(oldp+590,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_e1_q),32);
    bufp->fullIData(oldp+591,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q),32);
    bufp->fullIData(oldp+592,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q),32);
    bufp->fullBit(oldp+593,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                   >> 1U))));
    bufp->fullBit(oldp+594,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                   >> 5U))));
    bufp->fullIData(oldp+595,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q),32);
    bufp->fullIData(oldp+596,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_wb_q),32);
    bufp->fullIData(oldp+597,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_wb_q),32);
    bufp->fullCData(oldp+598,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_fault_w),6);
    bufp->fullBit(oldp+599,(vlSymsp->TOP__v__u_core__u_issue.__PVT__div_pending_q));
    bufp->fullBit(oldp+600,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_pending_q));
    bufp->fullIData(oldp+601,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__ra0_value_r),32);
    bufp->fullIData(oldp+602,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__rb0_value_r),32);
    bufp->fullCData(oldp+603,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                        >> 0xfU))),5);
    bufp->fullCData(oldp+604,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                        >> 0x14U))),5);
    bufp->fullBit(oldp+605,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e1_q));
    bufp->fullSData(oldp+606,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q),10);
    bufp->fullIData(oldp+607,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_e1_q),32);
    bufp->fullCData(oldp+608,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e1_q),6);
    bufp->fullBit(oldp+609,((1U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))));
    bufp->fullBit(oldp+610,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                   >> 3U))));
    bufp->fullBit(oldp+611,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                   >> 4U))));
    bufp->fullBit(oldp+612,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e2_q));
    bufp->fullSData(oldp+613,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q),10);
    bufp->fullBit(oldp+614,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_e2_q));
    bufp->fullIData(oldp+615,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wdata_e2_q),32);
    bufp->fullIData(oldp+616,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_e2_q),32);
    bufp->fullIData(oldp+617,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_e2_q),32);
    bufp->fullIData(oldp+618,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_e2_q),32);
    bufp->fullIData(oldp+619,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_e2_q),32);
    bufp->fullIData(oldp+620,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q),32);
    bufp->fullIData(oldp+621,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q),32);
    bufp->fullCData(oldp+622,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_q),6);
    bufp->fullBit(oldp+623,((IData)((0U != (6U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q))))));
    bufp->fullBit(oldp+624,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__squash_e1_e2_q));
    bufp->fullBit(oldp+625,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_wb_q));
    bufp->fullSData(oldp+626,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q),10);
    bufp->fullIData(oldp+627,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_wb_q),32);
    bufp->fullCData(oldp+628,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                        >> 7U))),5);
    bufp->fullCData(oldp+629,((3U & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                     >> 0x1cU))),2);
    bufp->fullCData(oldp+630,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q),2);
    bufp->fullBit(oldp+631,((3U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                    >> 0x1eU))));
    bufp->fullIData(oldp+632,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__rdata_r),32);
    bufp->fullBit(oldp+633,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__branch_r));
    bufp->fullIData(oldp+634,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__branch_target_r),32);
    bufp->fullIData(oldp+635,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_masked_r),32);
    bufp->fullIData(oldp+636,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q),32);
    bufp->fullBit(oldp+637,(vlSymsp->TOP__v__u_core__u_csr.__PVT__reset_q));
    bufp->fullSData(oldp+638,((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                               >> 0x14U)),12);
    bufp->fullSData(oldp+639,(vlSymsp->TOP__v__u_core__u_csr.__Vcellinp__u_csrfile__csr_waddr_i),12);
    bufp->fullIData(oldp+640,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mepc_q),32);
    bufp->fullIData(oldp+641,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcause_q),32);
    bufp->fullIData(oldp+642,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtvec_q),32);
    bufp->fullIData(oldp+643,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_q),32);
    bufp->fullIData(oldp+644,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mie_q),32);
    bufp->fullIData(oldp+645,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_q),32);
    bufp->fullIData(oldp+646,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_h_q),32);
    bufp->fullIData(oldp+647,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mscratch_q),32);
    bufp->fullIData(oldp+648,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtval_q),32);
    bufp->fullIData(oldp+649,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtimecmp_q),32);
    bufp->fullBit(oldp+650,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtime_ie_q));
    bufp->fullIData(oldp+651,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_medeleg_q),32);
    bufp->fullIData(oldp+652,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mideleg_q),32);
    bufp->fullIData(oldp+653,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sepc_q),32);
    bufp->fullIData(oldp+654,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stvec_q),32);
    bufp->fullIData(oldp+655,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_scause_q),32);
    bufp->fullIData(oldp+656,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stval_q),32);
    bufp->fullIData(oldp+657,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sscratch_q),32);
    bufp->fullIData(oldp+658,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_pending_r),32);
    bufp->fullCData(oldp+659,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_priv_q),2);
    bufp->fullBit(oldp+660,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_upd_q));
    bufp->fullIData(oldp+661,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mepc_r),32);
    bufp->fullIData(oldp+662,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcause_r),32);
    bufp->fullIData(oldp+663,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtval_r),32);
    bufp->fullIData(oldp+664,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_r),32);
    bufp->fullIData(oldp+665,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtvec_r),32);
    bufp->fullIData(oldp+666,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mie_r),32);
    bufp->fullCData(oldp+667,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_r),2);
    bufp->fullIData(oldp+668,(((IData)(1U) + vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_q)),32);
    bufp->fullIData(oldp+669,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mscratch_r),32);
    bufp->fullIData(oldp+670,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtimecmp_r),32);
    bufp->fullBit(oldp+671,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtime_ie_r));
    bufp->fullIData(oldp+672,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_medeleg_r),32);
    bufp->fullIData(oldp+673,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mideleg_r),32);
    bufp->fullIData(oldp+674,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_next_q),32);
    bufp->fullIData(oldp+675,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sepc_r),32);
    bufp->fullIData(oldp+676,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stvec_r),32);
    bufp->fullIData(oldp+677,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_scause_r),32);
    bufp->fullIData(oldp+678,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stval_r),32);
    bufp->fullIData(oldp+679,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_r),32);
    bufp->fullIData(oldp+680,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sscratch_r),32);
    bufp->fullBit(oldp+681,((0x10U == (0x30U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_wb_q)))));
    bufp->fullBit(oldp+682,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_dirty_any_m_w));
    bufp->fullBit(oldp+683,((((IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag0_hit_m_w) 
                              & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                 >> 0x13U)) | ((IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag1_hit_m_w) 
                                               & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                                  >> 0x13U)))));
    bufp->fullIData(oldp+684,(0U),32);
    bufp->fullIData(oldp+685,(0xffffffffU),32);
    bufp->fullBit(oldp+686,(0U));
    bufp->fullIData(oldp+687,(0U),32);
    bufp->fullCData(oldp+688,(0U),4);
    bufp->fullCData(oldp+689,(0U),8);
    bufp->fullCData(oldp+690,(0U),2);
    bufp->fullCData(oldp+691,(7U),8);
    bufp->fullCData(oldp+692,(1U),2);
    bufp->fullBit(oldp+693,(1U));
    bufp->fullSData(oldp+694,(0U),11);
    bufp->fullIData(oldp+695,(0x4dU),32);
    bufp->fullIData(oldp+696,(2U),32);
    bufp->fullIData(oldp+697,(1U),32);
    bufp->fullIData(oldp+698,(0x46U),32);
    bufp->fullIData(oldp+699,(0xbU),32);
    bufp->fullIData(oldp+700,(0x100U),32);
    bufp->fullIData(oldp+701,(8U),32);
    bufp->fullIData(oldp+702,(5U),32);
    bufp->fullIData(oldp+703,(0x20U),32);
    bufp->fullIData(oldp+704,(0xcU),32);
    bufp->fullIData(oldp+705,(0x13U),32);
    bufp->fullIData(oldp+706,(0x14U),32);
    bufp->fullIData(oldp+707,(0xdU),32);
    bufp->fullIData(oldp+708,(0x1fU),32);
    bufp->fullCData(oldp+709,(2U),2);
    bufp->fullCData(oldp+710,(3U),2);
    bufp->fullIData(oldp+711,(0x24U),32);
    bufp->fullIData(oldp+712,(3U),32);
    bufp->fullIData(oldp+713,(0x15U),32);
    bufp->fullIData(oldp+714,(4U),32);
    bufp->fullCData(oldp+715,(1U),4);
    bufp->fullCData(oldp+716,(2U),4);
    bufp->fullCData(oldp+717,(3U),4);
    bufp->fullCData(oldp+718,(4U),4);
    bufp->fullCData(oldp+719,(5U),4);
    bufp->fullCData(oldp+720,(6U),4);
    bufp->fullCData(oldp+721,(7U),4);
    bufp->fullCData(oldp+722,(8U),4);
    bufp->fullCData(oldp+723,(9U),4);
    bufp->fullCData(oldp+724,(0xaU),4);
    bufp->fullIData(oldp+725,(0x1bU),32);
    bufp->fullIData(oldp+726,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_b_ra_value_w),32);
    bufp->fullIData(oldp+727,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_b_rb_value_w),32);
    bufp->fullIData(oldp+728,(0x40001100U),32);
    bufp->fullBit(oldp+729,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__m_enabled_r));
    bufp->fullIData(oldp+730,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__m_interrupts_r),32);
    bufp->fullBit(oldp+731,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__s_enabled_r));
    bufp->fullIData(oldp+732,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__s_interrupts_r),32);
}
