// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top___024root.h"

VL_ATTR_COLD void Vriscv_top___024root___initial__TOP__0(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___initial__TOP__0\n"); );
    // Body
    VL_ASSIGN_SII(1,vlSelf->axi_d_rready_o, 1U);
    VL_ASSIGN_SII(1,vlSelf->axi_d_bready_o, 1U);
    VL_ASSIGN_SII(1,vlSelf->axi_i_rready_o, 1U);
    VL_ASSIGN_SUI(2,vlSelf->axi_i_arburst_o, 1U);
    VL_ASSIGN_SUI(8,vlSelf->axi_i_arlen_o, 7U);
    VL_ASSIGN_SUI(4,vlSelf->axi_i_arid_o, 0U);
    VL_ASSIGN_SII(1,vlSelf->axi_i_bready_o, 0U);
    VL_ASSIGN_SII(1,vlSelf->axi_i_wlast_o, 0U);
    VL_ASSIGN_SUI(4,vlSelf->axi_i_wstrb_o, 0U);
    VL_ASSIGN_SUI(32,vlSelf->axi_i_wdata_o, 0U);
    VL_ASSIGN_SII(1,vlSelf->axi_i_wvalid_o, 0U);
    VL_ASSIGN_SUI(2,vlSelf->axi_i_awburst_o, 0U);
    VL_ASSIGN_SUI(8,vlSelf->axi_i_awlen_o, 0U);
    VL_ASSIGN_SUI(4,vlSelf->axi_i_awid_o, 0U);
    VL_ASSIGN_SUI(32,vlSelf->axi_i_awaddr_o, 0U);
    VL_ASSIGN_SII(1,vlSelf->axi_i_awvalid_o, 0U);
}

VL_ATTR_COLD void Vriscv_top___024root___eval_initial(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___eval_initial\n"); );
    // Body
    Vriscv_top___024root___initial__TOP__0(vlSelf);
    vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i = vlSelf->__Vcellinp__v__clk_i;
    vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_i 
        = vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i;
}

VL_ATTR_COLD void Vriscv_top___024root___final(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___final\n"); );
}

VL_ATTR_COLD void Vriscv_top___024root___ctor_var_reset(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->__Vcellinp__v__reset_vector_i = VL_RAND_RESET_I(32);
    vlSelf->__Vcellinp__v__intr_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_d_rlast_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_d_rid_i = VL_RAND_RESET_I(4);
    vlSelf->__Vcellinp__v__axi_d_rresp_i = VL_RAND_RESET_I(2);
    vlSelf->__Vcellinp__v__axi_d_rdata_i = VL_RAND_RESET_I(32);
    vlSelf->__Vcellinp__v__axi_d_rvalid_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_d_arready_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_d_bid_i = VL_RAND_RESET_I(4);
    vlSelf->__Vcellinp__v__axi_d_bresp_i = VL_RAND_RESET_I(2);
    vlSelf->__Vcellinp__v__axi_d_bvalid_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_d_wready_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_d_awready_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_i_rlast_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_i_rid_i = VL_RAND_RESET_I(4);
    vlSelf->__Vcellinp__v__axi_i_rresp_i = VL_RAND_RESET_I(2);
    vlSelf->__Vcellinp__v__axi_i_rdata_i = VL_RAND_RESET_I(32);
    vlSelf->__Vcellinp__v__axi_i_rvalid_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_i_arready_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_i_bid_i = VL_RAND_RESET_I(4);
    vlSelf->__Vcellinp__v__axi_i_bresp_i = VL_RAND_RESET_I(2);
    vlSelf->__Vcellinp__v__axi_i_bvalid_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_i_wready_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__axi_i_awready_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__rst_i = VL_RAND_RESET_I(1);
    vlSelf->__Vcellinp__v__clk_i = VL_RAND_RESET_I(1);
    vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i = VL_RAND_RESET_I(1);
    vlSelf->__Vchglast__TOP____Vcellinp__v__rst_i = VL_RAND_RESET_I(1);
    for (int __Vi0=0; __Vi0<4; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = VL_RAND_RESET_I(1);
    }
}
