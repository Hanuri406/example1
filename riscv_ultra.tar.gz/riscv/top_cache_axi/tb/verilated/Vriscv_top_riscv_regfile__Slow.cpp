// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_riscv_regfile.h"

void Vriscv_top_riscv_regfile___ctor_var_reset(Vriscv_top_riscv_regfile* vlSelf);

Vriscv_top_riscv_regfile::Vriscv_top_riscv_regfile(Vriscv_top__Syms* symsp, const char* name)
    : VerilatedModule{name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vriscv_top_riscv_regfile___ctor_var_reset(this);
}

void Vriscv_top_riscv_regfile::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vriscv_top_riscv_regfile::~Vriscv_top_riscv_regfile() {
}
