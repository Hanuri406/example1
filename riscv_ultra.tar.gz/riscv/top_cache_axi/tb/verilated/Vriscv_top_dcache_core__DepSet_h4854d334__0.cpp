// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_dcache_core.h"

extern const VlUnpacked<VlWide<3>/*79:0*/, 16> Vriscv_top__ConstPool__TABLE_hb125fe79_0;

VL_INLINE_OPT void Vriscv_top_dcache_core___sequent__TOP__v__u_dcache__u_core__0(Vriscv_top_dcache_core* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_top_dcache_core___sequent__TOP__v__u_dcache__u_core__0\n"); );
    // Init
    CData/*3:0*/ __Vtableidx1;
    SData/*10:0*/ __Vdly__data_write_addr_q;
    CData/*7:0*/ __Vdly__flush_addr_q;
    CData/*0:0*/ __Vdly__replace_way_q;
    CData/*7:0*/ __Vdly__pmem_len_q;
    IData/*31:0*/ __Vdly__pmem_addr_q;
    // Body
    __Vdly__pmem_addr_q = vlSelf->__PVT__pmem_addr_q;
    __Vdly__flush_addr_q = vlSelf->__PVT__flush_addr_q;
    __Vdly__data_write_addr_q = vlSelf->__PVT__data_write_addr_q;
    __Vdly__pmem_len_q = vlSelf->__PVT__pmem_len_q;
    __Vdly__replace_way_q = vlSelf->__PVT__replace_way_q;
    if (vlSymsp->TOP.__Vcellinp__v__rst_i) {
        vlSelf->__PVT__pmem_write_data_q = 0U;
        __Vdly__pmem_addr_q = 0U;
        vlSelf->__PVT__pmem_wr_q = 0U;
        vlSelf->__PVT__pmem_rd_q = 0U;
        vlSelf->__PVT__mem_tag_m_q = 0U;
        vlSelf->__PVT__mem_data_m_q = 0U;
        __Vdly__flush_addr_q = 0U;
        vlSelf->__PVT__flush_last_q = 0U;
        vlSelf->__PVT__pmem_wr0_q = 0U;
        __Vdly__data_write_addr_q = 0U;
        __Vdly__pmem_len_q = 0U;
        vlSelf->__PVT__mem_flush_m_q = 0U;
        vlSelf->__PVT__mem_inval_m_q = 0U;
        vlSelf->__PVT__mem_writeback_m_q = 0U;
        vlSelf->__PVT__mem_rd_m_q = 0U;
        vlSelf->__PVT__mem_wr_m_q = 0U;
        vlSelf->__PVT__error_q = 0U;
        __Vdly__replace_way_q = 0U;
        vlSelf->__PVT__mem_addr_m_q = 0U;
        vlSelf->__PVT__flushing_q = 0U;
        vlSelf->__PVT__state_q = 0U;
    } else {
        if ((1U & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w)))) {
            vlSelf->__PVT__pmem_write_data_q = vlSelf->__PVT__pmem_write_data_w;
        }
        if (((0U != (IData)(vlSelf->__PVT__pmem_len_w)) 
             & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w))) {
            __Vdly__pmem_addr_q = ((IData)(4U) + vlSelf->__PVT__pmem_addr_w);
        } else if (vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w) {
            __Vdly__pmem_addr_q = ((IData)(4U) + vlSelf->__PVT__pmem_addr_q);
        }
        if (((0U != (IData)(vlSelf->__PVT__pmem_wr_w)) 
             & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w)))) {
            vlSelf->__PVT__pmem_wr_q = vlSelf->__PVT__pmem_wr_w;
        } else if (vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w) {
            vlSelf->__PVT__pmem_wr_q = 0U;
        }
        if (vlSelf->__PVT__pmem_rd_w) {
            vlSelf->__PVT__pmem_rd_q = (1U & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w)));
        }
        if (vlSelf->__PVT__mem_accept_r) {
            vlSelf->__PVT__mem_tag_m_q = 0U;
            vlSelf->__PVT__mem_data_m_q = vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q;
            vlSelf->__PVT__mem_flush_m_q = vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_flush_w;
            vlSelf->__PVT__mem_inval_m_q = vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_invalidate_w;
            vlSelf->__PVT__mem_writeback_m_q = vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_writeback_w;
            vlSelf->__PVT__mem_rd_m_q = vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_rd_w;
            vlSelf->__PVT__mem_wr_m_q = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                          & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w)))
                                          ? (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w)
                                          : 0U);
            vlSelf->__PVT__mem_addr_m_q = (0xfffffffcU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q);
        } else if (vlSelf->__PVT__mem_ack_r) {
            vlSelf->__PVT__mem_tag_m_q = 0U;
            vlSelf->__PVT__mem_data_m_q = 0U;
            vlSelf->__PVT__mem_flush_m_q = 0U;
            vlSelf->__PVT__mem_inval_m_q = 0U;
            vlSelf->__PVT__mem_writeback_m_q = 0U;
            vlSelf->__PVT__mem_rd_m_q = 0U;
            vlSelf->__PVT__mem_wr_m_q = 0U;
            vlSelf->__PVT__mem_addr_m_q = 0U;
        }
        if (((0U == (IData)(vlSelf->__PVT__state_q)) 
             | ((2U == (IData)(vlSelf->__PVT__state_q)) 
                & (1U == (IData)(vlSelf->__PVT__next_state_r))))) {
            __Vdly__flush_addr_q = (0xffU & ((IData)(1U) 
                                             + (IData)(vlSelf->__PVT__flush_addr_q)));
        } else if ((3U == (IData)(vlSelf->__PVT__state_q))) {
            __Vdly__flush_addr_q = 0U;
        }
        if ((3U == (IData)(vlSelf->__PVT__state_q))) {
            vlSelf->__PVT__flush_last_q = 0U;
        } else if ((0xffU == (IData)(vlSelf->__PVT__flush_addr_q))) {
            vlSelf->__PVT__flush_last_q = 1U;
        }
        if (((7U != (IData)(vlSelf->__PVT__state_q)) 
             & (7U == (IData)(vlSelf->__PVT__next_state_r)))) {
            vlSelf->__PVT__pmem_wr0_q = 1U;
            __Vdly__pmem_len_q = 7U;
        } else {
            if (vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w) {
                vlSelf->__PVT__pmem_wr0_q = 0U;
            }
            if (((IData)(vlSelf->__PVT__pmem_rd_w) 
                 & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w))) {
                __Vdly__pmem_len_q = vlSelf->__PVT__pmem_len_w;
            } else if (((6U == (IData)(vlSelf->__PVT__state_q)) 
                        & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w))) {
                __Vdly__pmem_len_q = (0xffU & ((IData)(vlSelf->__PVT__pmem_len_q) 
                                               - (IData)(1U)));
            } else if (((7U == (IData)(vlSelf->__PVT__state_q)) 
                        & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w))) {
                __Vdly__pmem_len_q = (0xffU & ((IData)(vlSelf->__PVT__pmem_len_q) 
                                               - (IData)(1U)));
            }
        }
        if (((6U != (IData)(vlSelf->__PVT__state_q)) 
             & (6U == (IData)(vlSelf->__PVT__next_state_r)))) {
            __Vdly__data_write_addr_q = (0x7ffU & (vlSelf->__PVT__pmem_addr_w 
                                                   >> 2U));
        } else if (((7U != (IData)(vlSelf->__PVT__state_q)) 
                    & (7U == (IData)(vlSelf->__PVT__next_state_r)))) {
            __Vdly__data_write_addr_q = (0x7ffU & ((IData)(1U) 
                                                   + (IData)(vlSelf->__PVT__data_addr_m_r)));
        } else if (((6U == (IData)(vlSelf->__PVT__state_q)) 
                    & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w))) {
            __Vdly__data_write_addr_q = (0x7ffU & ((IData)(1U) 
                                                   + (IData)(vlSelf->__PVT__data_write_addr_q)));
        } else if (((7U == (IData)(vlSelf->__PVT__state_q)) 
                    & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w))) {
            __Vdly__data_write_addr_q = (0x7ffU & ((IData)(1U) 
                                                   + (IData)(vlSelf->__PVT__data_write_addr_q)));
        }
        if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
             & ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q) 
                & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w)))) {
            vlSelf->__PVT__error_q = 1U;
        } else if (vlSelf->__PVT__mem_ack_r) {
            vlSelf->__PVT__error_q = 0U;
        }
        if (((5U == (IData)(vlSelf->__PVT__state_q)) 
             | (4U == (IData)(vlSelf->__PVT__state_q)))) {
            __Vdly__replace_way_q = (1U & ((IData)(1U) 
                                           + (IData)(vlSelf->__PVT__replace_way_q)));
        } else if (((((IData)(vlSelf->__PVT__flushing_q) 
                      & (IData)(vlSelf->__PVT__tag_dirty_any_m_w)) 
                     & (~ (IData)(vlSelf->__PVT__evict_way_w))) 
                    & (1U != (IData)(vlSelf->__PVT__state_q)))) {
            __Vdly__replace_way_q = (1U & ((IData)(1U) 
                                           + (IData)(vlSelf->__PVT__replace_way_q)));
        } else if (((8U == (IData)(vlSelf->__PVT__state_q)) 
                    & (1U == (IData)(vlSelf->__PVT__next_state_r)))) {
            __Vdly__replace_way_q = 0U;
        } else if (((2U == (IData)(vlSelf->__PVT__state_q)) 
                    & (3U == (IData)(vlSelf->__PVT__next_state_r)))) {
            __Vdly__replace_way_q = 0U;
        } else if (((3U == (IData)(vlSelf->__PVT__state_q)) 
                    & (1U == (IData)(vlSelf->__PVT__next_state_r)))) {
            __Vdly__replace_way_q = 0U;
        } else if ((0xaU == (IData)(vlSelf->__PVT__state_q))) {
            if (vlSelf->__PVT__tag0_hit_m_w) {
                __Vdly__replace_way_q = 0U;
            } else if (vlSelf->__PVT__tag1_hit_m_w) {
                __Vdly__replace_way_q = 1U;
            }
        }
        if (((3U == (IData)(vlSelf->__PVT__state_q)) 
             & (1U == (IData)(vlSelf->__PVT__next_state_r)))) {
            vlSelf->__PVT__flushing_q = 1U;
        } else if (((2U == (IData)(vlSelf->__PVT__state_q)) 
                    & (3U == (IData)(vlSelf->__PVT__next_state_r)))) {
            vlSelf->__PVT__flushing_q = 0U;
        }
        vlSelf->__PVT__state_q = vlSelf->__PVT__next_state_r;
    }
    vlSelf->__PVT__pmem_addr_q = __Vdly__pmem_addr_q;
    vlSelf->__PVT__flush_addr_q = __Vdly__flush_addr_q;
    vlSelf->__PVT__data_write_addr_q = __Vdly__data_write_addr_q;
    vlSelf->__PVT__pmem_len_q = __Vdly__pmem_len_q;
    vlSelf->__PVT__replace_way_q = __Vdly__replace_way_q;
    vlSelf->__PVT__evict_data_r = vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read0_q;
    vlSelf->__PVT__evict_way_r = 0U;
    vlSelf->__PVT__tag0_hit_m_w = ((vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                    >> 0x14U) & ((0x7ffffU 
                                                  & vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q) 
                                                 == 
                                                 (vlSelf->__PVT__mem_addr_m_q 
                                                  >> 0xdU)));
    vlSelf->__PVT__tag1_hit_m_w = ((vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                    >> 0x14U) & ((0x7ffffU 
                                                  & vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q) 
                                                 == 
                                                 (vlSelf->__PVT__mem_addr_m_q 
                                                  >> 0xdU)));
    if (vlSelf->__PVT__replace_way_q) {
        if (vlSelf->__PVT__replace_way_q) {
            vlSelf->__PVT__evict_data_r = vlSymsp->TOP__v__u_dcache__u_core__u_data1.__PVT__ram_read0_q;
        }
    } else {
        vlSelf->__PVT__evict_data_r = vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read0_q;
    }
    vlSelf->__PVT__pmem_write_data_w = ((0U != (IData)(vlSelf->__PVT__pmem_wr_q))
                                         ? vlSelf->__PVT__pmem_write_data_q
                                         : vlSelf->__PVT__evict_data_r);
    vlSelf->__PVT__data_r = vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read0_q;
    if (vlSelf->__PVT__tag0_hit_m_w) {
        vlSelf->__PVT__data_r = vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read0_q;
    } else if (vlSelf->__PVT__tag1_hit_m_w) {
        vlSelf->__PVT__data_r = vlSymsp->TOP__v__u_dcache__u_core__u_data1.__PVT__ram_read0_q;
    }
    vlSelf->__PVT__tag_hit_any_m_w = ((IData)(vlSelf->__PVT__tag0_hit_m_w) 
                                      | (IData)(vlSelf->__PVT__tag1_hit_m_w));
    vlSelf->__PVT__evict_addr_r = ((IData)(vlSelf->__PVT__flushing_q)
                                    ? ((0x7ffff00U 
                                        & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                           << 8U)) 
                                       | (IData)(vlSelf->__PVT__flush_addr_q))
                                    : ((0x7ffff00U 
                                        & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                           << 8U)) 
                                       | (0xffU & (vlSelf->__PVT__mem_addr_m_q 
                                                   >> 5U))));
    if (vlSelf->__PVT__replace_way_q) {
        if (vlSelf->__PVT__replace_way_q) {
            vlSelf->__PVT__evict_way_r = (IData)((0x180000U 
                                                  == 
                                                  (0x180000U 
                                                   & vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q)));
            vlSelf->__PVT__evict_addr_r = ((IData)(vlSelf->__PVT__flushing_q)
                                            ? ((0x7ffff00U 
                                                & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                                   << 8U)) 
                                               | (IData)(vlSelf->__PVT__flush_addr_q))
                                            : ((0x7ffff00U 
                                                & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                                   << 8U)) 
                                               | (0xffU 
                                                  & (vlSelf->__PVT__mem_addr_m_q 
                                                     >> 5U))));
        }
    } else {
        vlSelf->__PVT__evict_way_r = (IData)((0x180000U 
                                              == (0x180000U 
                                                  & vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q)));
        vlSelf->__PVT__evict_addr_r = ((IData)(vlSelf->__PVT__flushing_q)
                                        ? ((0x7ffff00U 
                                            & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                               << 8U)) 
                                           | (IData)(vlSelf->__PVT__flush_addr_q))
                                        : ((0x7ffff00U 
                                            & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                               << 8U)) 
                                           | (0xffU 
                                              & (vlSelf->__PVT__mem_addr_m_q 
                                                 >> 5U))));
    }
    vlSelf->__PVT__evict_way_w = (((IData)(vlSelf->__PVT__flushing_q) 
                                   | (~ (IData)(vlSelf->__PVT__tag_hit_any_m_w))) 
                                  & (IData)(vlSelf->__PVT__evict_way_r));
    vlSelf->__PVT__tag_addr_m_r = (0xffU & (((IData)(vlSelf->__PVT__flushing_q) 
                                             | (0U 
                                                == (IData)(vlSelf->__PVT__state_q)))
                                             ? (IData)(vlSelf->__PVT__flush_addr_q)
                                             : (vlSelf->__PVT__mem_addr_m_q 
                                                >> 5U)));
    vlSelf->__PVT__tag_data_in_m_r = 0U;
    if ((((2U == (IData)(vlSelf->__PVT__state_q)) | 
          (0U == (IData)(vlSelf->__PVT__state_q))) 
         | (IData)(vlSelf->__PVT__flushing_q))) {
        vlSelf->__PVT__tag_data_in_m_r = 0U;
    } else if ((6U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag_data_in_m_r = (0x100000U 
                                          | (vlSelf->__PVT__mem_addr_m_q 
                                             >> 0xdU));
    } else if ((9U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag_data_in_m_r = (vlSelf->__PVT__mem_addr_m_q 
                                          >> 0xdU);
    } else if ((8U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag_data_in_m_r = (0x100000U 
                                          | (vlSelf->__PVT__mem_addr_m_q 
                                             >> 0xdU));
    } else if (((5U == (IData)(vlSelf->__PVT__state_q)) 
                | ((3U == (IData)(vlSelf->__PVT__state_q)) 
                   & (0U != (IData)(vlSelf->__PVT__mem_wr_m_q))))) {
        vlSelf->__PVT__tag_data_in_m_r = (0x180000U 
                                          | (vlSelf->__PVT__mem_addr_m_q 
                                             >> 0xdU));
    }
    __Vtableidx1 = vlSelf->__PVT__state_q;
    vlSelf->__PVT__dbg_state[0U] = Vriscv_top__ConstPool__TABLE_hb125fe79_0
        [__Vtableidx1][0U];
    vlSelf->__PVT__dbg_state[1U] = Vriscv_top__ConstPool__TABLE_hb125fe79_0
        [__Vtableidx1][1U];
    vlSelf->__PVT__dbg_state[2U] = Vriscv_top__ConstPool__TABLE_hb125fe79_0
        [__Vtableidx1][2U];
    vlSelf->__PVT__pmem_wr_w = ((((7U == (IData)(vlSelf->__PVT__state_q)) 
                                  & ((IData)(vlSelf->__PVT__evict_way_w) 
                                     | (IData)(vlSelf->__PVT__mem_writeback_m_q))) 
                                 | (0U != (IData)(vlSelf->__PVT__pmem_wr_q)))
                                 ? 0xfU : 0U);
    vlSelf->__PVT__mem_ack_r = 0U;
    if ((3U == (IData)(vlSelf->__PVT__state_q))) {
        if ((((IData)(vlSelf->__PVT__mem_rd_m_q) | 
              (0U != (IData)(vlSelf->__PVT__mem_wr_m_q))) 
             & (IData)(vlSelf->__PVT__tag_hit_any_m_w))) {
            vlSelf->__PVT__mem_ack_r = 1U;
        } else if ((((IData)(vlSelf->__PVT__mem_flush_m_q) 
                     | (IData)(vlSelf->__PVT__mem_inval_m_q)) 
                    | (IData)(vlSelf->__PVT__mem_writeback_m_q))) {
            vlSelf->__PVT__mem_ack_r = 1U;
        }
    }
}

VL_INLINE_OPT void Vriscv_top_dcache_core___combo__TOP__v__u_dcache__u_core__0(Vriscv_top_dcache_core* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_top_dcache_core___combo__TOP__v__u_dcache__u_core__0\n"); );
    // Body
    vlSelf->__PVT__data0_write_m_r = 0U;
    vlSelf->__PVT__data1_write_m_r = 0U;
    if ((6U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__data0_write_m_r = (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                                           & (~ (IData)(vlSelf->__PVT__replace_way_q)))
                                           ? 0xfU : 0U);
        vlSelf->__PVT__data1_write_m_r = (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                                           & (IData)(vlSelf->__PVT__replace_way_q))
                                           ? 0xfU : 0U);
    } else if (((5U == (IData)(vlSelf->__PVT__state_q)) 
                | (3U == (IData)(vlSelf->__PVT__state_q)))) {
        vlSelf->__PVT__data0_write_m_r = ((IData)(vlSelf->__PVT__mem_wr_m_q) 
                                          & (- (IData)((IData)(vlSelf->__PVT__tag0_hit_m_w))));
        vlSelf->__PVT__data1_write_m_r = ((IData)(vlSelf->__PVT__mem_wr_m_q) 
                                          & (- (IData)((IData)(vlSelf->__PVT__tag1_hit_m_w))));
    }
}

VL_INLINE_OPT void Vriscv_top_dcache_core___combo__TOP__v__u_dcache__u_core__1(Vriscv_top_dcache_core* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_top_dcache_core___combo__TOP__v__u_dcache__u_core__1\n"); );
    // Body
    vlSelf->__PVT__mem_accept_r = 0U;
    if ((3U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__mem_accept_r = (1U & ((~ (((IData)(vlSelf->__PVT__mem_rd_m_q) 
                                                  | (0U 
                                                     != (IData)(vlSelf->__PVT__mem_wr_m_q))) 
                                                 & (~ (IData)(vlSelf->__PVT__tag_hit_any_m_w)))) 
                                             & (~ (
                                                   ((0U 
                                                     != (IData)(vlSelf->__PVT__mem_wr_m_q)) 
                                                    & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_rd_w)) 
                                                   & ((vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q 
                                                       >> 2U) 
                                                      == 
                                                      (vlSelf->__PVT__mem_addr_m_q 
                                                       >> 2U))))));
    }
}

VL_INLINE_OPT void Vriscv_top_dcache_core___sequent__TOP__v__u_dcache__u_core__1(Vriscv_top_dcache_core* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_top_dcache_core___sequent__TOP__v__u_dcache__u_core__1\n"); );
    // Body
    vlSelf->__PVT__tag_dirty_any_m_w = (1U & ((IData)(
                                                      (0x180000U 
                                                       == 
                                                       (0x180000U 
                                                        & vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q))) 
                                              | (IData)(
                                                        (0x180000U 
                                                         == 
                                                         (0x180000U 
                                                          & vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q)))));
}

VL_INLINE_OPT void Vriscv_top_dcache_core___combo__TOP__v__u_dcache__u_core__2(Vriscv_top_dcache_core* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_top_dcache_core___combo__TOP__v__u_dcache__u_core__2\n"); );
    // Body
    vlSelf->__PVT__tag0_write_m_r = 0U;
    vlSelf->__PVT__tag1_write_m_r = 0U;
    if ((0U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag0_write_m_r = 1U;
        vlSelf->__PVT__tag1_write_m_r = 1U;
    } else if ((2U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag0_write_m_r = (1U & (~ (IData)(vlSelf->__PVT__tag_dirty_any_m_w)));
        vlSelf->__PVT__tag1_write_m_r = (1U & (~ (IData)(vlSelf->__PVT__tag_dirty_any_m_w)));
    } else if (((3U == (IData)(vlSelf->__PVT__state_q)) 
                & (0U != (IData)(vlSelf->__PVT__mem_wr_m_q)))) {
        vlSelf->__PVT__tag0_write_m_r = vlSelf->__PVT__tag0_hit_m_w;
        vlSelf->__PVT__tag1_write_m_r = vlSelf->__PVT__tag1_hit_m_w;
    } else if ((5U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag0_write_m_r = (1U & (~ (IData)(vlSelf->__PVT__replace_way_q)));
        vlSelf->__PVT__tag1_write_m_r = vlSelf->__PVT__replace_way_q;
    } else if (((8U == (IData)(vlSelf->__PVT__state_q)) 
                & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w))) {
        vlSelf->__PVT__tag0_write_m_r = (1U & (~ (IData)(vlSelf->__PVT__replace_way_q)));
        vlSelf->__PVT__tag1_write_m_r = vlSelf->__PVT__replace_way_q;
    } else if ((6U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag0_write_m_r = (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                                          & (0U == (IData)(vlSelf->__PVT__pmem_len_q))) 
                                         & (~ (IData)(vlSelf->__PVT__replace_way_q)));
        vlSelf->__PVT__tag1_write_m_r = (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                                          & (0U == (IData)(vlSelf->__PVT__pmem_len_q))) 
                                         & (IData)(vlSelf->__PVT__replace_way_q));
    } else if ((9U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__tag0_write_m_r = vlSelf->__PVT__tag0_hit_m_w;
        vlSelf->__PVT__tag1_write_m_r = vlSelf->__PVT__tag1_hit_m_w;
    }
    vlSelf->__PVT__next_state_r = vlSelf->__PVT__state_q;
    if ((8U & (IData)(vlSelf->__PVT__state_q))) {
        if ((1U & (~ ((IData)(vlSelf->__PVT__state_q) 
                      >> 2U)))) {
            if ((2U & (IData)(vlSelf->__PVT__state_q))) {
                if ((1U & (~ (IData)(vlSelf->__PVT__state_q)))) {
                    vlSelf->__PVT__next_state_r = (
                                                   (((IData)(vlSelf->__PVT__tag0_hit_m_w) 
                                                     & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                                        >> 0x13U)) 
                                                    | ((IData)(vlSelf->__PVT__tag1_hit_m_w) 
                                                       & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                                          >> 0x13U)))
                                                    ? 7U
                                                    : 3U);
                }
            } else if ((1U & (IData)(vlSelf->__PVT__state_q))) {
                vlSelf->__PVT__next_state_r = 3U;
            } else if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                        & (IData)(vlSelf->__PVT__mem_writeback_m_q))) {
                vlSelf->__PVT__next_state_r = 3U;
            } else if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                        & (IData)(vlSelf->__PVT__flushing_q))) {
                vlSelf->__PVT__next_state_r = 1U;
            } else if (vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) {
                vlSelf->__PVT__next_state_r = 6U;
            }
        }
    } else if ((4U & (IData)(vlSelf->__PVT__state_q))) {
        if ((2U & (IData)(vlSelf->__PVT__state_q))) {
            if ((1U & (IData)(vlSelf->__PVT__state_q))) {
                if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w) 
                     & (0U == (IData)(vlSelf->__PVT__pmem_len_q)))) {
                    vlSelf->__PVT__next_state_r = 8U;
                }
            } else if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w) 
                        & (0U == (IData)(vlSelf->__PVT__pmem_len_q)))) {
                vlSelf->__PVT__next_state_r = ((0U 
                                                != (IData)(vlSelf->__PVT__mem_wr_m_q))
                                                ? 5U
                                                : 4U);
            }
        } else {
            vlSelf->__PVT__next_state_r = 3U;
        }
    } else if ((2U & (IData)(vlSelf->__PVT__state_q))) {
        if ((1U & (IData)(vlSelf->__PVT__state_q))) {
            if ((((IData)(vlSelf->__PVT__mem_rd_m_q) 
                  | (0U != (IData)(vlSelf->__PVT__mem_wr_m_q))) 
                 & (~ (IData)(vlSelf->__PVT__tag_hit_any_m_w)))) {
                vlSelf->__PVT__next_state_r = ((IData)(vlSelf->__PVT__evict_way_w)
                                                ? 7U
                                                : 6U);
            } else if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_writeback_w) 
                        & (IData)(vlSelf->__PVT__mem_accept_r))) {
                vlSelf->__PVT__next_state_r = 0xaU;
            } else if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_flush_w) 
                        & (IData)(vlSelf->__PVT__mem_accept_r))) {
                vlSelf->__PVT__next_state_r = 1U;
            } else if (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_invalidate_w) 
                        & (IData)(vlSelf->__PVT__mem_accept_r))) {
                vlSelf->__PVT__next_state_r = 9U;
            }
        } else if (vlSelf->__PVT__tag_dirty_any_m_w) {
            if (vlSelf->__PVT__evict_way_w) {
                vlSelf->__PVT__next_state_r = 7U;
            }
        } else {
            vlSelf->__PVT__next_state_r = ((IData)(vlSelf->__PVT__flush_last_q)
                                            ? 3U : 1U);
        }
    } else if ((1U & (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__next_state_r = 2U;
    } else if (vlSelf->__PVT__flush_last_q) {
        vlSelf->__PVT__next_state_r = 3U;
    }
    vlSelf->__PVT__tag_addr_x_r = (0xffU & (((3U == (IData)(vlSelf->__PVT__state_q)) 
                                             & ((3U 
                                                 == (IData)(vlSelf->__PVT__next_state_r)) 
                                                | (0xaU 
                                                   == (IData)(vlSelf->__PVT__next_state_r))))
                                             ? (vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q 
                                                >> 5U)
                                             : ((IData)(vlSelf->__PVT__flushing_q)
                                                 ? (IData)(vlSelf->__PVT__flush_addr_q)
                                                 : 
                                                (vlSelf->__PVT__mem_addr_m_q 
                                                 >> 5U))));
    vlSelf->__PVT__data_addr_x_r = (0x7ffU & (vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q 
                                              >> 2U));
    vlSelf->__PVT__data_addr_m_r = (0x7ffU & (vlSelf->__PVT__mem_addr_m_q 
                                              >> 2U));
    if (((6U == (IData)(vlSelf->__PVT__state_q)) | 
         (7U == (IData)(vlSelf->__PVT__state_q)))) {
        vlSelf->__PVT__data_addr_x_r = vlSelf->__PVT__data_write_addr_q;
        vlSelf->__PVT__data_addr_m_r = vlSelf->__PVT__data_addr_x_r;
    } else if (((2U == (IData)(vlSelf->__PVT__state_q)) 
                | (0U == (IData)(vlSelf->__PVT__state_q)))) {
        vlSelf->__PVT__data_addr_x_r = ((IData)(vlSelf->__PVT__flush_addr_q) 
                                        << 3U);
        vlSelf->__PVT__data_addr_m_r = vlSelf->__PVT__data_addr_x_r;
    } else if (((7U != (IData)(vlSelf->__PVT__state_q)) 
                & (7U == (IData)(vlSelf->__PVT__next_state_r)))) {
        vlSelf->__PVT__data_addr_x_r = (0x7f8U & (vlSelf->__PVT__mem_addr_m_q 
                                                  >> 2U));
        vlSelf->__PVT__data_addr_m_r = vlSelf->__PVT__data_addr_x_r;
    } else if ((4U == (IData)(vlSelf->__PVT__state_q))) {
        vlSelf->__PVT__data_addr_x_r = (0x7ffU & (vlSelf->__PVT__mem_addr_m_q 
                                                  >> 2U));
    } else {
        vlSelf->__PVT__data_addr_m_r = (0x7ffU & (vlSelf->__PVT__mem_addr_m_q 
                                                  >> 2U));
    }
    vlSelf->__PVT__refill_request_w = ((6U != (IData)(vlSelf->__PVT__state_q)) 
                                       & (6U == (IData)(vlSelf->__PVT__next_state_r)));
    vlSelf->__PVT__pmem_len_w = ((((IData)(vlSelf->__PVT__refill_request_w) 
                                   | (IData)(vlSelf->__PVT__pmem_rd_q)) 
                                  | ((7U == (IData)(vlSelf->__PVT__state_q)) 
                                     & (IData)(vlSelf->__PVT__pmem_wr0_q)))
                                  ? 7U : 0U);
    vlSelf->__PVT__pmem_rd_w = ((IData)(vlSelf->__PVT__refill_request_w) 
                                | (IData)(vlSelf->__PVT__pmem_rd_q));
    vlSelf->__PVT__pmem_addr_w = ((0U != (IData)(vlSelf->__PVT__pmem_len_w))
                                   ? ((IData)(vlSelf->__PVT__pmem_rd_w)
                                       ? (0xffffffe0U 
                                          & vlSelf->__PVT__mem_addr_m_q)
                                       : (vlSelf->__PVT__evict_addr_r 
                                          << 5U)) : vlSelf->__PVT__pmem_addr_q);
}
