// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_dcache.h"

VL_ATTR_COLD void Vriscv_top_dcache___settle__TOP__v__u_dcache__0(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___settle__TOP__v__u_dcache__0\n"); );
    // Body
    vlSelf->__PVT__u_uncached__DOT__req_valid_w = (0U 
                                                   != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__req_accept_w = 
        (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__valid_o 
        = (0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__res_accept_w = 
        (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q));
    vlSelf->__PVT__u_axi__DOT__res_valid_w = (0U != (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q));
    vlSelf->__PVT__u_axi__DOT__res_accept_w = (2U != (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q));
    vlSelf->__PVT__u_axi__DOT__req_valid_w = (0U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_axi__DOT__req_accept_w = (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q));
    vlSelf->__PVT__u_uncached__DOT__req_w[0U] = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q][0U];
    vlSelf->__PVT__u_uncached__DOT__req_w[1U] = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q][1U];
    vlSelf->__PVT__u_uncached__DOT__req_w[2U] = vlSelf->__PVT__u_uncached__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q][2U];
    vlSelf->__PVT__u_axi__DOT__req_w[0U] = vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q][0U];
    vlSelf->__PVT__u_axi__DOT__req_w[1U] = vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q][1U];
    vlSelf->__PVT__u_axi__DOT__req_w[2U] = vlSelf->__PVT__u_axi__DOT__u_req__DOT__ram_q
        [vlSelf->__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q][2U];
    vlSelf->__PVT__u_axi__DOT__req_can_issue_w = ((0U 
                                                   != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)) 
                                                  & (2U 
                                                     != (IData)(vlSelf->__PVT__u_axi__DOT__resp_outstanding_q)));
    if ((0U != (IData)(vlSelf->__PVT__u_mux__DOT__pending_q))) {
        vlSelf->__PVT__pmem_select_w = vlSelf->__PVT__u_mux__DOT__cache_access_q;
        vlSelf->__PVT__u_mux__DOT__hold_w = ((IData)(vlSelf->__PVT__u_mux__DOT__cache_access_q) 
                                             != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
    } else {
        vlSelf->__PVT__pmem_select_w = vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q;
        vlSelf->__PVT__u_mux__DOT__hold_w = 0U;
    }
    vlSelf->__PVT__pmem_ack_w = ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bvalid_i) 
                                 | (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rvalid_i));
    vlSelf->__PVT__u_axi__DOT__resp_pop_w = ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bvalid_i) 
                                             | ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rvalid_i) 
                                                & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rlast_i)));
    vlSelf->__PVT__pmem_error_w = ((IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bvalid_i)
                                    ? (0U != (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_bresp_i))
                                    : (0U != (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_rresp_i)));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w 
        = ((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q) 
           | (IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w));
    vlSelf->__PVT__u_axi__DOT__req_is_write_w = ((IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w) 
                                                 & (~ 
                                                    (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                     >> 4U)));
    if (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q) {
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_id_w 
            = (0xfU & (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                       >> 1U));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w 
            = (3U & (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                     >> 0xdU));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w 
            = ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                << 0x11U) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                             >> 0xfU));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w 
            = (0xfU & ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                        << 0x11U) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                                     >> 0xfU)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w 
            = ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                << 0x1fU) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[0U] 
                             >> 1U));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_len_w 
            = (0xffU & ((vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                         << 0x1bU) | (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[1U] 
                                      >> 5U)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w 
            = (1U & (vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[2U] 
                     >> 0x13U));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w 
            = (1U & vlSelf->__PVT__u_axi__DOT__u_axi__DOT__buf_q[0U]);
    } else {
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_id_w = 0U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w = 1U;
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w 
            = vlSelf->__PVT__u_axi__DOT__req_w[1U];
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w 
            = (0xfU & vlSelf->__PVT__u_axi__DOT__req_w[2U]);
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w 
            = (0xfffffffcU & vlSelf->__PVT__u_axi__DOT__req_w[0U]);
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_len_w 
            = (0xffU & ((vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                         << 0x1bU) | (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                      >> 5U)));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w 
            = (1U & ((IData)(((0U == (0x1fe0U & vlSelf->__PVT__u_axi__DOT__req_w[2U])) 
                              & (0U == (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q)))) 
                     | (1U == (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q))));
        vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w 
            = (1U & (IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w));
    }
    vlSelf->__PVT__pmem_cache_accept_w = ((IData)(vlSelf->__PVT__pmem_select_w) 
                                          & (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)));
    vlSelf->__PVT__u_uncached__DOT__drop_req_w = ((
                                                   (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                                     & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                                    & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                                   | (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                                       & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                                      & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q))) 
                                                  | (((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                                      & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                                     & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)));
    vlSelf->__PVT__mem_cached_invalidate_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                               & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                              & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
    vlSelf->__PVT__mem_cached_writeback_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                              & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                             & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q));
    vlSelf->__PVT__mem_cached_flush_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                          & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w))) 
                                         & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q));
    vlSelf->__PVT__pmem_cache_ack_w = ((IData)(vlSelf->__PVT__u_pmem_mux__DOT__select_q) 
                                       & (IData)(vlSelf->__PVT__pmem_ack_w));
    vlSelf->__PVT__mem_uncached_ack_w = ((IData)(vlSelf->__PVT__u_uncached__DOT__dropped_q) 
                                         | ((~ (IData)(vlSelf->__PVT__u_pmem_mux__DOT__select_q)) 
                                            & (IData)(vlSelf->__PVT__pmem_ack_w)));
    if (vlSelf->__PVT__u_mux__DOT__cache_access_q) {
        vlSelf->__PVT__mem_error_o = vlSymsp->TOP__v__u_dcache__u_core.__PVT__error_q;
        vlSelf->__PVT__mem_ack_o = vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_ack_r;
    } else {
        vlSelf->__PVT__mem_error_o = ((~ (IData)(vlSelf->__PVT__u_pmem_mux__DOT__select_q)) 
                                      & (IData)(vlSelf->__PVT__pmem_error_w));
        vlSelf->__PVT__mem_ack_o = vlSelf->__PVT__mem_uncached_ack_w;
    }
    vlSelf->__PVT__u_uncached__DOT__request_in_progress_w 
        = ((IData)(vlSelf->__PVT__u_uncached__DOT__request_pending_q) 
           & (~ (IData)(vlSelf->__PVT__mem_uncached_ack_w)));
    vlSelf->__PVT__axi_arvalid_o = ((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w) 
                                    & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)));
    vlSelf->__PVT__axi_awvalid_o = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w) 
                                     & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)) 
                                    & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q)));
    vlSelf->__PVT__axi_wvalid_o = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w) 
                                    & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_write_w)) 
                                   & (~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q)));
    vlSelf->__PVT__u_uncached__DOT__req_is_drop_w = 
        (((0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
          & (~ (IData)(vlSelf->__PVT__u_uncached__DOT__request_in_progress_w))) 
         & (vlSelf->__PVT__u_uncached__DOT__req_w[2U] 
            >> 5U));
    vlSelf->__PVT__u_uncached__DOT__req_is_read_w = 
        (((0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
          & (~ (IData)(vlSelf->__PVT__u_uncached__DOT__request_in_progress_w))) 
         & (vlSelf->__PVT__u_uncached__DOT__req_w[2U] 
            >> 4U));
    vlSelf->__PVT__pmem_uncached_wr_w = ((((0U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                                           & (~ (IData)(vlSelf->__PVT__u_uncached__DOT__request_in_progress_w))) 
                                          & (~ (vlSelf->__PVT__u_uncached__DOT__req_w[2U] 
                                                >> 4U)))
                                          ? (0xfU & 
                                             vlSelf->__PVT__u_uncached__DOT__req_w[2U])
                                          : 0U);
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_cmd_accepted_w 
        = (((IData)(vlSelf->__PVT__axi_awvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_awready_i)) 
           | (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__awvalid_q));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_accepted_w 
        = (((IData)(vlSelf->__PVT__axi_wvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i)) 
           | (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q));
    vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wr_data_last_w 
        = (((IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wvalid_q) 
            & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__wlast_q)) 
           | (((IData)(vlSelf->__PVT__axi_wvalid_o) 
               & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i)) 
              & (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w)));
    vlSelf->__PVT__u_axi__DOT__accept_w = ((~ (IData)(vlSelf->__PVT__u_axi__DOT__u_axi__DOT__valid_q)) 
                                           & ((((IData)(vlSelf->__PVT__axi_awvalid_o) 
                                                & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_awready_i)) 
                                               | ((IData)(vlSelf->__PVT__axi_wvalid_o) 
                                                  & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_wready_i))) 
                                              | ((IData)(vlSelf->__PVT__axi_arvalid_o) 
                                                 & (IData)(vlSymsp->TOP.__Vcellinp__v__axi_d_arready_i))));
    vlSelf->__PVT__u_uncached__DOT__request_complete_w 
        = ((IData)(vlSelf->__PVT__u_uncached__DOT__req_is_drop_w) 
           | (((IData)(vlSelf->__PVT__u_uncached__DOT__req_is_read_w) 
               | (0U != (IData)(vlSelf->__PVT__pmem_uncached_wr_w))) 
              & ((~ (IData)(vlSelf->__PVT__pmem_select_w)) 
                 & (2U != (IData)(vlSelf->__PVT__u_axi__DOT__u_req__DOT__count_q)))));
    vlSelf->__PVT__u_pmem_mux__DOT__outport_wr_r = 
        ((IData)(vlSelf->__PVT__pmem_select_w) ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr_w)
          : (IData)(vlSelf->__PVT__pmem_uncached_wr_w));
    vlSelf->__PVT__u_axi__DOT__res_push_w = (((((IData)(vlSelf->__PVT__u_axi__DOT__req_is_write_w) 
                                                & (0U 
                                                   == 
                                                   (0x1fe0U 
                                                    & vlSelf->__PVT__u_axi__DOT__req_w[2U]))) 
                                               & (0U 
                                                  == (IData)(vlSelf->__PVT__u_axi__DOT__req_cnt_q))) 
                                              | ((IData)(vlSelf->__PVT__u_axi__DOT__req_can_issue_w) 
                                                 & (vlSelf->__PVT__u_axi__DOT__req_w[2U] 
                                                    >> 4U))) 
                                             & (IData)(vlSelf->__PVT__u_axi__DOT__accept_w));
}

VL_ATTR_COLD void Vriscv_top_dcache___settle__TOP__v__u_dcache__2(Vriscv_top_dcache* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_top_dcache___settle__TOP__v__u_dcache__2\n"); );
    // Body
    vlSelf->__PVT__mem_accept_o = (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)
                                     ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_accept_r)
                                     : ((2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                                        & (2U != (IData)(vlSelf->__PVT__u_uncached__DOT__u_resp__DOT__count_q)))) 
                                   & (~ (IData)(vlSelf->__PVT__u_mux__DOT__hold_w)));
    vlSelf->__PVT__u_pmem_mux__DOT__outport_rd_r = 
        ((IData)(vlSelf->__PVT__pmem_select_w) ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_rd_w)
          : (IData)(vlSelf->__PVT__u_uncached__DOT__req_is_read_w));
    vlSelf->__PVT__u_mux__DOT__pending_r = vlSelf->__PVT__u_mux__DOT__pending_q;
    if ((((IData)(vlSelf->__PVT__u_mux__DOT__request_w) 
          & (IData)(vlSelf->__PVT__mem_accept_o)) & 
         (~ (IData)(vlSelf->__PVT__mem_ack_o)))) {
        vlSelf->__PVT__u_mux__DOT__pending_r = (0x1fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelf->__PVT__u_mux__DOT__pending_r)));
    } else if (((~ ((IData)(vlSelf->__PVT__u_mux__DOT__request_w) 
                    & (IData)(vlSelf->__PVT__mem_accept_o))) 
                & (IData)(vlSelf->__PVT__mem_ack_o))) {
        vlSelf->__PVT__u_mux__DOT__pending_r = (0x1fU 
                                                & ((IData)(vlSelf->__PVT__u_mux__DOT__pending_r) 
                                                   - (IData)(1U)));
    }
    vlSelf->__PVT__u_axi__DOT__req_push_w = ((IData)(vlSelf->__PVT__u_pmem_mux__DOT__outport_rd_r) 
                                             | (0U 
                                                != (IData)(vlSelf->__PVT__u_pmem_mux__DOT__outport_wr_r)));
}
