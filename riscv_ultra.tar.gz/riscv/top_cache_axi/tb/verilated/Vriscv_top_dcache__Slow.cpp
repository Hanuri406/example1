// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_dcache.h"

void Vriscv_top_dcache___ctor_var_reset(Vriscv_top_dcache* vlSelf);

Vriscv_top_dcache::Vriscv_top_dcache(Vriscv_top__Syms* symsp, const char* name)
    : VerilatedModule{name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vriscv_top_dcache___ctor_var_reset(this);
}

void Vriscv_top_dcache::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vriscv_top_dcache::~Vriscv_top_dcache() {
}
