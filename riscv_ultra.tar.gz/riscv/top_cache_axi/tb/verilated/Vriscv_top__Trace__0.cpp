// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "Vriscv_top__Syms.h"


void Vriscv_top___024root__trace_chg_sub_0(Vriscv_top___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vriscv_top___024root__trace_chg_top_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_chg_top_0\n"); );
    // Init
    Vriscv_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_top___024root*>(voidSelf);
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vriscv_top___024root__trace_chg_sub_0((&vlSymsp->TOP), bufp);
}

void Vriscv_top___024root__trace_chg_sub_0(Vriscv_top___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_chg_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    VlWide<3>/*95:0*/ __Vtemp_hac1c4767__0;
    VlWide<3>/*95:0*/ __Vtemp_h484948a1__0;
    // Body
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[1U])) {
        bufp->chgBit(oldp+0,(vlSelf->__Vcellinp__v__clk_i));
        bufp->chgBit(oldp+1,(vlSelf->__Vcellinp__v__rst_i));
        bufp->chgBit(oldp+2,(vlSelf->__Vcellinp__v__axi_i_awready_i));
        bufp->chgBit(oldp+3,(vlSelf->__Vcellinp__v__axi_i_wready_i));
        bufp->chgBit(oldp+4,(vlSelf->__Vcellinp__v__axi_i_bvalid_i));
        bufp->chgCData(oldp+5,(vlSelf->__Vcellinp__v__axi_i_bresp_i),2);
        bufp->chgCData(oldp+6,(vlSelf->__Vcellinp__v__axi_i_bid_i),4);
        bufp->chgBit(oldp+7,(vlSelf->__Vcellinp__v__axi_i_arready_i));
        bufp->chgBit(oldp+8,(vlSelf->__Vcellinp__v__axi_i_rvalid_i));
        bufp->chgIData(oldp+9,(vlSelf->__Vcellinp__v__axi_i_rdata_i),32);
        bufp->chgCData(oldp+10,(vlSelf->__Vcellinp__v__axi_i_rresp_i),2);
        bufp->chgCData(oldp+11,(vlSelf->__Vcellinp__v__axi_i_rid_i),4);
        bufp->chgBit(oldp+12,(vlSelf->__Vcellinp__v__axi_i_rlast_i));
        bufp->chgBit(oldp+13,(vlSelf->__Vcellinp__v__axi_d_awready_i));
        bufp->chgBit(oldp+14,(vlSelf->__Vcellinp__v__axi_d_wready_i));
        bufp->chgBit(oldp+15,(vlSelf->__Vcellinp__v__axi_d_bvalid_i));
        bufp->chgCData(oldp+16,(vlSelf->__Vcellinp__v__axi_d_bresp_i),2);
        bufp->chgCData(oldp+17,(vlSelf->__Vcellinp__v__axi_d_bid_i),4);
        bufp->chgBit(oldp+18,(vlSelf->__Vcellinp__v__axi_d_arready_i));
        bufp->chgBit(oldp+19,(vlSelf->__Vcellinp__v__axi_d_rvalid_i));
        bufp->chgIData(oldp+20,(vlSelf->__Vcellinp__v__axi_d_rdata_i),32);
        bufp->chgCData(oldp+21,(vlSelf->__Vcellinp__v__axi_d_rresp_i),2);
        bufp->chgCData(oldp+22,(vlSelf->__Vcellinp__v__axi_d_rid_i),4);
        bufp->chgBit(oldp+23,(vlSelf->__Vcellinp__v__axi_d_rlast_i));
        bufp->chgBit(oldp+24,(vlSelf->__Vcellinp__v__intr_i));
        bufp->chgIData(oldp+25,(vlSelf->__Vcellinp__v__reset_vector_i),32);
        bufp->chgBit(oldp+26,(vlSymsp->TOP__v__u_icache.__PVT__axi_arvalid_o));
        bufp->chgBit(oldp+27,(vlSymsp->TOP__v__u_dcache.__PVT__mem_ack_o));
        bufp->chgBit(oldp+28,(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w));
        bufp->chgBit(oldp+29,(vlSymsp->TOP__v__u_dcache.__PVT__mem_accept_o));
        bufp->chgBit(oldp+30,(vlSymsp->TOP__v__u_icache.__PVT__req_accept_o));
        bufp->chgCData(oldp+31,(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w),4);
        bufp->chgBit(oldp+32,(vlSymsp->TOP__v__u_core.__PVT__mmu_ifetch_rd_w));
        bufp->chgBit(oldp+33,(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o));
        bufp->chgCData(oldp+34,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w),8);
        bufp->chgBit(oldp+35,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_accept_r));
        bufp->chgBit(oldp+36,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_ack_w));
        bufp->chgIData(oldp+37,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w),32);
        bufp->chgBit(oldp+38,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_rd_w));
        bufp->chgBit(oldp+39,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w));
        bufp->chgBit(oldp+40,(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_ack_w));
        bufp->chgBit(oldp+41,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_ack_w));
        bufp->chgCData(oldp+42,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_uncached_wr_w),4);
        bufp->chgBit(oldp+43,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_rd_w));
        bufp->chgCData(oldp+44,(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_wr_r),4);
        bufp->chgBit(oldp+45,(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_rd_r));
        bufp->chgCData(oldp+46,(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_wr_w),4);
        bufp->chgBit(oldp+47,(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_rd_w));
        bufp->chgBit(oldp+48,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_is_read_w));
        bufp->chgBit(oldp+49,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__accept_w));
        bufp->chgBit(oldp+50,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_push_w));
        bufp->chgBit(oldp+51,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__res_push_w));
        bufp->chgBit(oldp+52,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_pop_w));
        bufp->chgBit(oldp+53,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wr_cmd_accepted_w));
        bufp->chgBit(oldp+54,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wr_data_accepted_w));
        bufp->chgBit(oldp+55,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wr_data_last_w));
        bufp->chgBit(oldp+56,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__request_w));
        bufp->chgCData(oldp+57,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__pending_r),5);
        bufp->chgBit(oldp+58,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_complete_w));
        bufp->chgBit(oldp+59,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_w));
        bufp->chgBit(oldp+60,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_push_w));
        bufp->chgBit(oldp+61,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__res_push_w));
        bufp->chgBit(oldp+62,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_in_progress_w));
        bufp->chgBit(oldp+63,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_is_drop_w));
        bufp->chgCData(oldp+64,(vlSymsp->TOP__v__u_icache.__PVT__next_state_r),2);
        bufp->chgBit(oldp+65,(vlSymsp->TOP__v__u_icache.__PVT__tag0_write_r));
        bufp->chgBit(oldp+66,(vlSymsp->TOP__v__u_icache.__PVT__tag1_write_r));
        bufp->chgBit(oldp+67,(vlSymsp->TOP__v__u_core__u_issue.__PVT__fetch_accept_o));
        bufp->chgIData(oldp+68,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r),32);
        bufp->chgBit(oldp+69,(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o));
        bufp->chgBit(oldp+70,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_issue_r));
        bufp->chgBit(oldp+71,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_invalid_o));
        bufp->chgBit(oldp+72,(vlSymsp->TOP__v__u_core__u_issue.__PVT__branch_request_o));
        bufp->chgBit(oldp+73,(vlSymsp->TOP__v__u_core.__PVT__writeback_mem_valid_w));
        bufp->chgIData(oldp+74,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r),32);
        bufp->chgBit(oldp+75,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w));
        bufp->chgBit(oldp+76,(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w));
        bufp->chgIData(oldp+77,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__wb_result_r),32);
        bufp->chgIData(oldp+78,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r),32);
        bufp->chgBit(oldp+79,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_start_w));
        bufp->chgIData(oldp+80,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_input_a_r),32);
        bufp->chgIData(oldp+81,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_input_b_r),32);
        bufp->chgIData(oldp+82,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__result_r),32);
        bufp->chgBit(oldp+83,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_r));
        bufp->chgSData(oldp+84,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_fill_r),16);
        bufp->chgIData(oldp+85,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_1_r),32);
        bufp->chgIData(oldp+86,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_2_r),32);
        bufp->chgIData(oldp+87,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_4_r),32);
        bufp->chgIData(oldp+88,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_8_r),32);
        bufp->chgIData(oldp+89,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_1_r),32);
        bufp->chgIData(oldp+90,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_2_r),32);
        bufp->chgIData(oldp+91,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_4_r),32);
        bufp->chgIData(oldp+92,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_8_r),32);
        bufp->chgIData(oldp+93,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__sub_res_w),32);
        bufp->chgBit(oldp+94,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__stall_w));
        bufp->chgBit(oldp+95,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__complete_ok_e2_w));
        bufp->chgBit(oldp+96,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__complete_err_e2_w));
        bufp->chgBit(oldp+97,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w));
        bufp->chgIData(oldp+98,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_r),32);
        bufp->chgBit(oldp+99,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_r));
        bufp->chgIData(oldp+100,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_r),32);
        bufp->chgBit(oldp+101,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_rd_r));
        bufp->chgCData(oldp+102,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_wr_r),4);
        bufp->chgCData(oldp+103,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__addr_lsb_r),2);
        bufp->chgBit(oldp+104,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_byte_r));
        bufp->chgBit(oldp+105,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_half_r));
        bufp->chgBit(oldp+106,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_signed_r));
        bufp->chgBit(oldp+107,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellinp__u_lsu_request__push_i));
        bufp->chgBit(oldp+108,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellinp__u_lsu_request__pop_i));
        bufp->chgCData(oldp+109,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__next_state_r),4);
        bufp->chgCData(oldp+110,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_addr_x_r),8);
        bufp->chgBit(oldp+111,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag0_write_m_r));
        bufp->chgBit(oldp+112,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag1_write_m_r));
        bufp->chgSData(oldp+113,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_x_r),11);
        bufp->chgSData(oldp+114,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_addr_m_r),11);
        bufp->chgCData(oldp+115,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data0_write_m_r),4);
        bufp->chgCData(oldp+116,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data1_write_m_r),4);
        bufp->chgBit(oldp+117,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__refill_request_w));
        bufp->chgBit(oldp+118,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_squash_e1_e2_w));
        bufp->chgBit(oldp+119,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_valid_w));
        bufp->chgBit(oldp+120,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_accept_r));
        bufp->chgCData(oldp+121,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_e2_w),5);
        bufp->chgIData(oldp+122,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_e2_r),32);
        bufp->chgBit(oldp+123,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_valid_wb_w));
        bufp->chgCData(oldp+124,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_wb_w),5);
        bufp->chgIData(oldp+125,(vlSymsp->TOP__v__u_core__u_issue.__PVT__scoreboard_r),32);
        bufp->chgBit(oldp+126,((0U != (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_r))));
        bufp->chgBit(oldp+127,(((IData)(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w) 
                                & (0U != (3U & vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)))));
        bufp->chgBit(oldp+128,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e2_w));
        bufp->chgCData(oldp+129,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_r),6);
        bufp->chgWData(oldp+130,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str),80);
        bufp->chgWData(oldp+133,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra),80);
        bufp->chgWData(oldp+136,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb),80);
        bufp->chgWData(oldp+139,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd),80);
        bufp->chgIData(oldp+142,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm),32);
        bufp->chgIData(oldp+143,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_pc),32);
        bufp->chgWData(oldp+144,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str),80);
        bufp->chgWData(oldp+147,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra),80);
        bufp->chgWData(oldp+150,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb),80);
        bufp->chgWData(oldp+153,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd),80);
        bufp->chgIData(oldp+156,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm),32);
        bufp->chgIData(oldp+157,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_pc),32);
        bufp->chgWData(oldp+158,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str),80);
        bufp->chgWData(oldp+161,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra),80);
        bufp->chgWData(oldp+164,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb),80);
        bufp->chgWData(oldp+167,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd),80);
        bufp->chgIData(oldp+170,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm),32);
        bufp->chgIData(oldp+171,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_pc),32);
        bufp->chgBit(oldp+172,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrw_w));
        bufp->chgBit(oldp+173,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrwi_w));
        bufp->chgBit(oldp+174,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrsi_w));
        bufp->chgBit(oldp+175,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrci_w));
        bufp->chgBit(oldp+176,(vlSymsp->TOP__v__u_core__u_csr.__PVT__sfence_w));
        bufp->chgBit(oldp+177,(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_w));
        bufp->chgBit(oldp+178,(vlSymsp->TOP__v__u_core__u_csr.__PVT__set_r));
        bufp->chgBit(oldp+179,(vlSymsp->TOP__v__u_core__u_csr.__PVT__clr_r));
        bufp->chgIData(oldp+180,(vlSymsp->TOP__v__u_core__u_csr.__PVT__data_r),32);
        bufp->chgBit(oldp+181,(vlSymsp->TOP__v__u_core__u_csr.__PVT__satp_update_w));
        bufp->chgBit(oldp+182,(vlSymsp->TOP__v__u_core__u_csr.__PVT__eret_fault_w));
        bufp->chgIData(oldp+183,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_r),32);
        bufp->chgIData(oldp+184,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_next_r),32);
    }
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[1U] 
                     | vlSelf->__Vm_traceActivity[3U]))) {
        bufp->chgIData(oldp+185,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__cache_access_q)
                                   ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_r
                                   : vlSelf->__Vcellinp__v__axi_d_rdata_i)),32);
        bufp->chgCData(oldp+186,((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q) 
                                   & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w)))
                                   ? (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w)
                                   : 0U)),4);
        bufp->chgBit(oldp+187,(((~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q)) 
                                & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_ack_w))));
        bufp->chgCData(oldp+188,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                   ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w)
                                   : 0U)),8);
        bufp->chgIData(oldp+189,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                   ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                   : (0xfffffffcU & 
                                      vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U]))),32);
        bufp->chgBit(oldp+190,(((~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q)) 
                                & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w))));
        bufp->chgBit(oldp+191,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q) 
                                & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_error_w))));
        __Vtemp_hac1c4767__0[0U] = (IData)((((QData)((IData)(
                                                             ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                               ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                                               : 
                                                              vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U]))) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                                ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                                                : 
                                                               (0xfffffffcU 
                                                                & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U]))))));
        __Vtemp_hac1c4767__0[1U] = (IData)(((((QData)((IData)(
                                                              ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                                ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                                                : 
                                                               vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U]))) 
                                              << 0x20U) 
                                             | (QData)((IData)(
                                                               ((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                                                 ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_w
                                                                 : 
                                                                (0xfffffffcU 
                                                                 & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U]))))) 
                                            >> 0x20U));
        __Vtemp_hac1c4767__0[2U] = ((((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                       ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_w)
                                       : 0U) << 5U) 
                                    | (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_rd_r) 
                                        << 4U) | (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__outport_wr_r)));
        bufp->chgWData(oldp+192,(__Vtemp_hac1c4767__0),77);
        bufp->chgBit(oldp+195,((((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                                 & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_in_progress_w))) 
                                & (~ (vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[2U] 
                                      >> 4U)))));
        __Vtemp_h484948a1__0[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              (0xfffffffcU 
                                                               & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))));
        __Vtemp_h484948a1__0[1U] = (IData)(((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                              << 0x20U) 
                                             | (QData)((IData)(
                                                               (0xfffffffcU 
                                                                & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))) 
                                            >> 0x20U));
        __Vtemp_h484948a1__0[2U] = (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__drop_req_w) 
                                     << 5U) | (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_rd_w) 
                                                << 4U) 
                                               | (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_uncached_wr_w)));
        bufp->chgWData(oldp+196,(__Vtemp_h484948a1__0),70);
        bufp->chgBit(oldp+199,(((IData)(vlSelf->__Vcellinp__v__axi_i_rvalid_i) 
                                & (~ (IData)(vlSymsp->TOP__v__u_icache.__PVT__replace_way_q)))));
        bufp->chgBit(oldp+200,(((IData)(vlSelf->__Vcellinp__v__axi_i_rvalid_i) 
                                & (IData)(vlSymsp->TOP__v__u_icache.__PVT__replace_way_q))));
        bufp->chgIData(oldp+201,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)
                                   ? vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_target_q
                                   : vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)),32);
        bufp->chgBit(oldp+202,(((((((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q) 
                                      | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                     | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                                    | (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w)) 
                                   | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                                  & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_accept_o))) 
                                 | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w)) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q))));
        bufp->chgCData(oldp+203,((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                   & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                                   ? 0x14U : (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                               & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                               ? 0x16U
                                               : (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                                                   & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                                                   ? 0x15U
                                                   : 
                                                  (((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                                                    & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                                    ? 0x17U
                                                    : 0U))))),6);
        bufp->chgBit(oldp+204,(((((((IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w) 
                                    | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                                   | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q)) 
                                  | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                 | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                                & (IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_accept_o))));
        bufp->chgBit(oldp+205,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                                & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
        bufp->chgBit(oldp+206,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__mem_error_o) 
                                & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))));
        bufp->chgQData(oldp+207,(((0x2002033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                   ? (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r))
                                   : ((0x2001033U == 
                                       (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                       ? (((QData)((IData)(
                                                           (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r 
                                                            >> 0x1fU))) 
                                           << 0x20U) 
                                          | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r)))
                                       : (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r))))),33);
        bufp->chgQData(oldp+209,(((0x2002033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                   ? (((QData)((IData)(
                                                       (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r 
                                                        >> 0x1fU))) 
                                       << 0x20U) | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r)))
                                   : ((0x2001033U == 
                                       (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                       ? (((QData)((IData)(
                                                           (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r 
                                                            >> 0x1fU))) 
                                           << 0x20U) 
                                          | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r)))
                                       : (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r))))),33);
        bufp->chgIData(oldp+211,(((6U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q))
                                   ? vlSelf->__Vcellinp__v__axi_d_rdata_i
                                   : vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q)),32);
        bufp->chgBit(oldp+212,((1U & (((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                       >> 3U) & (~ (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w))))));
        bufp->chgBit(oldp+213,((IData)((((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                         >> 9U) & (~ (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w))))));
        bufp->chgBit(oldp+214,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0x73U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+215,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0x100073U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+216,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0x200073U == (0xcfffffffU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+217,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0x2073U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+218,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0x3073U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+219,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0x10500073U == (0xffff8fffU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+220,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                & (0xfU == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+221,(((IData)(((0U != (0xf8000U 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                         | (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrw_w))) 
                                | (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrwi_w))));
        bufp->chgBit(oldp+222,((((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o) 
                                 & ((0x344U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                >> 0x14U)) 
                                    | (0x144U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                  >> 0x14U)))) 
                                | (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_upd_q))));
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[2U])) {
        bufp->chgIData(oldp+223,(vlSymsp->TOP__v__u_icache__u_tag0.__PVT__ram_read_q),20);
        bufp->chgBit(oldp+224,((1U & (vlSymsp->TOP__v__u_icache__u_tag0.__PVT__ram_read_q 
                                      >> 0x13U))));
        bufp->chgIData(oldp+225,((0x7ffffU & vlSymsp->TOP__v__u_icache__u_tag0.__PVT__ram_read_q)),19);
        bufp->chgIData(oldp+226,(vlSymsp->TOP__v__u_icache__u_tag1.__PVT__ram_read_q),20);
        bufp->chgBit(oldp+227,((1U & (vlSymsp->TOP__v__u_icache__u_tag1.__PVT__ram_read_q 
                                      >> 0x13U))));
        bufp->chgIData(oldp+228,((0x7ffffU & vlSymsp->TOP__v__u_icache__u_tag1.__PVT__ram_read_q)),19);
        bufp->chgIData(oldp+229,(vlSymsp->TOP__v__u_icache__u_data0.__PVT__ram_read_q),32);
        bufp->chgIData(oldp+230,(vlSymsp->TOP__v__u_icache__u_data1.__PVT__ram_read_q),32);
        bufp->chgIData(oldp+231,(vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q),21);
        bufp->chgBit(oldp+232,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                      >> 0x14U))));
        bufp->chgBit(oldp+233,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                      >> 0x13U))));
        bufp->chgIData(oldp+234,((0x7ffffU & vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q)),19);
        bufp->chgIData(oldp+235,(vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q),21);
        bufp->chgBit(oldp+236,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                      >> 0x14U))));
        bufp->chgBit(oldp+237,((1U & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                      >> 0x13U))));
        bufp->chgIData(oldp+238,((0x7ffffU & vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q)),19);
        bufp->chgIData(oldp+239,(vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read0_q),32);
        bufp->chgIData(oldp+240,(vlSymsp->TOP__v__u_dcache__u_core__u_data1.__PVT__ram_read0_q),32);
        bufp->chgIData(oldp+241,(vlSymsp->TOP__v__u_dcache__u_core__u_data0.__PVT__ram_read1_q),32);
        bufp->chgIData(oldp+242,(vlSymsp->TOP__v__u_dcache__u_core__u_data1.__PVT__ram_read1_q),32);
        bufp->chgIData(oldp+243,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r1_q),32);
        bufp->chgIData(oldp+244,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r2_q),32);
        bufp->chgIData(oldp+245,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r3_q),32);
        bufp->chgIData(oldp+246,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r4_q),32);
        bufp->chgIData(oldp+247,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r5_q),32);
        bufp->chgIData(oldp+248,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r6_q),32);
        bufp->chgIData(oldp+249,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r7_q),32);
        bufp->chgIData(oldp+250,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r8_q),32);
        bufp->chgIData(oldp+251,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r9_q),32);
        bufp->chgIData(oldp+252,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r10_q),32);
        bufp->chgIData(oldp+253,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r11_q),32);
        bufp->chgIData(oldp+254,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r12_q),32);
        bufp->chgIData(oldp+255,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r13_q),32);
        bufp->chgIData(oldp+256,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r14_q),32);
        bufp->chgIData(oldp+257,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r15_q),32);
        bufp->chgIData(oldp+258,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r16_q),32);
        bufp->chgIData(oldp+259,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r17_q),32);
        bufp->chgIData(oldp+260,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r18_q),32);
        bufp->chgIData(oldp+261,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r19_q),32);
        bufp->chgIData(oldp+262,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r20_q),32);
        bufp->chgIData(oldp+263,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r21_q),32);
        bufp->chgIData(oldp+264,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r22_q),32);
        bufp->chgIData(oldp+265,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r23_q),32);
        bufp->chgIData(oldp+266,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r24_q),32);
        bufp->chgIData(oldp+267,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r25_q),32);
        bufp->chgIData(oldp+268,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r26_q),32);
        bufp->chgIData(oldp+269,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r27_q),32);
        bufp->chgIData(oldp+270,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r28_q),32);
        bufp->chgIData(oldp+271,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r29_q),32);
        bufp->chgIData(oldp+272,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r30_q),32);
        bufp->chgIData(oldp+273,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r31_q),32);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[3U])) {
        bufp->chgIData(oldp+274,((0xffffffe0U & vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q)),32);
        bufp->chgBit(oldp+275,(vlSymsp->TOP__v__u_dcache.__PVT__axi_awvalid_o));
        bufp->chgIData(oldp+276,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w),32);
        bufp->chgCData(oldp+277,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_id_w),4);
        bufp->chgCData(oldp+278,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_len_w),8);
        bufp->chgCData(oldp+279,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w),2);
        bufp->chgBit(oldp+280,(vlSymsp->TOP__v__u_dcache.__PVT__axi_wvalid_o));
        bufp->chgIData(oldp+281,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w),32);
        bufp->chgCData(oldp+282,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w),4);
        bufp->chgBit(oldp+283,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w));
        bufp->chgBit(oldp+284,(vlSymsp->TOP__v__u_dcache.__PVT__axi_arvalid_o));
        bufp->chgBit(oldp+285,(vlSymsp->TOP__v__u_icache.__PVT__req_valid_o));
        bufp->chgBit(oldp+286,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_q) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_invalidate_q))));
        bufp->chgBit(oldp+287,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q));
        bufp->chgBit(oldp+288,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
        bufp->chgSData(oldp+289,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__cache_access_q)
                                   ? (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_tag_m_q)
                                   : vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q
                                  [vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q])),11);
        bufp->chgIData(oldp+290,(vlSymsp->TOP__v__u_icache.__PVT__inst_r),32);
        bufp->chgIData(oldp+291,((0xfffffffcU & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)),32);
        bufp->chgBit(oldp+292,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q));
        bufp->chgBit(oldp+293,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
        bufp->chgBit(oldp+294,(vlSymsp->TOP__v__u_icache.__PVT__axi_error_q));
        bufp->chgIData(oldp+295,((0xfffffffcU & vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q)),32);
        bufp->chgIData(oldp+296,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q),32);
        bufp->chgBit(oldp+297,((((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                 & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w))) 
                                & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q))));
        bufp->chgBit(oldp+298,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_cache_accept_w));
        bufp->chgBit(oldp+299,(((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q)) 
                                & (2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q)))));
        bufp->chgBit(oldp+300,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_invalidate_w));
        bufp->chgBit(oldp+301,(((~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)) 
                                & (2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q)))));
        bufp->chgIData(oldp+302,((0xfffffffcU & vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[0U])),32);
        bufp->chgIData(oldp+303,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_r),32);
        bufp->chgBit(oldp+304,((((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                 & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w))) 
                                & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q))));
        bufp->chgIData(oldp+305,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w)
                                   ? vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w
                                   : vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U])),32);
        bufp->chgSData(oldp+306,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_tag_m_q),11);
        bufp->chgBit(oldp+307,(vlSymsp->TOP__v__u_dcache.__PVT__pmem_select_w));
        bufp->chgBit(oldp+308,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_flush_w));
        bufp->chgBit(oldp+309,((((~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q)) 
                                 & (~ (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w))) 
                                & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q))));
        bufp->chgCData(oldp+310,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr_w),4);
        bufp->chgIData(oldp+311,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w[1U]),32);
        bufp->chgSData(oldp+312,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q
                                 [vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q]),11);
        bufp->chgBit(oldp+313,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q))));
        bufp->chgIData(oldp+314,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_w),32);
        bufp->chgBit(oldp+315,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__error_q));
        bufp->chgBit(oldp+316,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_ack_r));
        bufp->chgBit(oldp+317,(vlSymsp->TOP__v__u_dcache.__PVT__mem_cached_writeback_w));
        bufp->chgBit(oldp+318,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_outstanding_q))));
        bufp->chgBit(oldp+319,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_outstanding_q))));
        bufp->chgBit(oldp+320,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q))));
        bufp->chgWData(oldp+321,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w),77);
        bufp->chgBit(oldp+324,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_can_issue_w));
        bufp->chgBit(oldp+325,(((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_can_issue_w) 
                                & (vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U] 
                                   >> 4U))));
        bufp->chgBit(oldp+326,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_is_write_w));
        bufp->chgCData(oldp+327,((0xffU & (vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U] 
                                           >> 5U))),8);
        bufp->chgCData(oldp+328,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_cnt_q),8);
        bufp->chgBit(oldp+329,((((IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_is_write_w) 
                                 & (0U == (0x1fe0U 
                                           & vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U]))) 
                                & (0U == (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_cnt_q)))));
        bufp->chgCData(oldp+330,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__resp_outstanding_q),2);
        bufp->chgIData(oldp+331,((0xfffffffcU & vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[0U])),32);
        bufp->chgIData(oldp+332,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[1U]),32);
        bufp->chgCData(oldp+333,((0xfU & vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__req_w[2U])),4);
        bufp->chgCData(oldp+334,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__req_cnt_q),8);
        bufp->chgBit(oldp+335,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__valid_q));
        bufp->chgWData(oldp+336,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__buf_q),84);
        bufp->chgBit(oldp+339,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_valid_w));
        bufp->chgBit(oldp+340,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_write_w));
        bufp->chgBit(oldp+341,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__awvalid_q));
        bufp->chgBit(oldp+342,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wvalid_q));
        bufp->chgBit(oldp+343,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__wlast_q));
        bufp->chgWData(oldp+344,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__ram_q[0]),77);
        bufp->chgWData(oldp+347,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__ram_q[1]),77);
        bufp->chgBit(oldp+350,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q));
        bufp->chgBit(oldp+351,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q));
        bufp->chgCData(oldp+352,(vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_req__DOT__count_q),2);
        bufp->chgBit(oldp+353,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__hold_w));
        bufp->chgBit(oldp+354,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__cache_access_q));
        bufp->chgCData(oldp+355,(vlSymsp->TOP__v__u_dcache.__PVT__u_mux__DOT__pending_q),5);
        bufp->chgBit(oldp+356,(vlSymsp->TOP__v__u_dcache.__PVT__u_pmem_mux__DOT__select_q));
        bufp->chgBit(oldp+357,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q))));
        bufp->chgBit(oldp+358,((2U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q))));
        bufp->chgBit(oldp+359,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q))));
        bufp->chgWData(oldp+360,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__req_w),70);
        bufp->chgBit(oldp+363,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__drop_req_w));
        bufp->chgBit(oldp+364,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__request_pending_q));
        bufp->chgBit(oldp+365,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__dropped_q));
        bufp->chgWData(oldp+366,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__ram_q[0]),70);
        bufp->chgWData(oldp+369,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__ram_q[1]),70);
        bufp->chgBit(oldp+372,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__rd_ptr_q));
        bufp->chgBit(oldp+373,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__wr_ptr_q));
        bufp->chgCData(oldp+374,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_req__DOT__count_q),2);
        bufp->chgBit(oldp+375,((0U != (IData)(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q))));
        bufp->chgSData(oldp+376,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q[0]),11);
        bufp->chgSData(oldp+377,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__ram_q[1]),11);
        bufp->chgBit(oldp+378,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__rd_ptr_q));
        bufp->chgBit(oldp+379,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__wr_ptr_q));
        bufp->chgCData(oldp+380,(vlSymsp->TOP__v__u_dcache.__PVT__u_uncached__DOT__u_resp__DOT__count_q),2);
        bufp->chgCData(oldp+381,((0xffU & (vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q 
                                           >> 5U))),8);
        bufp->chgSData(oldp+382,((0x7ffU & (vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q 
                                            >> 2U))),11);
        bufp->chgCData(oldp+383,(vlSymsp->TOP__v__u_icache.__PVT__state_q),2);
        bufp->chgBit(oldp+384,(vlSymsp->TOP__v__u_icache.__PVT__invalidate_q));
        bufp->chgBit(oldp+385,(vlSymsp->TOP__v__u_icache.__PVT__replace_way_q));
        bufp->chgBit(oldp+386,(vlSymsp->TOP__v__u_icache.__PVT__lookup_valid_q));
        bufp->chgIData(oldp+387,(vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q),32);
        bufp->chgIData(oldp+388,((vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q 
                                  >> 0xdU)),19);
        bufp->chgCData(oldp+389,(vlSymsp->TOP__v__u_icache.__PVT__tag_addr_r),8);
        bufp->chgIData(oldp+390,(vlSymsp->TOP__v__u_icache.__PVT__tag_data_in_r),20);
        bufp->chgBit(oldp+391,(vlSymsp->TOP__v__u_icache.__PVT__tag0_hit_w));
        bufp->chgBit(oldp+392,(vlSymsp->TOP__v__u_icache.__PVT__tag1_hit_w));
        bufp->chgBit(oldp+393,(vlSymsp->TOP__v__u_icache.__PVT__tag_hit_any_w));
        bufp->chgSData(oldp+394,(vlSymsp->TOP__v__u_icache.__PVT__data_addr_r),11);
        bufp->chgSData(oldp+395,(vlSymsp->TOP__v__u_icache.__PVT__data_write_addr_q),11);
        bufp->chgCData(oldp+396,(vlSymsp->TOP__v__u_icache.__PVT__flush_addr_q),8);
        bufp->chgBit(oldp+397,(vlSymsp->TOP__v__u_icache.__PVT__axi_arvalid_q));
        bufp->chgCData(oldp+398,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__priv_f_q),2);
        bufp->chgCData(oldp+399,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                           >> 7U))),5);
        bufp->chgBit(oldp+400,(vlSymsp->TOP__v__u_core__u_csr.__PVT__tlb_flush_q));
        bufp->chgIData(oldp+401,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w),32);
        bufp->chgIData(oldp+402,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__pc_m_q),32);
        bufp->chgIData(oldp+403,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__wb_result_q),32);
        bufp->chgBit(oldp+404,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q));
        bufp->chgCData(oldp+405,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                           >> 0x14U))),5);
        bufp->chgBit(oldp+406,((1U & (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                      >> 0x13U))));
        bufp->chgCData(oldp+407,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_wb_q),6);
        bufp->chgBit(oldp+408,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_mul_w));
        bufp->chgBit(oldp+409,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ret_q));
        bufp->chgIData(oldp+410,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_wb_q),32);
        bufp->chgCData(oldp+411,(vlSymsp->TOP__v__u_core__u_csr.__PVT__exception_e1_q),6);
        bufp->chgIData(oldp+412,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_target_q),32);
        bufp->chgBit(oldp+413,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w));
        bufp->chgIData(oldp+414,(vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w),32);
        bufp->chgBit(oldp+415,(vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__u_dec__DOT__invalid_w));
        bufp->chgCData(oldp+416,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                           >> 0xfU))),5);
        bufp->chgBit(oldp+417,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ntaken_q));
        bufp->chgIData(oldp+418,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__pc_x_q),32);
        bufp->chgBit(oldp+419,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_q));
        bufp->chgBit(oldp+420,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w));
        bufp->chgBit(oldp+421,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_valid_w));
        bufp->chgCData(oldp+422,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o),2);
        bufp->chgBit(oldp+423,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_q) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ntaken_q))));
        bufp->chgCData(oldp+424,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)
                                   ? (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o)
                                   : (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__priv_x_q))),2);
        bufp->chgBit(oldp+425,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_pending_q) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w))));
        bufp->chgBit(oldp+426,((((((((((3U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                       | (0x1003U == 
                                          (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                      | (0x2003U == 
                                         (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                     | (0x4003U == 
                                        (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                    | (0x5003U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x6003U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x23U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x1023U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2023U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgCData(oldp+427,((3U & ((0x20000U & vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q)
                                         ? (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                            >> 0xbU)
                                         : (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q)))),2);
        bufp->chgBit(oldp+428,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__valid_q));
        bufp->chgBit(oldp+429,(((((((((0x6fU == (0x7fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                      | (0x67U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                     | (0x63U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                    | (0x1063U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x4063U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x5063U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x6063U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x7063U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgIData(oldp+430,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_q),32);
        bufp->chgIData(oldp+431,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csr_wdata_e1_q),32);
        bufp->chgBit(oldp+432,(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_q));
        bufp->chgBit(oldp+433,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_exec_w));
        bufp->chgIData(oldp+434,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wdata_wb_q),32);
        bufp->chgBit(oldp+435,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_wb_q));
        bufp->chgBit(oldp+436,(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q));
        bufp->chgIData(oldp+437,(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_result_e1_q),32);
        bufp->chgSData(oldp+438,((vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                  >> 0x14U)),12);
        bufp->chgBit(oldp+439,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_jmp_q));
        bufp->chgBit(oldp+440,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w));
        bufp->chgIData(oldp+441,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_instr_w),32);
        bufp->chgBit(oldp+442,(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_valid_e1_q));
        bufp->chgBit(oldp+443,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w));
        bufp->chgBit(oldp+444,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w));
        bufp->chgIData(oldp+445,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e2_q),32);
        bufp->chgBit(oldp+446,((1U & (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                      >> 0x12U))));
        bufp->chgIData(oldp+447,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__result_q),32);
        bufp->chgIData(oldp+448,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_wb_q),32);
        bufp->chgBit(oldp+449,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_call_q));
        bufp->chgBit(oldp+450,(((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w))));
        bufp->chgBit(oldp+451,((0x2004033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+452,((0x2005033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+453,((0x2006033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+454,((0x2007033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+455,(((((0x2004033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                  | (0x2005033U == 
                                     (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x2006033U == (0xfe00707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2007033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+456,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__signed_operation_w));
        bufp->chgBit(oldp+457,(((0x2004033U == (0xfe00707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x2005033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgIData(oldp+458,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q),32);
        bufp->chgQData(oldp+459,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__divisor_q),63);
        bufp->chgIData(oldp+461,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q),32);
        bufp->chgIData(oldp+462,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__q_mask_q),32);
        bufp->chgBit(oldp+463,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_inst_q));
        bufp->chgBit(oldp+464,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_busy_q));
        bufp->chgBit(oldp+465,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q));
        bufp->chgBit(oldp+466,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_complete_w));
        bufp->chgIData(oldp+467,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_inst_q)
                                   ? ((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q)
                                       ? (- vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q)
                                       : vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q)
                                   : ((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q)
                                       ? (- vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q)
                                       : vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q))),32);
        bufp->chgIData(oldp+468,((0xfffff000U & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)),32);
        bufp->chgIData(oldp+469,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__imm12_r),32);
        bufp->chgIData(oldp+470,((((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                               >> 0x1fU))) 
                                   << 0xdU) | ((0x1000U 
                                                & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                   >> 0x13U)) 
                                               | ((0x800U 
                                                   & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                      << 4U)) 
                                                  | ((0x7e0U 
                                                      & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                         >> 0x14U)) 
                                                     | (0x1eU 
                                                        & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                           >> 7U))))))),32);
        bufp->chgIData(oldp+471,((((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                               >> 0x1fU))) 
                                   << 0x14U) | ((0xff000U 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w) 
                                                | ((0x800U 
                                                    & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                       >> 9U)) 
                                                   | ((0x7e0U 
                                                       & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                          >> 0x14U)) 
                                                      | (0x1eU 
                                                         & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                            >> 0x14U))))))),32);
        bufp->chgCData(oldp+472,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_func_r),4);
        bufp->chgBit(oldp+473,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_r));
        bufp->chgBit(oldp+474,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_call_r));
        bufp->chgBit(oldp+475,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ret_r));
        bufp->chgBit(oldp+476,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_jmp_r));
        bufp->chgBit(oldp+477,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__active_q));
        bufp->chgBit(oldp+478,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_busy_w));
        bufp->chgBit(oldp+479,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_q));
        bufp->chgIData(oldp+480,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_pc_q),32);
        bufp->chgCData(oldp+481,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_priv_q),2);
        bufp->chgBit(oldp+482,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__stall_q));
        bufp->chgBit(oldp+483,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_fetch_q));
        bufp->chgBit(oldp+484,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_invalidate_q));
        bufp->chgIData(oldp+485,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q),32);
        bufp->chgIData(oldp+486,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_d_q),32);
        bufp->chgBit(oldp+487,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_q) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_d_q))));
        bufp->chgBit(oldp+488,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_d_q));
        bufp->chgWData(oldp+489,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__skid_buffer_q),66);
        bufp->chgBit(oldp+492,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__skid_valid_q));
        bufp->chgIData(oldp+493,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q),32);
        bufp->chgBit(oldp+494,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_rd_q));
        bufp->chgCData(oldp+495,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_wr_q),4);
        bufp->chgBit(oldp+496,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q));
        bufp->chgBit(oldp+497,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q));
        bufp->chgBit(oldp+498,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_load_q));
        bufp->chgBit(oldp+499,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xb_q));
        bufp->chgBit(oldp+500,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xh_q));
        bufp->chgBit(oldp+501,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_ls_q));
        bufp->chgBit(oldp+502,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__pending_lsu_e2_q));
        bufp->chgBit(oldp+503,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_inst_w));
        bufp->chgBit(oldp+504,((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x1003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+505,((((0x23U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x1023U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2023U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+506,(((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x4003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+507,(((0x1003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x5003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+508,(((0x2003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x6003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+509,((0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+510,((0x1023U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+511,((0x2023U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+512,((((0x2023U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x2003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x6003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+513,((((0x1023U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x1003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x5003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+514,((IData)((0x3a001073U 
                                        == (0xfff0707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+515,((IData)((0x3a101073U 
                                        == (0xfff0707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+516,((IData)((0x3a201073U 
                                        == (0xfff0707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+517,((1U & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
        bufp->chgIData(oldp+518,((IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                          >> 4U))),32);
        bufp->chgBit(oldp+519,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                              >> 1U)))));
        bufp->chgBit(oldp+520,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                              >> 2U)))));
        bufp->chgBit(oldp+521,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                              >> 3U)))));
        bufp->chgBit(oldp+522,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
        bufp->chgBit(oldp+523,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))));
        bufp->chgQData(oldp+524,((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                                   << 4U) | (QData)((IData)(
                                                            (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_ls_q) 
                                                              << 3U) 
                                                             | (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xh_q) 
                                                                 << 2U) 
                                                                | (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xb_q) 
                                                                    << 1U) 
                                                                   | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_load_q)))))))),36);
        bufp->chgQData(oldp+526,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o),36);
        bufp->chgBit(oldp+528,((2U != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q))));
        bufp->chgBit(oldp+529,((0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q))));
        bufp->chgQData(oldp+530,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__ram_q[0]),36);
        bufp->chgQData(oldp+532,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__ram_q[1]),36);
        bufp->chgBit(oldp+534,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__rd_ptr_q));
        bufp->chgBit(oldp+535,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__wr_ptr_q));
        bufp->chgCData(oldp+536,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q),2);
        bufp->chgIData(oldp+537,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__i),32);
        bufp->chgIData(oldp+538,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e3_q),32);
        bufp->chgQData(oldp+539,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__operand_a_e1_q),33);
        bufp->chgQData(oldp+541,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__operand_b_e1_q),33);
        bufp->chgBit(oldp+543,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mulhi_sel_e1_q));
        bufp->chgWData(oldp+544,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w),65);
        bufp->chgIData(oldp+547,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mulhi_sel_e1_q)
                                   ? vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w[1U]
                                   : vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w[0U])),32);
        bufp->chgCData(oldp+548,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q),4);
        bufp->chgIData(oldp+549,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_addr_m_q),32);
        bufp->chgIData(oldp+550,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_data_m_q),32);
        bufp->chgCData(oldp+551,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_wr_m_q),4);
        bufp->chgBit(oldp+552,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_rd_m_q));
        bufp->chgBit(oldp+553,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_inval_m_q));
        bufp->chgBit(oldp+554,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_writeback_m_q));
        bufp->chgBit(oldp+555,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_flush_m_q));
        bufp->chgIData(oldp+556,((vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_addr_m_q 
                                  >> 0xdU)),19);
        bufp->chgBit(oldp+557,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__replace_way_q));
        bufp->chgBit(oldp+558,((0U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_q))));
        bufp->chgBit(oldp+559,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_way_w));
        bufp->chgBit(oldp+560,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__flushing_q));
        bufp->chgCData(oldp+561,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_addr_m_r),8);
        bufp->chgIData(oldp+562,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_data_in_m_r),21);
        bufp->chgBit(oldp+563,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag0_hit_m_w));
        bufp->chgBit(oldp+564,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag1_hit_m_w));
        bufp->chgBit(oldp+565,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_hit_any_m_w));
        bufp->chgBit(oldp+566,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_way_r));
        bufp->chgIData(oldp+567,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_data_r),32);
        bufp->chgIData(oldp+568,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_addr_r),27);
        bufp->chgSData(oldp+569,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__data_write_addr_q),11);
        bufp->chgCData(oldp+570,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__flush_addr_q),8);
        bufp->chgBit(oldp+571,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__flush_last_q));
        bufp->chgBit(oldp+572,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_rd_q));
        bufp->chgBit(oldp+573,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr0_q));
        bufp->chgCData(oldp+574,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_len_q),8);
        bufp->chgIData(oldp+575,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_addr_q),32);
        bufp->chgCData(oldp+576,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_wr_q),4);
        bufp->chgIData(oldp+577,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__pmem_write_data_q),32);
        bufp->chgBit(oldp+578,(((7U == (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__state_q)) 
                                & ((IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__evict_way_w) 
                                   | (IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__mem_writeback_m_q)))));
        bufp->chgWData(oldp+579,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__dbg_state),80);
        bufp->chgCData(oldp+582,(vlSymsp->TOP__v__u_core__u_issue.__PVT__priv_x_q),2);
        bufp->chgBit(oldp+583,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 1U))));
        bufp->chgBit(oldp+584,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 2U))));
        bufp->chgBit(oldp+585,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 5U))));
        bufp->chgBit(oldp+586,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 6U))));
        bufp->chgCData(oldp+587,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_e1_w),5);
        bufp->chgIData(oldp+588,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_e1_q),32);
        bufp->chgIData(oldp+589,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_e1_q),32);
        bufp->chgIData(oldp+590,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q),32);
        bufp->chgIData(oldp+591,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q),32);
        bufp->chgBit(oldp+592,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                      >> 1U))));
        bufp->chgBit(oldp+593,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                      >> 5U))));
        bufp->chgIData(oldp+594,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q),32);
        bufp->chgIData(oldp+595,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_wb_q),32);
        bufp->chgIData(oldp+596,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_wb_q),32);
        bufp->chgCData(oldp+597,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_fault_w),6);
        bufp->chgBit(oldp+598,(vlSymsp->TOP__v__u_core__u_issue.__PVT__div_pending_q));
        bufp->chgBit(oldp+599,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_pending_q));
        bufp->chgIData(oldp+600,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__ra0_value_r),32);
        bufp->chgIData(oldp+601,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__rb0_value_r),32);
        bufp->chgCData(oldp+602,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                           >> 0xfU))),5);
        bufp->chgCData(oldp+603,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                           >> 0x14U))),5);
        bufp->chgBit(oldp+604,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e1_q));
        bufp->chgSData(oldp+605,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q),10);
        bufp->chgIData(oldp+606,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_e1_q),32);
        bufp->chgCData(oldp+607,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e1_q),6);
        bufp->chgBit(oldp+608,((1U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))));
        bufp->chgBit(oldp+609,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 3U))));
        bufp->chgBit(oldp+610,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 4U))));
        bufp->chgBit(oldp+611,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e2_q));
        bufp->chgSData(oldp+612,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q),10);
        bufp->chgBit(oldp+613,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_e2_q));
        bufp->chgIData(oldp+614,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wdata_e2_q),32);
        bufp->chgIData(oldp+615,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_e2_q),32);
        bufp->chgIData(oldp+616,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_e2_q),32);
        bufp->chgIData(oldp+617,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_e2_q),32);
        bufp->chgIData(oldp+618,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_e2_q),32);
        bufp->chgIData(oldp+619,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q),32);
        bufp->chgIData(oldp+620,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q),32);
        bufp->chgCData(oldp+621,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_q),6);
        bufp->chgBit(oldp+622,((IData)((0U != (6U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q))))));
        bufp->chgBit(oldp+623,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__squash_e1_e2_q));
        bufp->chgBit(oldp+624,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_wb_q));
        bufp->chgSData(oldp+625,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q),10);
        bufp->chgIData(oldp+626,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_wb_q),32);
        bufp->chgCData(oldp+627,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                           >> 7U))),5);
        bufp->chgCData(oldp+628,((3U & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                        >> 0x1cU))),2);
        bufp->chgCData(oldp+629,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q),2);
        bufp->chgBit(oldp+630,((3U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                       >> 0x1eU))));
        bufp->chgIData(oldp+631,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__rdata_r),32);
        bufp->chgBit(oldp+632,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__branch_r));
        bufp->chgIData(oldp+633,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__branch_target_r),32);
        bufp->chgIData(oldp+634,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_masked_r),32);
        bufp->chgIData(oldp+635,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q),32);
        bufp->chgBit(oldp+636,(vlSymsp->TOP__v__u_core__u_csr.__PVT__reset_q));
        bufp->chgSData(oldp+637,((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                  >> 0x14U)),12);
        bufp->chgSData(oldp+638,(vlSymsp->TOP__v__u_core__u_csr.__Vcellinp__u_csrfile__csr_waddr_i),12);
        bufp->chgIData(oldp+639,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mepc_q),32);
        bufp->chgIData(oldp+640,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcause_q),32);
        bufp->chgIData(oldp+641,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtvec_q),32);
        bufp->chgIData(oldp+642,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_q),32);
        bufp->chgIData(oldp+643,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mie_q),32);
        bufp->chgIData(oldp+644,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_q),32);
        bufp->chgIData(oldp+645,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_h_q),32);
        bufp->chgIData(oldp+646,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mscratch_q),32);
        bufp->chgIData(oldp+647,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtval_q),32);
        bufp->chgIData(oldp+648,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtimecmp_q),32);
        bufp->chgBit(oldp+649,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtime_ie_q));
        bufp->chgIData(oldp+650,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_medeleg_q),32);
        bufp->chgIData(oldp+651,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mideleg_q),32);
        bufp->chgIData(oldp+652,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sepc_q),32);
        bufp->chgIData(oldp+653,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stvec_q),32);
        bufp->chgIData(oldp+654,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_scause_q),32);
        bufp->chgIData(oldp+655,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stval_q),32);
        bufp->chgIData(oldp+656,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sscratch_q),32);
        bufp->chgIData(oldp+657,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_pending_r),32);
        bufp->chgCData(oldp+658,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_priv_q),2);
        bufp->chgBit(oldp+659,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_upd_q));
        bufp->chgIData(oldp+660,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mepc_r),32);
        bufp->chgIData(oldp+661,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcause_r),32);
        bufp->chgIData(oldp+662,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtval_r),32);
        bufp->chgIData(oldp+663,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_r),32);
        bufp->chgIData(oldp+664,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtvec_r),32);
        bufp->chgIData(oldp+665,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mie_r),32);
        bufp->chgCData(oldp+666,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_r),2);
        bufp->chgIData(oldp+667,(((IData)(1U) + vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_q)),32);
        bufp->chgIData(oldp+668,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mscratch_r),32);
        bufp->chgIData(oldp+669,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtimecmp_r),32);
        bufp->chgBit(oldp+670,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtime_ie_r));
        bufp->chgIData(oldp+671,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_medeleg_r),32);
        bufp->chgIData(oldp+672,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mideleg_r),32);
        bufp->chgIData(oldp+673,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_next_q),32);
        bufp->chgIData(oldp+674,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sepc_r),32);
        bufp->chgIData(oldp+675,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stvec_r),32);
        bufp->chgIData(oldp+676,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_scause_r),32);
        bufp->chgIData(oldp+677,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stval_r),32);
        bufp->chgIData(oldp+678,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_r),32);
        bufp->chgIData(oldp+679,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sscratch_r),32);
        bufp->chgBit(oldp+680,((0x10U == (0x30U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_wb_q)))));
    }
    bufp->chgBit(oldp+681,(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag_dirty_any_m_w));
    bufp->chgBit(oldp+682,((((IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag0_hit_m_w) 
                             & (vlSymsp->TOP__v__u_dcache__u_core__u_tag0.__PVT__ram_read0_q 
                                >> 0x13U)) | ((IData)(vlSymsp->TOP__v__u_dcache__u_core.__PVT__tag1_hit_m_w) 
                                              & (vlSymsp->TOP__v__u_dcache__u_core__u_tag1.__PVT__ram_read0_q 
                                                 >> 0x13U)))));
}

void Vriscv_top___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root__trace_cleanup\n"); );
    // Init
    Vriscv_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_top___024root*>(voidSelf);
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
}
