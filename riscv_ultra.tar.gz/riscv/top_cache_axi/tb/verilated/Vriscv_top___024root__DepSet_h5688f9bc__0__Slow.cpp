// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top___024root.h"

VL_ATTR_COLD void Vriscv_top___024root___settle__TOP__0(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___settle__TOP__0\n"); );
    // Body
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_d_rid_i, vlSelf->axi_d_rid_i);
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_d_bid_i, vlSelf->axi_d_bid_i);
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_i_rid_i, vlSelf->axi_i_rid_i);
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_i_bid_i, vlSelf->axi_i_bid_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_i_bresp_i, vlSelf->axi_i_bresp_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_bvalid_i, vlSelf->axi_i_bvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_wready_i, vlSelf->axi_i_wready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_awready_i, vlSelf->axi_i_awready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_d_rlast_i, vlSelf->axi_d_rlast_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__intr_i, vlSelf->intr_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_d_rresp_i, vlSelf->axi_d_rresp_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_d_bresp_i, vlSelf->axi_d_bresp_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_d_rvalid_i, vlSelf->axi_d_rvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_d_bvalid_i, vlSelf->axi_d_bvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__clk_i, vlSelf->clk_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_i_rresp_i, vlSelf->axi_i_rresp_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__axi_i_rdata_i, vlSelf->axi_i_rdata_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_arready_i, vlSelf->axi_i_arready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_d_arready_i, vlSelf->axi_d_arready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_d_awready_i, vlSelf->axi_d_awready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_d_wready_i, vlSelf->axi_d_wready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_rlast_i, vlSelf->axi_i_rlast_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_rvalid_i, vlSelf->axi_i_rvalid_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__axi_d_rdata_i, vlSelf->axi_d_rdata_i);
    VL_ASSIGN_SUI(32,vlSelf->axi_i_araddr_o, (0xffffffe0U 
                                              & vlSymsp->TOP__v__u_icache.__PVT__lookup_addr_q));
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__reset_vector_i, vlSelf->reset_vector_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__rst_i, vlSelf->rst_i);
}

VL_ATTR_COLD void Vriscv_top___024root___settle__TOP__1(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___settle__TOP__1\n"); );
    // Body
    VL_ASSIGN_SUI(4,vlSelf->axi_d_arid_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_id_w);
    VL_ASSIGN_SUI(4,vlSelf->axi_d_awid_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_id_w);
    VL_ASSIGN_SUI(2,vlSelf->axi_d_arburst_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w);
    VL_ASSIGN_SUI(2,vlSelf->axi_d_awburst_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_burst_w);
    VL_ASSIGN_SUI(32,vlSelf->axi_d_wdata_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wdata_w);
    VL_ASSIGN_SUI(4,vlSelf->axi_d_wstrb_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wstrb_w);
    VL_ASSIGN_SUI(32,vlSelf->axi_d_araddr_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w);
    VL_ASSIGN_SUI(32,vlSelf->axi_d_awaddr_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_addr_w);
    VL_ASSIGN_SUI(8,vlSelf->axi_d_arlen_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_len_w);
    VL_ASSIGN_SUI(8,vlSelf->axi_d_awlen_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_len_w);
    VL_ASSIGN_SII(1,vlSelf->axi_d_wlast_o, vlSymsp->TOP__v__u_dcache.__PVT__u_axi__DOT__u_axi__DOT__inport_wlast_w);
    VL_ASSIGN_SII(1,vlSelf->axi_d_arvalid_o, vlSymsp->TOP__v__u_dcache.__PVT__axi_arvalid_o);
    VL_ASSIGN_SII(1,vlSelf->axi_d_awvalid_o, vlSymsp->TOP__v__u_dcache.__PVT__axi_awvalid_o);
    VL_ASSIGN_SII(1,vlSelf->axi_d_wvalid_o, vlSymsp->TOP__v__u_dcache.__PVT__axi_wvalid_o);
    VL_ASSIGN_SII(1,vlSelf->axi_i_arvalid_o, vlSymsp->TOP__v__u_icache.__PVT__axi_arvalid_o);
}

VL_ATTR_COLD void Vriscv_top_dcache_core___settle__TOP__v__u_dcache__u_core__0(Vriscv_top_dcache_core* vlSelf);
VL_ATTR_COLD void Vriscv_top_dcache___settle__TOP__v__u_dcache__0(Vriscv_top_dcache* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_core__M0_MBffffffff___settle__TOP__v__u_core__0(Vriscv_top_riscv_core__M0_MBffffffff* vlSelf);
VL_ATTR_COLD void Vriscv_top_icache___settle__TOP__v__u_icache__0(Vriscv_top_icache* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_csr_regfile___settle__TOP__v__u_core__u_csr__u_csrfile__0(Vriscv_top_riscv_csr_regfile* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_csr__SB0___settle__TOP__v__u_core__u_csr__0(Vriscv_top_riscv_csr__SB0* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_issue___settle__TOP__v__u_core__u_issue__0(Vriscv_top_riscv_issue* vlSelf);
VL_ATTR_COLD void Vriscv_top_dcache_core___settle__TOP__v__u_dcache__u_core__1(Vriscv_top_dcache_core* vlSelf);
void Vriscv_top_dcache___combo__TOP__v__u_dcache__2(Vriscv_top_dcache* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_core__M0_MBffffffff___settle__TOP__v__u_core__1(Vriscv_top_riscv_core__M0_MBffffffff* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_csr_regfile___settle__TOP__v__u_core__u_csr__u_csrfile__1(Vriscv_top_riscv_csr_regfile* vlSelf);
VL_ATTR_COLD void Vriscv_top_dcache_core___settle__TOP__v__u_dcache__u_core__2(Vriscv_top_dcache_core* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_issue___settle__TOP__v__u_core__u_issue__1(Vriscv_top_riscv_issue* vlSelf);
void Vriscv_top_riscv_regfile___sequent__TOP__v__u_core__u_issue__u_regfile__1(Vriscv_top_riscv_regfile* vlSelf);
VL_ATTR_COLD void Vriscv_top_dcache___settle__TOP__v__u_dcache__2(Vriscv_top_dcache* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_issue___settle__TOP__v__u_core__u_issue__2(Vriscv_top_riscv_issue* vlSelf);
VL_ATTR_COLD void Vriscv_top_riscv_core__M0_MBffffffff___settle__TOP__v__u_core__2(Vriscv_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_top_riscv_csr__SB0___combo__TOP__v__u_core__u_csr__0(Vriscv_top_riscv_csr__SB0* vlSelf);
void Vriscv_top_riscv_issue___combo__TOP__v__u_core__u_issue__2(Vriscv_top_riscv_issue* vlSelf);

VL_ATTR_COLD void Vriscv_top___024root___eval_settle(Vriscv_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_top___024root___eval_settle\n"); );
    // Body
    Vriscv_top___024root___settle__TOP__0(vlSelf);
    vlSelf->__Vm_traceActivity[3U] = 1U;
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->__Vm_traceActivity[1U] = 1U;
    vlSelf->__Vm_traceActivity[0U] = 1U;
    Vriscv_top_dcache_core___settle__TOP__v__u_dcache__u_core__0((&vlSymsp->TOP__v__u_dcache__u_core));
    Vriscv_top_dcache___settle__TOP__v__u_dcache__0((&vlSymsp->TOP__v__u_dcache));
    Vriscv_top_riscv_core__M0_MBffffffff___settle__TOP__v__u_core__0((&vlSymsp->TOP__v__u_core));
    Vriscv_top_icache___settle__TOP__v__u_icache__0((&vlSymsp->TOP__v__u_icache));
    Vriscv_top_riscv_csr_regfile___settle__TOP__v__u_core__u_csr__u_csrfile__0((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
    Vriscv_top_riscv_csr__SB0___settle__TOP__v__u_core__u_csr__0((&vlSymsp->TOP__v__u_core__u_csr));
    Vriscv_top_riscv_issue___settle__TOP__v__u_core__u_issue__0((&vlSymsp->TOP__v__u_core__u_issue));
    Vriscv_top___024root___settle__TOP__1(vlSelf);
    Vriscv_top_dcache_core___settle__TOP__v__u_dcache__u_core__1((&vlSymsp->TOP__v__u_dcache__u_core));
    Vriscv_top_dcache___combo__TOP__v__u_dcache__2((&vlSymsp->TOP__v__u_dcache));
    Vriscv_top_riscv_core__M0_MBffffffff___settle__TOP__v__u_core__1((&vlSymsp->TOP__v__u_core));
    Vriscv_top_riscv_csr_regfile___settle__TOP__v__u_core__u_csr__u_csrfile__1((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
    Vriscv_top_dcache_core___settle__TOP__v__u_dcache__u_core__2((&vlSymsp->TOP__v__u_dcache__u_core));
    Vriscv_top_riscv_issue___settle__TOP__v__u_core__u_issue__1((&vlSymsp->TOP__v__u_core__u_issue));
    Vriscv_top_riscv_regfile___sequent__TOP__v__u_core__u_issue__u_regfile__1((&vlSymsp->TOP__v__u_core__u_issue__u_regfile));
    Vriscv_top_dcache___settle__TOP__v__u_dcache__2((&vlSymsp->TOP__v__u_dcache));
    Vriscv_top_riscv_issue___settle__TOP__v__u_core__u_issue__2((&vlSymsp->TOP__v__u_core__u_issue));
    Vriscv_top_riscv_core__M0_MBffffffff___settle__TOP__v__u_core__2((&vlSymsp->TOP__v__u_core));
    Vriscv_top_riscv_csr__SB0___combo__TOP__v__u_core__u_csr__0((&vlSymsp->TOP__v__u_core__u_csr));
    Vriscv_top_riscv_issue___combo__TOP__v__u_core__u_issue__2((&vlSymsp->TOP__v__u_core__u_issue));
}
