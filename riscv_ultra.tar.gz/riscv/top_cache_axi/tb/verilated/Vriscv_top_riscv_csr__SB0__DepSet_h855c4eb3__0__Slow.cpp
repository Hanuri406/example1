// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_top__Syms.h"
#include "Vriscv_top_riscv_csr__SB0.h"

VL_ATTR_COLD void Vriscv_top_riscv_csr__SB0___settle__TOP__v__u_core__u_csr__0(Vriscv_top_riscv_csr__SB0* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_top_riscv_csr__SB0___settle__TOP__v__u_core__u_csr__0\n"); );
    // Body
    vlSelf->__PVT__branch_csr_priv_o = ((vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_q 
                                         >> 0x1fU) ? (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q)
                                         : 3U);
    vlSelf->__Vcellinp__u_csrfile__csr_waddr_i = ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_wb_q)
                                                   ? 
                                                  (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                   >> 0x14U)
                                                   : 0U);
}
