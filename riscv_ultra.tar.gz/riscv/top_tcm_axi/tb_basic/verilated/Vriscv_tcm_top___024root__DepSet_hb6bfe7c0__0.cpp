// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_tcm_top__Syms.h"
#include "Vriscv_tcm_top___024root.h"

VL_INLINE_OPT void Vriscv_tcm_top___024root___sequent__TOP__0(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___sequent__TOP__0\n"); );
    // Body
    VL_ASSIGN_SUI(32,vlSelf->axi_t_rdata_o, vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__ram
                  [vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__rd_ptr]);
    VL_ASSIGN_SII(1,vlSelf->axi_t_rlast_o, (1U & ((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w) 
                                                  >> 4U)));
    VL_ASSIGN_SUI(4,vlSelf->axi_t_rid_o, (0xfU & (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w)));
    VL_ASSIGN_SUI(4,vlSelf->axi_t_bid_o, (0xfU & (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w)));
    VL_ASSIGN_SII(1,vlSelf->axi_t_rvalid_o, vlSymsp->TOP__v__u_tcm.__PVT__axi_rvalid_o);
    VL_ASSIGN_SII(1,vlSelf->axi_t_bvalid_o, vlSymsp->TOP__v__u_tcm.__PVT__axi_bvalid_o);
    VL_ASSIGN_SUI(32,vlSelf->axi_i_araddr_o, (0xfffffffcU 
                                              & vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[0U]));
    VL_ASSIGN_SUI(4,vlSelf->axi_i_wstrb_o, (0xfU & 
                                            vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[2U]));
    VL_ASSIGN_SUI(32,vlSelf->axi_i_wdata_o, vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[1U]);
    VL_ASSIGN_SUI(32,vlSelf->axi_i_awaddr_o, (0xfffffffcU 
                                              & vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[0U]));
}

VL_INLINE_OPT void Vriscv_tcm_top___024root___combo__TOP__2(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___combo__TOP__2\n"); );
    // Body
    VL_ASSIGN_SII(1,vlSelf->axi_i_arvalid_o, vlSymsp->TOP__v.__PVT__u_axi__DOT__req_is_read_w);
    VL_ASSIGN_SII(1,vlSelf->axi_i_awvalid_o, vlSymsp->TOP__v.axi_i_awvalid_o);
    VL_ASSIGN_SII(1,vlSelf->axi_i_wvalid_o, vlSymsp->TOP__v.axi_i_wvalid_o);
}

VL_INLINE_OPT void Vriscv_tcm_top___024root___combo__TOP__4(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___combo__TOP__4\n"); );
    // Body
    VL_ASSIGN_SII(1,vlSelf->axi_t_wready_o, vlSymsp->TOP__v__u_tcm.__PVT__axi_wready_o);
    VL_ASSIGN_SII(1,vlSelf->axi_t_awready_o, vlSymsp->TOP__v__u_tcm.__PVT__axi_awready_o);
    VL_ASSIGN_SII(1,vlSelf->axi_t_arready_o, vlSymsp->TOP__v__u_tcm.__PVT__axi_arready_o);
}

void Vriscv_tcm_top___024root___combo__TOP__0(Vriscv_tcm_top___024root* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__0(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__0(Vriscv_tcm_top_riscv_csr__SB0* vlSelf);
void Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__0(Vriscv_tcm_top_riscv_csr_regfile* vlSelf);
void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__0(Vriscv_tcm_top_riscv_issue* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__1(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__1(Vriscv_tcm_top_riscv_csr__SB0* vlSelf);
void Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__1(Vriscv_tcm_top_riscv_csr_regfile* vlSelf);
void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__1(Vriscv_tcm_top_riscv_issue* vlSelf);
void Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__2(Vriscv_tcm_top_riscv_csr__SB0* vlSelf);
void Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__2(Vriscv_tcm_top_riscv_csr_regfile* vlSelf);
void Vriscv_tcm_top_tcm_mem___sequent__TOP__v__u_tcm__0(Vriscv_tcm_top_tcm_mem* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___sequent__TOP__v__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_tcm_mem_ram___sequent__TOP__v__u_tcm__u_ram__0(Vriscv_tcm_top_tcm_mem_ram* vlSelf);
void Vriscv_tcm_top_riscv_regfile___sequent__TOP__v__u_core__u_issue__u_regfile__0(Vriscv_tcm_top_riscv_regfile* vlSelf);
void Vriscv_tcm_top_riscv_csr_regfile___combo__TOP__v__u_core__u_csr__u_csrfile__0(Vriscv_tcm_top_riscv_csr_regfile* vlSelf);
void Vriscv_tcm_top___024root___combo__TOP__1(Vriscv_tcm_top___024root* vlSelf);
void Vriscv_tcm_top_tcm_mem___combo__TOP__v__u_tcm__0(Vriscv_tcm_top_tcm_mem* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___combo__TOP__v__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__0(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___multiclk__TOP__v__u_core__0(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__2(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__2(Vriscv_tcm_top_riscv_issue* vlSelf);
void Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__3(Vriscv_tcm_top_riscv_csr__SB0* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__3(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__3(Vriscv_tcm_top_riscv_csr_regfile* vlSelf);
void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__3(Vriscv_tcm_top_riscv_issue* vlSelf);
void Vriscv_tcm_top_riscv_regfile___sequent__TOP__v__u_core__u_issue__u_regfile__1(Vriscv_tcm_top_riscv_regfile* vlSelf);
void Vriscv_tcm_top_tcm_mem___sequent__TOP__v__u_tcm__1(Vriscv_tcm_top_tcm_mem* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__1(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top___024root___combo__TOP__3(Vriscv_tcm_top___024root* vlSelf);
void Vriscv_tcm_top_tcm_mem___combo__TOP__v__u_tcm__1(Vriscv_tcm_top_tcm_mem* vlSelf);
void Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__0(Vriscv_tcm_top_riscv_issue* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___combo__TOP__v__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__2(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___multiclk__TOP__v__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___multiclk__TOP__v__u_core__1(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___combo__TOP__v__2(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__3(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__1(Vriscv_tcm_top_riscv_issue* vlSelf);
void Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__4(Vriscv_tcm_top_riscv_core__M0_MBffffffff* vlSelf);
void Vriscv_tcm_top_riscv_csr__SB0___combo__TOP__v__u_core__u_csr__0(Vriscv_tcm_top_riscv_csr__SB0* vlSelf);
void Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__2(Vriscv_tcm_top_riscv_issue* vlSelf);

void Vriscv_tcm_top___024root___eval(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval\n"); );
    // Body
    Vriscv_tcm_top___024root___combo__TOP__0(vlSelf);
    vlSelf->__Vm_traceActivity[1U] = 1U;
    if ((((IData)(vlSelf->__Vcellinp__v__clk_i) & (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i))) 
         | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_cpu_i) 
            & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_cpu_i))))) {
        Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__0((&vlSymsp->TOP__v__u_core));
        vlSelf->__Vm_traceActivity[2U] = 1U;
        Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__0((&vlSymsp->TOP__v__u_core__u_csr));
        Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__0((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
        Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__0((&vlSymsp->TOP__v__u_core__u_issue));
        Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__1((&vlSymsp->TOP__v__u_core));
        Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__1((&vlSymsp->TOP__v__u_core__u_csr));
        Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__1((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
        Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__1((&vlSymsp->TOP__v__u_core__u_issue));
        Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__2((&vlSymsp->TOP__v__u_core__u_csr));
        Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__2((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
    }
    if ((((IData)(vlSelf->__Vcellinp__v__clk_i) & (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i))) 
         | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i) 
            & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_i))))) {
        Vriscv_tcm_top_tcm_mem___sequent__TOP__v__u_tcm__0((&vlSymsp->TOP__v__u_tcm));
        vlSelf->__Vm_traceActivity[3U] = 1U;
        Vriscv_tcm_top_riscv_tcm_top___sequent__TOP__v__0((&vlSymsp->TOP__v));
        Vriscv_tcm_top___024root___sequent__TOP__0(vlSelf);
    }
    if (((IData)(vlSelf->__Vcellinp__v__clk_i) & (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i)))) {
        Vriscv_tcm_top_tcm_mem_ram___sequent__TOP__v__u_tcm__u_ram__0((&vlSymsp->TOP__v__u_tcm__u_ram));
        vlSelf->__Vm_traceActivity[4U] = 1U;
        Vriscv_tcm_top_riscv_regfile___sequent__TOP__v__u_core__u_issue__u_regfile__0((&vlSymsp->TOP__v__u_core__u_issue__u_regfile));
    }
    Vriscv_tcm_top_riscv_csr_regfile___combo__TOP__v__u_core__u_csr__u_csrfile__0((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
    Vriscv_tcm_top___024root___combo__TOP__1(vlSelf);
    Vriscv_tcm_top_tcm_mem___combo__TOP__v__u_tcm__0((&vlSymsp->TOP__v__u_tcm));
    Vriscv_tcm_top_riscv_tcm_top___combo__TOP__v__0((&vlSymsp->TOP__v));
    Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__0((&vlSymsp->TOP__v__u_core));
    Vriscv_tcm_top___024root___combo__TOP__2(vlSelf);
    if (((((IData)(vlSelf->__Vcellinp__v__clk_i) & 
           (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i))) 
          | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_cpu_i) 
             & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_cpu_i)))) 
         | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i) 
            & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_i))))) {
        Vriscv_tcm_top_riscv_core__M0_MBffffffff___multiclk__TOP__v__u_core__0((&vlSymsp->TOP__v__u_core));
    }
    if ((((IData)(vlSelf->__Vcellinp__v__clk_i) & (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i))) 
         | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_cpu_i) 
            & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_cpu_i))))) {
        Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__2((&vlSymsp->TOP__v__u_core));
        vlSelf->__Vm_traceActivity[5U] = 1U;
        Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__2((&vlSymsp->TOP__v__u_core__u_issue));
        Vriscv_tcm_top_riscv_csr__SB0___sequent__TOP__v__u_core__u_csr__3((&vlSymsp->TOP__v__u_core__u_csr));
        Vriscv_tcm_top_riscv_core__M0_MBffffffff___sequent__TOP__v__u_core__3((&vlSymsp->TOP__v__u_core));
        Vriscv_tcm_top_riscv_csr_regfile___sequent__TOP__v__u_core__u_csr__u_csrfile__3((&vlSymsp->TOP__v__u_core__u_csr__u_csrfile));
        Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__3((&vlSymsp->TOP__v__u_core__u_issue));
        Vriscv_tcm_top_riscv_regfile___sequent__TOP__v__u_core__u_issue__u_regfile__1((&vlSymsp->TOP__v__u_core__u_issue__u_regfile));
    }
    if ((((IData)(vlSelf->__Vcellinp__v__clk_i) & (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i))) 
         | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i) 
            & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_i))))) {
        Vriscv_tcm_top_tcm_mem___sequent__TOP__v__u_tcm__1((&vlSymsp->TOP__v__u_tcm));
    }
    Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__1((&vlSymsp->TOP__v__u_core));
    Vriscv_tcm_top___024root___combo__TOP__3(vlSelf);
    Vriscv_tcm_top_tcm_mem___combo__TOP__v__u_tcm__1((&vlSymsp->TOP__v__u_tcm));
    Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__0((&vlSymsp->TOP__v__u_core__u_issue));
    Vriscv_tcm_top_riscv_tcm_top___combo__TOP__v__1((&vlSymsp->TOP__v));
    Vriscv_tcm_top___024root___combo__TOP__4(vlSelf);
    Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__2((&vlSymsp->TOP__v__u_core));
    if (((((IData)(vlSelf->__Vcellinp__v__clk_i) & 
           (~ (IData)(vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i))) 
          | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_cpu_i) 
             & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_cpu_i)))) 
         | ((IData)(vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i) 
            & (~ (IData)(vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_i))))) {
        Vriscv_tcm_top_riscv_tcm_top___multiclk__TOP__v__0((&vlSymsp->TOP__v));
        vlSelf->__Vm_traceActivity[6U] = 1U;
        Vriscv_tcm_top_riscv_core__M0_MBffffffff___multiclk__TOP__v__u_core__1((&vlSymsp->TOP__v__u_core));
    }
    Vriscv_tcm_top_riscv_tcm_top___combo__TOP__v__2((&vlSymsp->TOP__v));
    Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__3((&vlSymsp->TOP__v__u_core));
    Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__1((&vlSymsp->TOP__v__u_core__u_issue));
    Vriscv_tcm_top_riscv_core__M0_MBffffffff___combo__TOP__v__u_core__4((&vlSymsp->TOP__v__u_core));
    Vriscv_tcm_top_riscv_csr__SB0___combo__TOP__v__u_core__u_csr__0((&vlSymsp->TOP__v__u_core__u_csr));
    Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__2((&vlSymsp->TOP__v__u_core__u_issue));
    // Final
    vlSelf->__Vclklast__TOP____Vcellinp__v__clk_i = vlSelf->__Vcellinp__v__clk_i;
    vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_cpu_i 
        = vlSelf->__VinpClk__TOP____Vcellinp__v__rst_cpu_i;
    vlSelf->__Vclklast__TOP____VinpClk__TOP____Vcellinp__v__rst_i 
        = vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i;
    vlSelf->__VinpClk__TOP____Vcellinp__v__rst_cpu_i 
        = vlSelf->__Vcellinp__v__rst_cpu_i;
    vlSelf->__VinpClk__TOP____Vcellinp__v__rst_i = vlSelf->__Vcellinp__v__rst_i;
}
