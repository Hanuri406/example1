// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_tcm_top__Syms.h"
#include "Vriscv_tcm_top_riscv_issue.h"

void Vriscv_tcm_top_riscv_issue___ctor_var_reset(Vriscv_tcm_top_riscv_issue* vlSelf);

Vriscv_tcm_top_riscv_issue::Vriscv_tcm_top_riscv_issue(Vriscv_tcm_top__Syms* symsp, const char* name)
    : VerilatedModule{name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vriscv_tcm_top_riscv_issue___ctor_var_reset(this);
}

void Vriscv_tcm_top_riscv_issue::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vriscv_tcm_top_riscv_issue::~Vriscv_tcm_top_riscv_issue() {
}
