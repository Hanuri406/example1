// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_tcm_top__Syms.h"
#include "Vriscv_tcm_top_riscv_issue.h"

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__0(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__0\n"); );
    // Body
    vlSelf->__Vdly__u_pipe_ctrl__DOT__ctrl_e2_q = vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q;
    if (vlSymsp->TOP.__Vcellinp__v__rst_cpu_i) {
        vlSelf->__PVT__priv_x_q = 3U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__squash_e1_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wr_wb_q = 0U;
        vlSelf->__PVT__div_pending_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__npc_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__pc_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q = 0U;
        vlSelf->__Vdly__u_pipe_ctrl__DOT__ctrl_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__valid_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wr_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e1_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e1_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e1_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e1_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e1_q = 0U;
    } else {
        if (vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q) {
            vlSelf->__PVT__priv_x_q = vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o;
        }
        if ((1U & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w)))) {
            vlSelf->__PVT__u_pipe_ctrl__DOT__squash_e1_e2_q 
                = (0U != (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r));
            vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wr_wb_q 
                = vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wr_e2_q;
            vlSelf->__PVT__u_pipe_ctrl__DOT__npc_wb_q 
                = vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e2_q;
            vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_wb_q 
                = vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q;
            vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_wb_q 
                = vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q;
            vlSelf->__PVT__u_pipe_ctrl__DOT__pc_wb_q 
                = vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e2_q;
            vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                = vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e2_q;
            vlSelf->__PVT__u_pipe_ctrl__DOT__valid_wb_q 
                = ((0x20U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r))
                    ? (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q)
                    : ((0x10U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r))
                        ? ((8U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r))
                            ? ((4U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r))
                                ? ((~ (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r)) 
                                   & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q))
                                : (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q))
                            : ((~ ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r) 
                                   >> 2U)) & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q)))
                        : (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q)));
            if (vlSelf->__PVT__pipe_squash_e1_e2_w) {
                vlSelf->__Vdly__u_pipe_ctrl__DOT__ctrl_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e2_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q = 0U;
            } else {
                vlSelf->__Vdly__u_pipe_ctrl__DOT__ctrl_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q;
                vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_q 
                    = ((0x100U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))
                        ? 0x20U : ((0U != (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e1_q))
                                    ? (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e1_q)
                                    : (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__exception_e1_q)));
                vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e1_q;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q;
                vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e1_q;
                vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e1_q;
                vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q 
                    = vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e1_q;
                if ((1U & (~ ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                              >> 8U)))) {
                    if ((0U != (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e1_q))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q = 0U;
                    }
                }
            }
            vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wr_e2_q 
                = ((~ (IData)(vlSelf->__PVT__pipe_squash_e1_e2_w)) 
                   & (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_valid_e1_q));
            if ((((IData)(vlSelf->__PVT__opcode_issue_r) 
                  & (IData)(vlSelf->__PVT__opcode_accept_r)) 
                 & (~ (IData)(vlSelf->__PVT__pipe_squash_e1_e2_w)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e1_q 
                    = ((IData)(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w)
                        ? vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r
                        : ((IData)(4U) + vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w));
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q 
                    = vlSelf->__PVT__issue_rb_value_r;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q 
                    = vlSelf->__PVT__issue_ra_value_r;
                vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e1_q 
                    = vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w;
                vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e1_q 
                    = vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w;
                vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e1_q 
                    = ((0U != (IData)(vlSelf->__PVT__issue_fault_w))
                        ? (IData)(vlSelf->__PVT__issue_fault_w)
                        : (((IData)(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w) 
                            & (0U != (3U & vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)))
                            ? 0x10U : 0U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e1_q = 1U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__npc_e1_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__pc_e1_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e1_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e1_q = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e1_q = 0U;
            }
        }
        if (vlSelf->__PVT__pipe_squash_e1_e2_w) {
            vlSelf->__PVT__div_pending_q = 0U;
        } else if (((IData)(vlSelf->__PVT__opcode_issue_r) 
                    & (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w))) {
            vlSelf->__PVT__div_pending_q = 1U;
        } else if (vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__valid_q) {
            vlSelf->__PVT__div_pending_q = 0U;
        }
    }
    vlSelf->__PVT__issue_fault_w = ((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w)
                                     ? 0x11U : ((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w)
                                                 ? 0x1cU
                                                 : 0U));
}

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__1(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__1\n"); );
    // Body
    if (vlSymsp->TOP.__Vcellinp__v__rst_cpu_i) {
        vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wdata_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__exception_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wdata_e2_q = 0U;
    } else if ((1U & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w)))) {
        vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wdata_wb_q 
            = vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wdata_e2_q;
        vlSelf->__PVT__u_pipe_ctrl__DOT__exception_wb_q 
            = vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r;
        vlSelf->__PVT__u_pipe_ctrl__DOT__csr_wdata_e2_q 
            = ((IData)(vlSelf->__PVT__pipe_squash_e1_e2_w)
                ? 0U : vlSymsp->TOP__v__u_core__u_csr.__PVT__csr_wdata_e1_q);
    }
}

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__2(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__2\n"); );
    // Body
    if (vlSymsp->TOP.__Vcellinp__v__rst_cpu_i) {
        vlSelf->__PVT__u_pipe_ctrl__DOT__result_wb_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q = 0U;
    } else if ((1U & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w)))) {
        vlSelf->__PVT__u_pipe_ctrl__DOT__result_wb_q 
            = (((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_w) 
                & (IData)((0U != (6U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q)))))
                ? vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__wb_result_r
                : (((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_w) 
                    & ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                       >> 5U)) ? vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e2_q
                    : vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_q));
        vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_q 
            = ((IData)(vlSelf->__PVT__pipe_squash_e1_e2_w)
                ? 0U : ((0x10U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))
                         ? vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__wb_result_q
                         : ((8U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))
                             ? vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_result_e1_q
                             : vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__result_q)));
        if ((((IData)(vlSelf->__PVT__opcode_issue_r) 
              & (IData)(vlSelf->__PVT__opcode_accept_r)) 
             & (~ (IData)(vlSelf->__PVT__pipe_squash_e1_e2_w)))) {
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = ((0x3feU & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)) 
                   | (1U & (~ ((((((((((((3U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                         | (0x1003U 
                                            == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                        | (0x2003U 
                                           == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                       | (0x4003U == 
                                          (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                      | (0x5003U == 
                                         (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                     | (0x6003U == 
                                        (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                    | (0x23U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x1023U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x2023U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w)) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w)) 
                               | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_mul_w)))));
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = ((0x3fdU & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)) 
                   | ((((((((((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x1003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                               | (0x2003U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x4003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x5003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                            | (0x6003U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x1023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x2023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        & (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w)) 
                       & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                      << 1U));
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = ((0x3fbU & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)) 
                   | ((((((((((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x1003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                               | (0x2003U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x4003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x5003U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                            | (0x6003U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x1023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x2023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        & (~ (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w))) 
                       & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                      << 2U));
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = ((0x3e7U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)) 
                   | ((((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w) 
                        & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                       << 4U) | (((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w) 
                                  & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                                 << 3U)));
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = ((0x39fU & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)) 
                   | (((((((((((0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                               | (0x67U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x63U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x1063U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                            | (0x4063U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0x5063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x6063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x7063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                       << 6U) | (((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_mul_w) 
                                  & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                                 << 5U)));
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = ((0x27fU & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)) 
                   | (((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q) 
                       << 8U) | (((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w) 
                                  & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q))) 
                                 << 7U)));
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q 
                = (0x200U | (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q));
        } else {
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q = 0U;
        }
    }
    vlSelf->__PVT__pipe_rd_e1_w = (0x1fU & ((- (IData)(
                                                       (1U 
                                                        & ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                                           >> 7U)))) 
                                            & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e1_q 
                                               >> 7U)));
}

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__3(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___sequent__TOP__v__u_core__u_issue__3\n"); );
    // Body
    if (vlSymsp->TOP.__Vcellinp__v__rst_cpu_i) {
        vlSelf->__PVT__csr_pending_q = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_wb_q = 0U;
    } else {
        if (vlSelf->__PVT__pipe_squash_e1_e2_w) {
            vlSelf->__PVT__csr_pending_q = 0U;
        } else if (((IData)(vlSelf->__PVT__csr_opcode_valid_o) 
                    & (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w))) {
            vlSelf->__PVT__csr_pending_q = 1U;
        } else if ((1U & (((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                           >> 3U) & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w))))) {
            vlSelf->__PVT__csr_pending_q = 0U;
        }
        if ((1U & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w)))) {
            vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_wb_q 
                = ((0U != (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r))
                    ? (0x37fU & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q))
                    : (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q));
        }
    }
    vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q = vlSelf->__Vdly__u_pipe_ctrl__DOT__ctrl_e2_q;
}

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__0(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__0\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_hd86ad487__0;
    VlWide<3>/*95:0*/ __Vtemp_ha12c50ec__0;
    VlWide<3>/*95:0*/ __Vtemp_h474c3905__0;
    VlWide<3>/*95:0*/ __Vtemp_hdbdd82ce__0;
    VlWide<3>/*95:0*/ __Vtemp_hce4e2311__0;
    VlWide<3>/*95:0*/ __Vtemp_h0c708dba__0;
    VlWide<3>/*95:0*/ __Vtemp_h4aa81e77__0;
    VlWide<3>/*95:0*/ __Vtemp_h093306c4__0;
    VlWide<3>/*95:0*/ __Vtemp_hc3c1c93f__0;
    VlWide<3>/*95:0*/ __Vtemp_h5e916eb9__0;
    VlWide<3>/*95:0*/ __Vtemp_h66a187a1__0;
    VlWide<3>/*95:0*/ __Vtemp_h9b1ba40d__0;
    // Body
    vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r 
        = ((((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q) 
             & (IData)((0U != (6U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q))))) 
            & (IData)(vlSymsp->TOP__v__u_core.__PVT__writeback_mem_valid_w))
            ? (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                ? 0x14U : (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                            & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                            ? 0x16U : (((IData)(vlSymsp->TOP__v.__PVT__dport_error_w) 
                                        & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                                        ? 0x15U : (
                                                   ((IData)(vlSymsp->TOP__v.__PVT__dport_error_w) 
                                                    & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                                    ? 0x17U
                                                    : 0U))))
            : (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_q));
    vlSelf->__PVT__pipe_stall_raw_w = (1U & ((((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                               >> 4U) 
                                              & (~ (IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__valid_q))) 
                                             | ((IData)(
                                                        (0U 
                                                         != 
                                                         (6U 
                                                          & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q)))) 
                                                & (~ (IData)(vlSymsp->TOP__v__u_core.__PVT__writeback_mem_valid_w)))));
    vlSelf->__PVT__pipe_squash_e1_e2_w = ((0U != (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__exception_e2_r)) 
                                          | (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__squash_e1_e2_q));
    vlSelf->__PVT__pipe_valid_wb_w = ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_wb_q) 
                                      & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w)));
    vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_w = ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_q) 
                                                   & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w)));
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_pc = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_pc = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[1U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[2U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[1U] = 0U;
    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[2U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[1U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[2U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[0U] = 0x2dU;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[1U] = 0U;
    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[2U] = 0U;
    if (vlSelf->__PVT__pipe_valid_wb_w) {
        if (((((((((0x7013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                   | (0x13U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                  | (0x2013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                 | (0x3013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                | (0x6013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
               | (0x4013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
              | (0x1013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
             | (0x5013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
            if ((0x7013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x616e6469U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x616e6469U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x13U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x61646469U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x61646469U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x736c7469U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x736c7469U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x3013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c746975U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x73U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c746975U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x73U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6f7269U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6f7269U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x4013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x786f7269U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x786f7269U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x1013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x736c6c69U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x736c6c69U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x73726c69U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x73726c69U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x40005013U == (0xfc00707fU 
                                           & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                          | (0x37U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x17U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x33U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x40000033U == (0xfe00707fU 
                                          & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x2033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x3033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x4033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
            if ((0x40005013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x73726169U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x73726169U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x37U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c7569U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c7569U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x17U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x75697063U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x61U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x75697063U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x61U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x33U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x616464U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x616464U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x40000033U == (0xfe00707fU 
                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x737562U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x737562U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x736c74U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x736c74U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x3033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x736c7475U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x736c7475U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x786f72U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x786f72U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x6033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                          | (0x7033U == (0xfe00707fU 
                                         & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x1033U == (0xfe00707fU 
                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x5033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x40005033U == (0xfe00707fU 
                                          & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x6fU == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x67U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x63U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
            if ((0x6033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6f72U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6f72U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x7033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x616e64U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x616e64U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x1033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x736c6cU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x736c6cU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x73726cU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x73726cU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x40005033U == (0xfe00707fU 
                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x737261U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x737261U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6fU == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6a616cU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6a616cU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x67U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6a616c72U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6a616c72U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x626571U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x626571U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x1063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                          | (0x4063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x5063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x6063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x7063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (3U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x1003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x2003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
            if ((0x1063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x626e65U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x626e65U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x4063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x626c74U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x626c74U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x626765U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x626765U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x626c7475U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x626c7475U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x7063U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x62676575U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x62676575U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((3U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c62U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c62U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x1003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c68U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c68U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c77U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c77U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x4003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                          | (0x5003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x6003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x23U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x1023U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x2023U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x73U == vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                    | (0x100073U == vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
            if ((0x4003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c6275U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c6275U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c6875U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c6875U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c7775U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c7775U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x23U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x7362U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x7362U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x1023U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x7368U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x7368U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2023U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x7377U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x7377U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x73U == vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x63616c6cU;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x65U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x63616c6cU;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x65U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x7265616bU;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x6562U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x7265616bU;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x6562U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x200073U == (0xcfffffffU 
                                         & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                          | (0x1073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x2073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x3073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x5073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x6073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x7073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x2000033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
            if ((0x200073U == (0xcfffffffU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x65726574U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x65726574U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x1073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x73727277U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x73727277U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x73727273U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x73727273U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x3073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x73727263U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x73727263U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x72727769U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x6373U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x72727769U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x6373U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x72727369U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x6373U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x72727369U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x6373U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x7073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x72726369U;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x6373U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x72726369U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x6373U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6d756cU;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6d756cU;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x2001033U == (0xfe00707fU 
                                          & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                          | (0x2002033U == (0xfe00707fU 
                                            & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x2003033U == (0xfe00707fU 
                                           & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x2004033U == (0xfe00707fU 
                                          & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x2005033U == (0xfe00707fU 
                                         & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x2006033U == (0xfe00707fU 
                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x2007033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x100fU == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
            if ((0x2001033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6d756c68U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6d756c68U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2002033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x6c687375U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x6d75U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x6c687375U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x6d75U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2003033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x756c6875U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x6dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x756c6875U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x6dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2004033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x646976U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x646976U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2005033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x64697675U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x64697675U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2006033U == (0xfe00707fU 
                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x72656dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x72656dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x2007033U == (0xfe00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x72656d75U;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x72656d75U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x63652e69U;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x66656eU;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x63652e69U;
                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x66656eU;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
            }
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_pc 
            = vlSelf->__PVT__u_pipe_ctrl__DOT__pc_wb_q;
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_pc 
            = vlSelf->__PVT__u_pipe_ctrl__DOT__pc_wb_q;
        vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum 
            = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                        >> 0xfU));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                        __Vtemp_hd86ad487__0[0U] = 0x7436U;
                        __Vtemp_ha12c50ec__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_hd86ad487__0[0U] = 0x7435U;
                        __Vtemp_ha12c50ec__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                    __Vtemp_hd86ad487__0[0U] = 0x7434U;
                    __Vtemp_ha12c50ec__0[0U] = 0x6133U;
                } else {
                    __Vtemp_hd86ad487__0[0U] = 0x7433U;
                    __Vtemp_ha12c50ec__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                    __Vtemp_hd86ad487__0[0U] = 0x733131U;
                    __Vtemp_ha12c50ec__0[0U] = 0x6131U;
                } else {
                    __Vtemp_hd86ad487__0[0U] = 0x733130U;
                    __Vtemp_ha12c50ec__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                __Vtemp_hd86ad487__0[0U] = 0x7339U;
                __Vtemp_ha12c50ec__0[0U] = 0x7331U;
            } else {
                __Vtemp_hd86ad487__0[0U] = 0x7338U;
                __Vtemp_ha12c50ec__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                    __Vtemp_hd86ad487__0[0U] = 0x7337U;
                    __Vtemp_ha12c50ec__0[0U] = 0x7432U;
                } else {
                    __Vtemp_hd86ad487__0[0U] = 0x7336U;
                    __Vtemp_ha12c50ec__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                __Vtemp_hd86ad487__0[0U] = 0x7335U;
                __Vtemp_ha12c50ec__0[0U] = 0x7430U;
            } else {
                __Vtemp_hd86ad487__0[0U] = 0x7334U;
                __Vtemp_ha12c50ec__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
                __Vtemp_hd86ad487__0[0U] = 0x7333U;
                __Vtemp_ha12c50ec__0[0U] = 0x6770U;
            } else {
                __Vtemp_hd86ad487__0[0U] = 0x7332U;
                __Vtemp_ha12c50ec__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
            __Vtemp_hd86ad487__0[0U] = 0x6137U;
            __Vtemp_ha12c50ec__0[0U] = 0x7261U;
        } else {
            __Vtemp_hd86ad487__0[0U] = 0x6136U;
            __Vtemp_ha12c50ec__0[0U] = 0x7a65726fU;
        }
        __Vtemp_hd86ad487__0[1U] = 0U;
        __Vtemp_hd86ad487__0[2U] = 0U;
        __Vtemp_ha12c50ec__0[1U] = 0U;
        __Vtemp_ha12c50ec__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__regnum))) {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[0U] 
                = __Vtemp_hd86ad487__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[1U] 
                = __Vtemp_hd86ad487__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[2U] 
                = __Vtemp_hd86ad487__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[0U] 
                = __Vtemp_ha12c50ec__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[1U] 
                = __Vtemp_ha12c50ec__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[2U] 
                = __Vtemp_ha12c50ec__0[2U];
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[0U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[1U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[2U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__3__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum 
            = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                        >> 0x14U));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                        __Vtemp_h474c3905__0[0U] = 0x7436U;
                        __Vtemp_hdbdd82ce__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_h474c3905__0[0U] = 0x7435U;
                        __Vtemp_hdbdd82ce__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                    __Vtemp_h474c3905__0[0U] = 0x7434U;
                    __Vtemp_hdbdd82ce__0[0U] = 0x6133U;
                } else {
                    __Vtemp_h474c3905__0[0U] = 0x7433U;
                    __Vtemp_hdbdd82ce__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                    __Vtemp_h474c3905__0[0U] = 0x733131U;
                    __Vtemp_hdbdd82ce__0[0U] = 0x6131U;
                } else {
                    __Vtemp_h474c3905__0[0U] = 0x733130U;
                    __Vtemp_hdbdd82ce__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                __Vtemp_h474c3905__0[0U] = 0x7339U;
                __Vtemp_hdbdd82ce__0[0U] = 0x7331U;
            } else {
                __Vtemp_h474c3905__0[0U] = 0x7338U;
                __Vtemp_hdbdd82ce__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                    __Vtemp_h474c3905__0[0U] = 0x7337U;
                    __Vtemp_hdbdd82ce__0[0U] = 0x7432U;
                } else {
                    __Vtemp_h474c3905__0[0U] = 0x7336U;
                    __Vtemp_hdbdd82ce__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                __Vtemp_h474c3905__0[0U] = 0x7335U;
                __Vtemp_hdbdd82ce__0[0U] = 0x7430U;
            } else {
                __Vtemp_h474c3905__0[0U] = 0x7334U;
                __Vtemp_hdbdd82ce__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
                __Vtemp_h474c3905__0[0U] = 0x7333U;
                __Vtemp_hdbdd82ce__0[0U] = 0x6770U;
            } else {
                __Vtemp_h474c3905__0[0U] = 0x7332U;
                __Vtemp_hdbdd82ce__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
            __Vtemp_h474c3905__0[0U] = 0x6137U;
            __Vtemp_hdbdd82ce__0[0U] = 0x7261U;
        } else {
            __Vtemp_h474c3905__0[0U] = 0x6136U;
            __Vtemp_hdbdd82ce__0[0U] = 0x7a65726fU;
        }
        __Vtemp_h474c3905__0[1U] = 0U;
        __Vtemp_h474c3905__0[2U] = 0U;
        __Vtemp_hdbdd82ce__0[1U] = 0U;
        __Vtemp_hdbdd82ce__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__regnum))) {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[0U] 
                = __Vtemp_h474c3905__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[1U] 
                = __Vtemp_h474c3905__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[2U] 
                = __Vtemp_h474c3905__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[0U] 
                = __Vtemp_hdbdd82ce__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[1U] 
                = __Vtemp_hdbdd82ce__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[2U] 
                = __Vtemp_hdbdd82ce__0[2U];
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__4__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum 
            = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                        >> 7U));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                        __Vtemp_hce4e2311__0[0U] = 0x7436U;
                        __Vtemp_h0c708dba__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_hce4e2311__0[0U] = 0x7435U;
                        __Vtemp_h0c708dba__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                    __Vtemp_hce4e2311__0[0U] = 0x7434U;
                    __Vtemp_h0c708dba__0[0U] = 0x6133U;
                } else {
                    __Vtemp_hce4e2311__0[0U] = 0x7433U;
                    __Vtemp_h0c708dba__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                    __Vtemp_hce4e2311__0[0U] = 0x733131U;
                    __Vtemp_h0c708dba__0[0U] = 0x6131U;
                } else {
                    __Vtemp_hce4e2311__0[0U] = 0x733130U;
                    __Vtemp_h0c708dba__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                __Vtemp_hce4e2311__0[0U] = 0x7339U;
                __Vtemp_h0c708dba__0[0U] = 0x7331U;
            } else {
                __Vtemp_hce4e2311__0[0U] = 0x7338U;
                __Vtemp_h0c708dba__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                    __Vtemp_hce4e2311__0[0U] = 0x7337U;
                    __Vtemp_h0c708dba__0[0U] = 0x7432U;
                } else {
                    __Vtemp_hce4e2311__0[0U] = 0x7336U;
                    __Vtemp_h0c708dba__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                __Vtemp_hce4e2311__0[0U] = 0x7335U;
                __Vtemp_h0c708dba__0[0U] = 0x7430U;
            } else {
                __Vtemp_hce4e2311__0[0U] = 0x7334U;
                __Vtemp_h0c708dba__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
                __Vtemp_hce4e2311__0[0U] = 0x7333U;
                __Vtemp_h0c708dba__0[0U] = 0x6770U;
            } else {
                __Vtemp_hce4e2311__0[0U] = 0x7332U;
                __Vtemp_h0c708dba__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
            __Vtemp_hce4e2311__0[0U] = 0x6137U;
            __Vtemp_h0c708dba__0[0U] = 0x7261U;
        } else {
            __Vtemp_hce4e2311__0[0U] = 0x6136U;
            __Vtemp_h0c708dba__0[0U] = 0x7a65726fU;
        }
        __Vtemp_hce4e2311__0[1U] = 0U;
        __Vtemp_hce4e2311__0[2U] = 0U;
        __Vtemp_h0c708dba__0[1U] = 0U;
        __Vtemp_h0c708dba__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__regnum))) {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[0U] 
                = __Vtemp_hce4e2311__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[1U] 
                = __Vtemp_hce4e2311__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[2U] 
                = __Vtemp_hce4e2311__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[0U] 
                = __Vtemp_h0c708dba__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[1U] 
                = __Vtemp_h0c708dba__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[2U] 
                = __Vtemp_h0c708dba__0[2U];
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[0U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[1U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[2U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_wb__DOT__get_regname_str__5__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum 
            = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                        >> 0xfU));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                        __Vtemp_h4aa81e77__0[0U] = 0x7436U;
                        __Vtemp_h093306c4__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_h4aa81e77__0[0U] = 0x7435U;
                        __Vtemp_h093306c4__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                    __Vtemp_h4aa81e77__0[0U] = 0x7434U;
                    __Vtemp_h093306c4__0[0U] = 0x6133U;
                } else {
                    __Vtemp_h4aa81e77__0[0U] = 0x7433U;
                    __Vtemp_h093306c4__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                    __Vtemp_h4aa81e77__0[0U] = 0x733131U;
                    __Vtemp_h093306c4__0[0U] = 0x6131U;
                } else {
                    __Vtemp_h4aa81e77__0[0U] = 0x733130U;
                    __Vtemp_h093306c4__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                __Vtemp_h4aa81e77__0[0U] = 0x7339U;
                __Vtemp_h093306c4__0[0U] = 0x7331U;
            } else {
                __Vtemp_h4aa81e77__0[0U] = 0x7338U;
                __Vtemp_h093306c4__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                    __Vtemp_h4aa81e77__0[0U] = 0x7337U;
                    __Vtemp_h093306c4__0[0U] = 0x7432U;
                } else {
                    __Vtemp_h4aa81e77__0[0U] = 0x7336U;
                    __Vtemp_h093306c4__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                __Vtemp_h4aa81e77__0[0U] = 0x7335U;
                __Vtemp_h093306c4__0[0U] = 0x7430U;
            } else {
                __Vtemp_h4aa81e77__0[0U] = 0x7334U;
                __Vtemp_h093306c4__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
                __Vtemp_h4aa81e77__0[0U] = 0x7333U;
                __Vtemp_h093306c4__0[0U] = 0x6770U;
            } else {
                __Vtemp_h4aa81e77__0[0U] = 0x7332U;
                __Vtemp_h093306c4__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
            __Vtemp_h4aa81e77__0[0U] = 0x6137U;
            __Vtemp_h093306c4__0[0U] = 0x7261U;
        } else {
            __Vtemp_h4aa81e77__0[0U] = 0x6136U;
            __Vtemp_h093306c4__0[0U] = 0x7a65726fU;
        }
        __Vtemp_h4aa81e77__0[1U] = 0U;
        __Vtemp_h4aa81e77__0[2U] = 0U;
        __Vtemp_h093306c4__0[1U] = 0U;
        __Vtemp_h093306c4__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__regnum))) {
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[0U] 
                = __Vtemp_h4aa81e77__0[0U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[1U] 
                = __Vtemp_h4aa81e77__0[1U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[2U] 
                = __Vtemp_h4aa81e77__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[0U] 
                = __Vtemp_h093306c4__0[0U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[1U] 
                = __Vtemp_h093306c4__0[1U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[2U] 
                = __Vtemp_h093306c4__0[2U];
        }
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[0U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[1U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[2U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__6__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum 
            = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                        >> 0x14U));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                        __Vtemp_hc3c1c93f__0[0U] = 0x7436U;
                        __Vtemp_h5e916eb9__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_hc3c1c93f__0[0U] = 0x7435U;
                        __Vtemp_h5e916eb9__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                    __Vtemp_hc3c1c93f__0[0U] = 0x7434U;
                    __Vtemp_h5e916eb9__0[0U] = 0x6133U;
                } else {
                    __Vtemp_hc3c1c93f__0[0U] = 0x7433U;
                    __Vtemp_h5e916eb9__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                    __Vtemp_hc3c1c93f__0[0U] = 0x733131U;
                    __Vtemp_h5e916eb9__0[0U] = 0x6131U;
                } else {
                    __Vtemp_hc3c1c93f__0[0U] = 0x733130U;
                    __Vtemp_h5e916eb9__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                __Vtemp_hc3c1c93f__0[0U] = 0x7339U;
                __Vtemp_h5e916eb9__0[0U] = 0x7331U;
            } else {
                __Vtemp_hc3c1c93f__0[0U] = 0x7338U;
                __Vtemp_h5e916eb9__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                    __Vtemp_hc3c1c93f__0[0U] = 0x7337U;
                    __Vtemp_h5e916eb9__0[0U] = 0x7432U;
                } else {
                    __Vtemp_hc3c1c93f__0[0U] = 0x7336U;
                    __Vtemp_h5e916eb9__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                __Vtemp_hc3c1c93f__0[0U] = 0x7335U;
                __Vtemp_h5e916eb9__0[0U] = 0x7430U;
            } else {
                __Vtemp_hc3c1c93f__0[0U] = 0x7334U;
                __Vtemp_h5e916eb9__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
                __Vtemp_hc3c1c93f__0[0U] = 0x7333U;
                __Vtemp_h5e916eb9__0[0U] = 0x6770U;
            } else {
                __Vtemp_hc3c1c93f__0[0U] = 0x7332U;
                __Vtemp_h5e916eb9__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
            __Vtemp_hc3c1c93f__0[0U] = 0x6137U;
            __Vtemp_h5e916eb9__0[0U] = 0x7261U;
        } else {
            __Vtemp_hc3c1c93f__0[0U] = 0x6136U;
            __Vtemp_h5e916eb9__0[0U] = 0x7a65726fU;
        }
        __Vtemp_hc3c1c93f__0[1U] = 0U;
        __Vtemp_hc3c1c93f__0[2U] = 0U;
        __Vtemp_h5e916eb9__0[1U] = 0U;
        __Vtemp_h5e916eb9__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__regnum))) {
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[0U] 
                = __Vtemp_hc3c1c93f__0[0U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[1U] 
                = __Vtemp_hc3c1c93f__0[1U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[2U] 
                = __Vtemp_hc3c1c93f__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[0U] 
                = __Vtemp_h5e916eb9__0[0U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[1U] 
                = __Vtemp_h5e916eb9__0[1U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[2U] 
                = __Vtemp_h5e916eb9__0[2U];
        }
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__7__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum 
            = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                        >> 7U));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                        __Vtemp_h66a187a1__0[0U] = 0x7436U;
                        __Vtemp_h9b1ba40d__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_h66a187a1__0[0U] = 0x7435U;
                        __Vtemp_h9b1ba40d__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                    __Vtemp_h66a187a1__0[0U] = 0x7434U;
                    __Vtemp_h9b1ba40d__0[0U] = 0x6133U;
                } else {
                    __Vtemp_h66a187a1__0[0U] = 0x7433U;
                    __Vtemp_h9b1ba40d__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                    __Vtemp_h66a187a1__0[0U] = 0x733131U;
                    __Vtemp_h9b1ba40d__0[0U] = 0x6131U;
                } else {
                    __Vtemp_h66a187a1__0[0U] = 0x733130U;
                    __Vtemp_h9b1ba40d__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                __Vtemp_h66a187a1__0[0U] = 0x7339U;
                __Vtemp_h9b1ba40d__0[0U] = 0x7331U;
            } else {
                __Vtemp_h66a187a1__0[0U] = 0x7338U;
                __Vtemp_h9b1ba40d__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                    __Vtemp_h66a187a1__0[0U] = 0x7337U;
                    __Vtemp_h9b1ba40d__0[0U] = 0x7432U;
                } else {
                    __Vtemp_h66a187a1__0[0U] = 0x7336U;
                    __Vtemp_h9b1ba40d__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                __Vtemp_h66a187a1__0[0U] = 0x7335U;
                __Vtemp_h9b1ba40d__0[0U] = 0x7430U;
            } else {
                __Vtemp_h66a187a1__0[0U] = 0x7334U;
                __Vtemp_h9b1ba40d__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
                __Vtemp_h66a187a1__0[0U] = 0x7333U;
                __Vtemp_h9b1ba40d__0[0U] = 0x6770U;
            } else {
                __Vtemp_h66a187a1__0[0U] = 0x7332U;
                __Vtemp_h9b1ba40d__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
            __Vtemp_h66a187a1__0[0U] = 0x6137U;
            __Vtemp_h9b1ba40d__0[0U] = 0x7261U;
        } else {
            __Vtemp_h66a187a1__0[0U] = 0x6136U;
            __Vtemp_h9b1ba40d__0[0U] = 0x7a65726fU;
        }
        __Vtemp_h66a187a1__0[1U] = 0U;
        __Vtemp_h66a187a1__0[2U] = 0U;
        __Vtemp_h9b1ba40d__0[1U] = 0U;
        __Vtemp_h9b1ba40d__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__regnum))) {
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[0U] 
                = __Vtemp_h66a187a1__0[0U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[1U] 
                = __Vtemp_h66a187a1__0[1U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[2U] 
                = __Vtemp_h66a187a1__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[0U] 
                = __Vtemp_h9b1ba40d__0[0U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[1U] 
                = __Vtemp_h9b1ba40d__0[1U];
            vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[2U] 
                = __Vtemp_h9b1ba40d__0[2U];
        }
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[0U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[1U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[2U] 
            = vlSelf->__Vfunc_u_pipe_dec0_verif__DOT__get_regname_str__8__Vfuncout[2U];
        if ((((((((((((((((((((0x13U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                              | (0x7013U == (0x707fU 
                                             & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                             | (0x2013U == (0x707fU 
                                            & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                            | (0x3013U == (0x707fU 
                                           & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                           | (0x6013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                          | (0x4013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x1073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x2073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x3073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x5073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x6073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x7073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                   | (((0x1013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                       | (0x5013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x40005013U == (0xfc00707fU 
                                         & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) 
                  | (0x37U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                 | (0x17U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                | (0x6fU == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
               | (0x67U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
              | ((((((3U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                     | (0x1003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x2003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                   | (0x4003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                  | (0x5003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                 | (0x6003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) 
             | (((0x23U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                 | (0x1023U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                | (0x2023U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))))) {
            if ((1U & (~ ((((((((((((0x13U == (0x707fU 
                                               & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                                    | (0x7013U == (0x707fU 
                                                   & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                   | (0x2013U == (0x707fU 
                                                  & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                  | (0x3013U == (0x707fU 
                                                 & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                 | (0x6013U == (0x707fU 
                                                & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                | (0x4013U == (0x707fU 
                                               & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                               | (0x1073U == (0x707fU 
                                              & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                              | (0x2073U == (0x707fU 
                                             & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                             | (0x3073U == (0x707fU 
                                            & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                            | (0x5073U == (0x707fU 
                                           & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                           | (0x6073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                          | (0x7073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))))) {
                if ((1U & (~ (((0x1013U == (0xfc00707fU 
                                            & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                               | (0x5013U == (0xfc00707fU 
                                              & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                              | (0x40005013U == (0xfc00707fU 
                                                 & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))))) {
                    if ((0x37U != (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                        if ((0x17U != (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                            if ((0x6fU == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                                if ((1U == (0x1fU & 
                                            (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                             >> 7U)))) {
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x63616c6cU;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x63616c6cU;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
                                }
                            } else if ((0x67U == (0x707fU 
                                                  & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                                if ((IData)(((0x8000U 
                                              == (0xf8000U 
                                                  & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                                             & (0U 
                                                == 
                                                (((- (IData)(
                                                             (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                              >> 0x1fU))) 
                                                  << 0xcU) 
                                                 | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                    >> 0x14U)))))) {
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x726574U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x726574U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
                                } else if ((1U == (0x1fU 
                                                   & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                      >> 7U)))) {
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[0U] = 0x20285229U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[1U] = 0x63616c6cU;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str[2U] = 0U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[0U] = 0x20285229U;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[1U] = 0x63616c6cU;
                                    vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str[2U] = 0U;
                                }
                            }
                            if ((0x6fU != (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                                if ((0x67U != (0x707fU 
                                               & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                                    if ((1U & (~ ((
                                                   ((((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                                                      | (0x1003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                                     | (0x2003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                                    | (0x4003U 
                                                       == 
                                                       (0x707fU 
                                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                                   | (0x5003U 
                                                      == 
                                                      (0x707fU 
                                                       & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                                                  | (0x6003U 
                                                     == 
                                                     (0x707fU 
                                                      & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))))) {
                                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[0U] = 0x2dU;
                                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[1U] = 0U;
                                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd[2U] = 0U;
                                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[0U] = 0x2dU;
                                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[1U] = 0U;
                                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd[2U] = 0U;
                                    }
                                }
                            }
                        }
                    }
                    if ((0x37U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[0U] = 0x2dU;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[2U] = 0U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[0U] = 0x2dU;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[2U] = 0U;
                    } else if ((0x17U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[0U] = 0x7063U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[2U] = 0U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[0U] = 0x7063U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[2U] = 0U;
                    } else if ((0x6fU == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[0U] = 0x2dU;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra[2U] = 0U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[0U] = 0x2dU;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra[2U] = 0U;
                    }
                }
            }
            if (((((((((((((0x13U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                           | (0x7013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                          | (0x2013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x3013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x6013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                       | (0x4013U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                      | (0x1073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                     | (0x2073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                    | (0x3073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                   | (0x5073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                  | (0x6073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                 | (0x7073U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((((0x1013U == (0xfc00707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                         | (0x5013U == (0xfc00707fU 
                                        & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x40005013U == (0xfc00707fU 
                                           & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                >> 0x14U));
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (0x1fU & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x37U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (0xfffff000U & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q);
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (0xfffff000U & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x17U == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (0xfffff000U & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q);
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (0xfffff000U & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x6fU == (0x7fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (vlSelf->__PVT__u_pipe_ctrl__DOT__pc_wb_q 
                       + (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                       >> 0x1fU))) 
                           << 0x14U) | ((0xff000U & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q) 
                                        | ((0x800U 
                                            & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                               >> 9U)) 
                                           | ((0x7e0U 
                                               & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                  >> 0x14U)) 
                                              | (0x1eU 
                                                 & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                    >> 0x14U)))))));
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (vlSelf->__PVT__u_pipe_ctrl__DOT__pc_wb_q 
                       + (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                       >> 0x1fU))) 
                           << 0x14U) | ((0xff000U & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q) 
                                        | ((0x800U 
                                            & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                               >> 9U)) 
                                           | ((0x7e0U 
                                               & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                  >> 0x14U)) 
                                              | (0x1eU 
                                                 & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                    >> 0x14U)))))));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x67U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else if (((((((3U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)) 
                            | (0x1003U == (0x707fU 
                                           & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                           | (0x2003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                          | (0x4003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                         | (0x5003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q))) 
                        | (0x6003U == (0x707fU & vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb[2U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb[2U] = 0U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0xfe0U & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                     >> 0x14U)) | (0x1fU 
                                                   & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                      >> 7U))));
                vlSelf->__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0xfe0U & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                     >> 0x14U)) | (0x1fU 
                                                   & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                                      >> 7U))));
            }
        }
    }
    vlSelf->__PVT__pipe_rd_wb_w = (0x1fU & ((- (IData)(
                                                       (((IData)(vlSelf->__PVT__pipe_valid_wb_w) 
                                                         & ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                                            >> 7U)) 
                                                        & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w))))) 
                                            & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                               >> 7U)));
    vlSelf->__PVT__pipe_rd_e2_w = (0x1fU & ((- (IData)(
                                                       (((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_w) 
                                                         & ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                                            >> 7U)) 
                                                        & (~ (IData)(vlSelf->__PVT__pipe_stall_raw_w))))) 
                                            & (vlSelf->__PVT__u_pipe_ctrl__DOT__opcode_e2_q 
                                               >> 7U)));
    vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_r = vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_q;
    if (((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_w) 
         & (IData)((0U != (6U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q)))))) {
        vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_r 
            = vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__wb_result_r;
    } else if (((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__valid_e2_w) 
                & ((IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                   >> 5U))) {
        vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_r 
            = vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e2_q;
    }
    vlSelf->__PVT__issue_rb_value_r = vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__rb0_value_r;
    if (((IData)(vlSelf->__PVT__pipe_rd_wb_w) == (0x1fU 
                                                  & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                     >> 0x14U)))) {
        vlSelf->__PVT__issue_rb_value_r = vlSelf->__PVT__u_pipe_ctrl__DOT__result_wb_q;
    }
    if (((IData)(vlSelf->__PVT__pipe_rd_e2_w) == (0x1fU 
                                                  & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                     >> 0x14U)))) {
        vlSelf->__PVT__issue_rb_value_r = vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_r;
    }
    if (((IData)(vlSelf->__PVT__pipe_rd_e1_w) == (0x1fU 
                                                  & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                     >> 0x14U)))) {
        vlSelf->__PVT__issue_rb_value_r = vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__result_q;
    }
    if ((0U == (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                         >> 0x14U)))) {
        vlSelf->__PVT__issue_rb_value_r = 0U;
    }
    vlSelf->__PVT__issue_ra_value_r = vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__ra0_value_r;
    if (((IData)(vlSelf->__PVT__pipe_rd_wb_w) == (0x1fU 
                                                  & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                     >> 0xfU)))) {
        vlSelf->__PVT__issue_ra_value_r = vlSelf->__PVT__u_pipe_ctrl__DOT__result_wb_q;
    }
    if (((IData)(vlSelf->__PVT__pipe_rd_e2_w) == (0x1fU 
                                                  & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                     >> 0xfU)))) {
        vlSelf->__PVT__issue_ra_value_r = vlSelf->__PVT__u_pipe_ctrl__DOT__result_e2_r;
    }
    if (((IData)(vlSelf->__PVT__pipe_rd_e1_w) == (0x1fU 
                                                  & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                     >> 0xfU)))) {
        vlSelf->__PVT__issue_ra_value_r = vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__result_q;
    }
    if ((0U == (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                         >> 0xfU)))) {
        vlSelf->__PVT__issue_ra_value_r = 0U;
    }
}

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__1(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__1\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_hecf9c89a__0;
    VlWide<3>/*95:0*/ __Vtemp_hf1ea3a5d__0;
    VlWide<3>/*95:0*/ __Vtemp_h5cfe69df__0;
    VlWide<3>/*95:0*/ __Vtemp_h246d2a09__0;
    VlWide<3>/*95:0*/ __Vtemp_h40572811__0;
    VlWide<3>/*95:0*/ __Vtemp_ha2fe9308__0;
    // Body
    vlSelf->__PVT__opcode_valid_w = (((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_valid_w) 
                                      & (~ (IData)(vlSelf->__PVT__pipe_squash_e1_e2_w))) 
                                     & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)));
    vlSelf->__PVT__opcode_issue_r = 0U;
    vlSelf->__PVT__opcode_accept_r = 0U;
    vlSelf->__PVT__scoreboard_r = 0U;
    if ((IData)((0U != (0x22U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))))) {
        vlSelf->__PVT__scoreboard_r = (vlSelf->__PVT__scoreboard_r 
                                       | (0xffffffffULL 
                                          & ((IData)(1U) 
                                             << (IData)(vlSelf->__PVT__pipe_rd_e1_w))));
    }
    if (((IData)((0U != (6U & (IData)(vlSelf->__PVT__u_pipe_ctrl__DOT__ctrl_e1_q)))) 
         & (((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_mul_w) 
             | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w)) 
            | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w)))) {
        vlSelf->__PVT__scoreboard_r = 0xffffffffU;
    }
    if ((1U & (~ (((((((((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q) 
                           | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                          | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                         | (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w)) 
                        | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                       & (~ (IData)(vlSymsp->TOP__v.__PVT__dport_accept_w))) 
                      | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w)) 
                     | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q)) 
                    | (IData)(vlSelf->__PVT__pipe_stall_raw_w)) 
                   | (IData)(vlSelf->__PVT__div_pending_q)) 
                  | (IData)(vlSelf->__PVT__csr_pending_q))))) {
        if (((IData)(vlSelf->__PVT__opcode_valid_w) 
             & (~ (((vlSelf->__PVT__scoreboard_r >> 
                     (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                               >> 0xfU))) | (vlSelf->__PVT__scoreboard_r 
                                             >> (0x1fU 
                                                 & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                    >> 0x14U)))) 
                   | (vlSelf->__PVT__scoreboard_r >> 
                      (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                >> 7U))))))) {
            vlSelf->__PVT__opcode_issue_r = 1U;
            vlSelf->__PVT__opcode_accept_r = 1U;
            if (((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w) 
                 & (0U != (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                    >> 7U))))) {
                vlSelf->__PVT__scoreboard_r = (vlSelf->__PVT__scoreboard_r 
                                               | (0xffffffffULL 
                                                  & ((IData)(1U) 
                                                     << 
                                                     (0x1fU 
                                                      & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                         >> 7U)))));
            }
        }
    }
    vlSelf->__PVT__fetch_accept_o = (1U & ((~ (IData)(vlSelf->__PVT__opcode_valid_w)) 
                                           | ((IData)(vlSelf->__PVT__opcode_accept_r) 
                                              & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q)))));
    if (vlSelf->__PVT__opcode_issue_r) {
        vlSelf->__PVT__csr_opcode_invalid_o = vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__u_dec__DOT__invalid_w;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_pc = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[2U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[2U] = 0U;
        if (((((((((0x7013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                   | (0x13U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                  | (0x2013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                 | (0x3013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                | (0x6013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
               | (0x4013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
              | (0x1013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
             | (0x5013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            if ((0x7013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x616e6469U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x13U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x61646469U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x736c7469U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x3013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c746975U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x73U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6f7269U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x4013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x786f7269U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] 
                    = ((0x1013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                        ? 0x736c6c69U : 0x73726c69U);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x40005013U == (0xfc00707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                          | (0x37U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x17U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x33U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x40000033U == (0xfe00707fU 
                                          & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x2033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x3033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x4033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            if ((0x40005013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x73726169U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x37U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c7569U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x17U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x75697063U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x61U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x33U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x616464U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x40000033U == (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x737562U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x736c74U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] 
                    = ((0x3033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                        ? 0x736c7475U : 0x786f72U);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x6033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                          | (0x7033U == (0xfe00707fU 
                                         & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x1033U == (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x5033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x40005033U == (0xfe00707fU 
                                          & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x67U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x63U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            if ((0x6033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6f72U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x7033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x616e64U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x1033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x736c6cU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x73726cU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x40005033U == (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x737261U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6a616cU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] 
                    = ((0x67U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                        ? 0x6a616c72U : 0x626571U);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x1063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                          | (0x4063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x5063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x6063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x7063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x1003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x2003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            if ((0x1063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x626e65U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x4063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x626c74U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x626765U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x626c7475U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x7063U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x62676575U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c62U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] 
                    = ((0x1003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                        ? 0x6c68U : 0x6c77U);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x4003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                          | (0x5003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x6003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x1023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x2023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x73U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                    | (0x100073U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
            if ((0x4003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c6275U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c6875U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c7775U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x7362U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x1023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x7368U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x7377U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x73U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x63616c6cU;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x65U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x7265616bU;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x6562U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x200073U == (0xcfffffffU 
                                         & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                          | (0x1073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x2073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x3073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x5073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x6073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x7073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x2000033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            if ((0x200073U == (0xcfffffffU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x65726574U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x1073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x73727277U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x73727273U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x3073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x73727263U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x63U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x5073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x72727769U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x6373U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x6073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x72727369U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x6373U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x7073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x72726369U;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x6373U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6d756cU;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        } else if (((((((((0x2001033U == (0xfe00707fU 
                                          & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                          | (0x2002033U == (0xfe00707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x2003033U == (0xfe00707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x2004033U == (0xfe00707fU 
                                          & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x2005033U == (0xfe00707fU 
                                         & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x2006033U == (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x2007033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x100fU == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
            if ((0x2001033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6d756c68U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2002033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x6c687375U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x6d75U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2003033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x756c6875U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x6dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2004033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x646976U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2005033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x64697675U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else if ((0x2006033U == (0xfe00707fU 
                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x72656dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            } else {
                if ((0x2007033U == (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x72656d75U;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                } else {
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x63652e69U;
                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x66656eU;
                }
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
            }
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_pc 
            = vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w;
        vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum 
            = (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                        >> 0xfU));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                        __Vtemp_hecf9c89a__0[0U] = 0x7436U;
                        __Vtemp_hf1ea3a5d__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_hecf9c89a__0[0U] = 0x7435U;
                        __Vtemp_hf1ea3a5d__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                    __Vtemp_hecf9c89a__0[0U] = 0x7434U;
                    __Vtemp_hf1ea3a5d__0[0U] = 0x6133U;
                } else {
                    __Vtemp_hecf9c89a__0[0U] = 0x7433U;
                    __Vtemp_hf1ea3a5d__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                    __Vtemp_hecf9c89a__0[0U] = 0x733131U;
                    __Vtemp_hf1ea3a5d__0[0U] = 0x6131U;
                } else {
                    __Vtemp_hecf9c89a__0[0U] = 0x733130U;
                    __Vtemp_hf1ea3a5d__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                __Vtemp_hecf9c89a__0[0U] = 0x7339U;
                __Vtemp_hf1ea3a5d__0[0U] = 0x7331U;
            } else {
                __Vtemp_hecf9c89a__0[0U] = 0x7338U;
                __Vtemp_hf1ea3a5d__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                    __Vtemp_hecf9c89a__0[0U] = 0x7337U;
                    __Vtemp_hf1ea3a5d__0[0U] = 0x7432U;
                } else {
                    __Vtemp_hecf9c89a__0[0U] = 0x7336U;
                    __Vtemp_hf1ea3a5d__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                __Vtemp_hecf9c89a__0[0U] = 0x7335U;
                __Vtemp_hf1ea3a5d__0[0U] = 0x7430U;
            } else {
                __Vtemp_hecf9c89a__0[0U] = 0x7334U;
                __Vtemp_hf1ea3a5d__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
                __Vtemp_hecf9c89a__0[0U] = 0x7333U;
                __Vtemp_hf1ea3a5d__0[0U] = 0x6770U;
            } else {
                __Vtemp_hecf9c89a__0[0U] = 0x7332U;
                __Vtemp_hf1ea3a5d__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
            __Vtemp_hecf9c89a__0[0U] = 0x6137U;
            __Vtemp_hf1ea3a5d__0[0U] = 0x7261U;
        } else {
            __Vtemp_hecf9c89a__0[0U] = 0x6136U;
            __Vtemp_hf1ea3a5d__0[0U] = 0x7a65726fU;
        }
        __Vtemp_hecf9c89a__0[1U] = 0U;
        __Vtemp_hecf9c89a__0[2U] = 0U;
        __Vtemp_hf1ea3a5d__0[1U] = 0U;
        __Vtemp_hf1ea3a5d__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__regnum))) {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[0U] 
                = __Vtemp_hecf9c89a__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[1U] 
                = __Vtemp_hecf9c89a__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[2U] 
                = __Vtemp_hecf9c89a__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[0U] 
                = __Vtemp_hf1ea3a5d__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[1U] 
                = __Vtemp_hf1ea3a5d__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[2U] 
                = __Vtemp_hf1ea3a5d__0[2U];
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[0U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[1U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[2U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__0__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum 
            = (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                        >> 0x14U));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                        __Vtemp_h5cfe69df__0[0U] = 0x7436U;
                        __Vtemp_h246d2a09__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_h5cfe69df__0[0U] = 0x7435U;
                        __Vtemp_h246d2a09__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                    __Vtemp_h5cfe69df__0[0U] = 0x7434U;
                    __Vtemp_h246d2a09__0[0U] = 0x6133U;
                } else {
                    __Vtemp_h5cfe69df__0[0U] = 0x7433U;
                    __Vtemp_h246d2a09__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                    __Vtemp_h5cfe69df__0[0U] = 0x733131U;
                    __Vtemp_h246d2a09__0[0U] = 0x6131U;
                } else {
                    __Vtemp_h5cfe69df__0[0U] = 0x733130U;
                    __Vtemp_h246d2a09__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                __Vtemp_h5cfe69df__0[0U] = 0x7339U;
                __Vtemp_h246d2a09__0[0U] = 0x7331U;
            } else {
                __Vtemp_h5cfe69df__0[0U] = 0x7338U;
                __Vtemp_h246d2a09__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                    __Vtemp_h5cfe69df__0[0U] = 0x7337U;
                    __Vtemp_h246d2a09__0[0U] = 0x7432U;
                } else {
                    __Vtemp_h5cfe69df__0[0U] = 0x7336U;
                    __Vtemp_h246d2a09__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                __Vtemp_h5cfe69df__0[0U] = 0x7335U;
                __Vtemp_h246d2a09__0[0U] = 0x7430U;
            } else {
                __Vtemp_h5cfe69df__0[0U] = 0x7334U;
                __Vtemp_h246d2a09__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
                __Vtemp_h5cfe69df__0[0U] = 0x7333U;
                __Vtemp_h246d2a09__0[0U] = 0x6770U;
            } else {
                __Vtemp_h5cfe69df__0[0U] = 0x7332U;
                __Vtemp_h246d2a09__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
            __Vtemp_h5cfe69df__0[0U] = 0x6137U;
            __Vtemp_h246d2a09__0[0U] = 0x7261U;
        } else {
            __Vtemp_h5cfe69df__0[0U] = 0x6136U;
            __Vtemp_h246d2a09__0[0U] = 0x7a65726fU;
        }
        __Vtemp_h5cfe69df__0[1U] = 0U;
        __Vtemp_h5cfe69df__0[2U] = 0U;
        __Vtemp_h246d2a09__0[1U] = 0U;
        __Vtemp_h246d2a09__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__regnum))) {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[0U] 
                = __Vtemp_h5cfe69df__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[1U] 
                = __Vtemp_h5cfe69df__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[2U] 
                = __Vtemp_h5cfe69df__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[0U] 
                = __Vtemp_h246d2a09__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[1U] 
                = __Vtemp_h246d2a09__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[2U] 
                = __Vtemp_h246d2a09__0[2U];
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__1__Vfuncout[2U];
        vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum 
            = (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                        >> 7U));
        if ((8U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
            if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                    if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                        __Vtemp_h40572811__0[0U] = 0x7436U;
                        __Vtemp_ha2fe9308__0[0U] = 0x6135U;
                    } else {
                        __Vtemp_h40572811__0[0U] = 0x7435U;
                        __Vtemp_ha2fe9308__0[0U] = 0x6134U;
                    }
                } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                    __Vtemp_h40572811__0[0U] = 0x7434U;
                    __Vtemp_ha2fe9308__0[0U] = 0x6133U;
                } else {
                    __Vtemp_h40572811__0[0U] = 0x7433U;
                    __Vtemp_ha2fe9308__0[0U] = 0x6132U;
                }
            } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                    __Vtemp_h40572811__0[0U] = 0x733131U;
                    __Vtemp_ha2fe9308__0[0U] = 0x6131U;
                } else {
                    __Vtemp_h40572811__0[0U] = 0x733130U;
                    __Vtemp_ha2fe9308__0[0U] = 0x6130U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                __Vtemp_h40572811__0[0U] = 0x7339U;
                __Vtemp_ha2fe9308__0[0U] = 0x7331U;
            } else {
                __Vtemp_h40572811__0[0U] = 0x7338U;
                __Vtemp_ha2fe9308__0[0U] = 0x7330U;
            }
        } else if ((4U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
            if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                    __Vtemp_h40572811__0[0U] = 0x7337U;
                    __Vtemp_ha2fe9308__0[0U] = 0x7432U;
                } else {
                    __Vtemp_h40572811__0[0U] = 0x7336U;
                    __Vtemp_ha2fe9308__0[0U] = 0x7431U;
                }
            } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                __Vtemp_h40572811__0[0U] = 0x7335U;
                __Vtemp_ha2fe9308__0[0U] = 0x7430U;
            } else {
                __Vtemp_h40572811__0[0U] = 0x7334U;
                __Vtemp_ha2fe9308__0[0U] = 0x7470U;
            }
        } else if ((2U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
            if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
                __Vtemp_h40572811__0[0U] = 0x7333U;
                __Vtemp_ha2fe9308__0[0U] = 0x6770U;
            } else {
                __Vtemp_h40572811__0[0U] = 0x7332U;
                __Vtemp_ha2fe9308__0[0U] = 0x7370U;
            }
        } else if ((1U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
            __Vtemp_h40572811__0[0U] = 0x6137U;
            __Vtemp_ha2fe9308__0[0U] = 0x7261U;
        } else {
            __Vtemp_h40572811__0[0U] = 0x6136U;
            __Vtemp_ha2fe9308__0[0U] = 0x7a65726fU;
        }
        __Vtemp_h40572811__0[1U] = 0U;
        __Vtemp_h40572811__0[2U] = 0U;
        __Vtemp_ha2fe9308__0[1U] = 0U;
        __Vtemp_ha2fe9308__0[2U] = 0U;
        if ((0x10U & (IData)(vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__regnum))) {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[0U] 
                = __Vtemp_h40572811__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[1U] 
                = __Vtemp_h40572811__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[2U] 
                = __Vtemp_h40572811__0[2U];
        } else {
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[0U] 
                = __Vtemp_ha2fe9308__0[0U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[1U] 
                = __Vtemp_ha2fe9308__0[1U];
            vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[2U] 
                = __Vtemp_ha2fe9308__0[2U];
        }
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[0U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[0U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[1U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[1U];
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[2U] 
            = vlSelf->__Vfunc_u_pipe_ctrl__DOT__u_trace_d__DOT__get_regname_str__2__Vfuncout[2U];
        if ((((((((((((((((((((0x13U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                              | (0x7013U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x2013U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                            | (0x3013U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0x6013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x4013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x1073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x2073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x3073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x5073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x6073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x7073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                   | (((0x1013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                       | (0x5013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x40005013U == (0xfc00707fU 
                                         & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) 
                  | (0x37U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                 | (0x17U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                | (0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
               | (0x67U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
              | ((((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                     | (0x1003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x2003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                   | (0x4003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                  | (0x5003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                 | (0x6003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) 
             | (((0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                 | (0x1023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                | (0x2023U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))))) {
            if ((1U & (~ ((((((((((((0x13U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                    | (0x7013U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x2013U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x3013U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x6013U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x4013U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                               | (0x1073U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x2073U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                             | (0x3073U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                            | (0x5073U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0x6073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x7073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))))) {
                if ((1U & (~ (((0x1013U == (0xfc00707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                               | (0x5013U == (0xfc00707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                              | (0x40005013U == (0xfc00707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))))) {
                    if ((0x37U != (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                        if ((0x17U != (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                            if ((0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                                if ((1U == (0x1fU & 
                                            (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                             >> 7U)))) {
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x63616c6cU;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
                                }
                            } else if ((0x67U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                                if ((IData)(((0x8000U 
                                              == (0xf8000U 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                             & (0U 
                                                == 
                                                (((- (IData)(
                                                             (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                              >> 0x1fU))) 
                                                  << 0xcU) 
                                                 | (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                    >> 0x14U)))))) {
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x726574U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
                                } else if ((1U == (0x1fU 
                                                   & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                      >> 7U)))) {
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x20285229U;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0x63616c6cU;
                                    vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
                                }
                            }
                            if ((0x6fU != (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                                if ((0x67U != (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                                    if ((1U & (~ ((
                                                   ((((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                                      | (0x1003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                     | (0x2003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                    | (0x4003U 
                                                       == 
                                                       (0x707fU 
                                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                   | (0x5003U 
                                                      == 
                                                      (0x707fU 
                                                       & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                                  | (0x6003U 
                                                     == 
                                                     (0x707fU 
                                                      & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))))) {
                                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[0U] = 0x2dU;
                                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[1U] = 0U;
                                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[2U] = 0U;
                                    }
                                }
                            }
                        }
                    }
                    if ((0x37U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[0U] = 0x2dU;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[2U] = 0U;
                    } else if ((0x17U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[0U] = 0x7063U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[2U] = 0U;
                    } else if ((0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[0U] = 0x2dU;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[1U] = 0U;
                        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[2U] = 0U;
                    }
                }
            }
            if (((((((((((((0x13U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                           | (0x7013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x2013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x3013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x6013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                       | (0x4013U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                      | (0x1073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                     | (0x2073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                    | (0x3073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                   | (0x5073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                  | (0x6073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                 | (0x7073U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((((0x1013U == (0xfc00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                         | (0x5013U == (0xfc00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x40005013U == (0xfc00707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x37U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (0xfffff000U & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x17U == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (0xfffff000U & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w);
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x6fU == (0x7fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w 
                       + (((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                       >> 0x1fU))) 
                           << 0x14U) | ((0xff000U & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w) 
                                        | ((0x800U 
                                            & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                               >> 9U)) 
                                           | ((0x7e0U 
                                               & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                  >> 0x14U)) 
                                              | (0x1eU 
                                                 & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                    >> 0x14U)))))));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else if ((0x67U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else if (((((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                            | (0x1003U == (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                           | (0x2003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                          | (0x4003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                         | (0x5003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                        | (0x6003U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))) {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                          >> 0x14U));
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
            } else {
                vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm 
                    = (((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0xfe0U & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                     >> 0x14U)) | (0x1fU 
                                                   & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                      >> 7U))));
            }
        }
        vlSelf->__PVT__lsu_opcode_valid_o = (1U & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q)));
        vlSelf->__PVT__csr_opcode_valid_o = (1U & (~ (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q)));
    } else {
        vlSelf->__PVT__csr_opcode_invalid_o = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str[2U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_pc = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra[2U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb[2U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[0U] = 0x2dU;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[1U] = 0U;
        vlSelf->__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd[2U] = 0U;
        vlSelf->__PVT__lsu_opcode_valid_o = 0U;
        vlSelf->__PVT__csr_opcode_valid_o = 0U;
    }
}

VL_INLINE_OPT void Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__2(Vriscv_tcm_top_riscv_issue* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_riscv_issue___combo__TOP__v__u_core__u_issue__2\n"); );
    // Body
    vlSelf->__PVT__branch_request_o = ((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q) 
                                       | (IData)(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w));
}
