// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vriscv_tcm_top___024root.h"

VL_INLINE_OPT void Vriscv_tcm_top___024root___combo__TOP__0(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___combo__TOP__0\n"); );
    // Body
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_t_rready_i, vlSelf->axi_t_rready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_t_bready_i, vlSelf->axi_t_bready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_arready_i, vlSelf->axi_i_arready_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__intr_i, vlSelf->intr_i);
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_t_wstrb_i, vlSelf->axi_t_wstrb_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__axi_i_rdata_i, vlSelf->axi_i_rdata_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_i_rresp_i, vlSelf->axi_i_rresp_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_i_bresp_i, vlSelf->axi_i_bresp_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_rvalid_i, vlSelf->axi_i_rvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_bvalid_i, vlSelf->axi_i_bvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__clk_i, vlSelf->clk_i);
}

VL_INLINE_OPT void Vriscv_tcm_top___024root___combo__TOP__1(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___combo__TOP__1\n"); );
    // Body
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_t_awburst_i, vlSelf->axi_t_awburst_i);
    VL_ASSIGN_ISU(2,vlSelf->__Vcellinp__v__axi_t_arburst_i, vlSelf->axi_t_arburst_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_t_wlast_i, vlSelf->axi_t_wlast_i);
    VL_ASSIGN_ISU(8,vlSelf->__Vcellinp__v__axi_t_awlen_i, vlSelf->axi_t_awlen_i);
    VL_ASSIGN_ISU(8,vlSelf->__Vcellinp__v__axi_t_arlen_i, vlSelf->axi_t_arlen_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__axi_t_awaddr_i, vlSelf->axi_t_awaddr_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__axi_t_araddr_i, vlSelf->axi_t_araddr_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_t_wvalid_i, vlSelf->axi_t_wvalid_i);
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_t_awid_i, vlSelf->axi_t_awid_i);
    VL_ASSIGN_ISU(4,vlSelf->__Vcellinp__v__axi_t_arid_i, vlSelf->axi_t_arid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_t_awvalid_i, vlSelf->axi_t_awvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_t_arvalid_i, vlSelf->axi_t_arvalid_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_awready_i, vlSelf->axi_i_awready_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__axi_i_wready_i, vlSelf->axi_i_wready_i);
    VL_ASSIGN_ISU(32,vlSelf->__Vcellinp__v__axi_t_wdata_i, vlSelf->axi_t_wdata_i);
}

VL_INLINE_OPT void Vriscv_tcm_top___024root___combo__TOP__3(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___combo__TOP__3\n"); );
    // Body
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__rst_cpu_i, vlSelf->rst_cpu_i);
    VL_ASSIGN_ISI(1,vlSelf->__Vcellinp__v__rst_i, vlSelf->rst_i);
}

QData Vriscv_tcm_top___024root___change_request_1(Vriscv_tcm_top___024root* vlSelf);

VL_INLINE_OPT QData Vriscv_tcm_top___024root___change_request(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___change_request\n"); );
    // Body
    return (Vriscv_tcm_top___024root___change_request_1(vlSelf));
}

VL_INLINE_OPT QData Vriscv_tcm_top___024root___change_request_1(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___change_request_1\n"); );
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    __req |= ((vlSelf->__Vcellinp__v__rst_cpu_i ^ vlSelf->__Vchglast__TOP____Vcellinp__v__rst_cpu_i)
         | (vlSelf->__Vcellinp__v__rst_i ^ vlSelf->__Vchglast__TOP____Vcellinp__v__rst_i));
    VL_DEBUG_IF( if(__req && ((vlSelf->__Vcellinp__v__rst_cpu_i ^ vlSelf->__Vchglast__TOP____Vcellinp__v__rst_cpu_i))) VL_DBG_MSGF("        CHANGE: ../src_v/../src_v/riscv_tcm_top.v:63: __Vcellinp__v__rst_cpu_i\n"); );
    VL_DEBUG_IF( if(__req && ((vlSelf->__Vcellinp__v__rst_i ^ vlSelf->__Vchglast__TOP____Vcellinp__v__rst_i))) VL_DBG_MSGF("        CHANGE: ../src_v/../src_v/riscv_tcm_top.v:62: __Vcellinp__v__rst_i\n"); );
    // Final
    vlSelf->__Vchglast__TOP____Vcellinp__v__rst_cpu_i 
        = vlSelf->__Vcellinp__v__rst_cpu_i;
    vlSelf->__Vchglast__TOP____Vcellinp__v__rst_i = vlSelf->__Vcellinp__v__rst_i;
    return __req;
}

#ifdef VL_DEBUG
void Vriscv_tcm_top___024root___eval_debug_assertions(Vriscv_tcm_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_debug_assertions\n"); );
}
#endif  // VL_DEBUG
