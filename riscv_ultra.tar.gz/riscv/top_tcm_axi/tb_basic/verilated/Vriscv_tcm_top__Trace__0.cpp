// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "Vriscv_tcm_top__Syms.h"


void Vriscv_tcm_top___024root__trace_chg_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vriscv_tcm_top___024root__trace_chg_top_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_chg_top_0\n"); );
    // Init
    Vriscv_tcm_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_tcm_top___024root*>(voidSelf);
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vriscv_tcm_top___024root__trace_chg_sub_0((&vlSymsp->TOP), bufp);
}

void Vriscv_tcm_top___024root__trace_chg_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    if (false && vlSelf) {}  // Prevent unused
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_chg_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    VlWide<3>/*95:0*/ __Vtemp_h2633fc29__0;
    // Body
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[1U])) {
        bufp->chgBit(oldp+0,(vlSelf->__Vcellinp__v__clk_i));
        bufp->chgBit(oldp+1,(vlSelf->__Vcellinp__v__rst_i));
        bufp->chgBit(oldp+2,(vlSelf->__Vcellinp__v__rst_cpu_i));
        bufp->chgBit(oldp+3,(vlSelf->__Vcellinp__v__axi_i_awready_i));
        bufp->chgBit(oldp+4,(vlSelf->__Vcellinp__v__axi_i_wready_i));
        bufp->chgBit(oldp+5,(vlSelf->__Vcellinp__v__axi_i_bvalid_i));
        bufp->chgCData(oldp+6,(vlSelf->__Vcellinp__v__axi_i_bresp_i),2);
        bufp->chgBit(oldp+7,(vlSelf->__Vcellinp__v__axi_i_arready_i));
        bufp->chgBit(oldp+8,(vlSelf->__Vcellinp__v__axi_i_rvalid_i));
        bufp->chgIData(oldp+9,(vlSelf->__Vcellinp__v__axi_i_rdata_i),32);
        bufp->chgCData(oldp+10,(vlSelf->__Vcellinp__v__axi_i_rresp_i),2);
        bufp->chgBit(oldp+11,(vlSelf->__Vcellinp__v__axi_t_awvalid_i));
        bufp->chgIData(oldp+12,(vlSelf->__Vcellinp__v__axi_t_awaddr_i),32);
        bufp->chgCData(oldp+13,(vlSelf->__Vcellinp__v__axi_t_awid_i),4);
        bufp->chgCData(oldp+14,(vlSelf->__Vcellinp__v__axi_t_awlen_i),8);
        bufp->chgCData(oldp+15,(vlSelf->__Vcellinp__v__axi_t_awburst_i),2);
        bufp->chgBit(oldp+16,(vlSelf->__Vcellinp__v__axi_t_wvalid_i));
        bufp->chgIData(oldp+17,(vlSelf->__Vcellinp__v__axi_t_wdata_i),32);
        bufp->chgCData(oldp+18,(vlSelf->__Vcellinp__v__axi_t_wstrb_i),4);
        bufp->chgBit(oldp+19,(vlSelf->__Vcellinp__v__axi_t_wlast_i));
        bufp->chgBit(oldp+20,(vlSelf->__Vcellinp__v__axi_t_bready_i));
        bufp->chgBit(oldp+21,(vlSelf->__Vcellinp__v__axi_t_arvalid_i));
        bufp->chgIData(oldp+22,(vlSelf->__Vcellinp__v__axi_t_araddr_i),32);
        bufp->chgCData(oldp+23,(vlSelf->__Vcellinp__v__axi_t_arid_i),4);
        bufp->chgCData(oldp+24,(vlSelf->__Vcellinp__v__axi_t_arlen_i),8);
        bufp->chgCData(oldp+25,(vlSelf->__Vcellinp__v__axi_t_arburst_i),2);
        bufp->chgBit(oldp+26,(vlSelf->__Vcellinp__v__axi_t_rready_i));
        bufp->chgIData(oldp+27,(vlSelf->__Vcellinp__v__intr_i),32);
        bufp->chgBit(oldp+28,(vlSymsp->TOP__v.axi_i_awvalid_o));
        bufp->chgBit(oldp+29,(vlSymsp->TOP__v.axi_i_wvalid_o));
        bufp->chgBit(oldp+30,(vlSymsp->TOP__v.__PVT__u_axi__DOT__req_is_read_w));
        bufp->chgBit(oldp+31,(vlSymsp->TOP__v__u_tcm.__PVT__axi_awready_o));
        bufp->chgBit(oldp+32,(vlSymsp->TOP__v__u_tcm.__PVT__axi_wready_o));
        bufp->chgBit(oldp+33,(vlSymsp->TOP__v__u_tcm.__PVT__axi_arready_o));
        bufp->chgCData(oldp+34,(vlSymsp->TOP__v.__PVT__dport_tcm_wr_w),4);
        bufp->chgBit(oldp+35,(vlSymsp->TOP__v__u_core.__PVT__mmu_ifetch_rd_w));
        bufp->chgBit(oldp+36,(vlSymsp->TOP__v.__PVT__dport_ack_w));
        bufp->chgBit(oldp+37,(((IData)(vlSelf->__Vcellinp__v__axi_i_bvalid_i)
                                ? (0U != (IData)(vlSelf->__Vcellinp__v__axi_i_bresp_i))
                                : (0U != (IData)(vlSelf->__Vcellinp__v__axi_i_rresp_i)))));
        bufp->chgBit(oldp+38,(vlSymsp->TOP__v.__PVT__dport_tcm_rd_w));
        bufp->chgBit(oldp+39,(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w));
        bufp->chgBit(oldp+40,(vlSymsp->TOP__v.__PVT__dport_axi_ack_w));
        bufp->chgBit(oldp+41,(vlSymsp->TOP__v.__PVT__dport_axi_rd_w));
        bufp->chgBit(oldp+42,(vlSymsp->TOP__v.__PVT__dport_error_w));
        bufp->chgCData(oldp+43,(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w),4);
        bufp->chgCData(oldp+44,(vlSymsp->TOP__v.__PVT__dport_axi_wr_w),4);
        bufp->chgBit(oldp+45,(vlSymsp->TOP__v.__PVT__u_axi__DOT__write_complete_w));
        bufp->chgBit(oldp+46,(vlSymsp->TOP__v.__PVT__u_axi__DOT__read_complete_w));
        bufp->chgBit(oldp+47,(vlSymsp->TOP__v.__PVT__u_axi__DOT__req_pop_w));
        bufp->chgBit(oldp+48,(vlSymsp->TOP__v.__PVT__u_axi__DOT__req_push_w));
        bufp->chgBit(oldp+49,(vlSymsp->TOP__v.__PVT__u_axi__DOT__res_push_w));
        bufp->chgBit(oldp+50,(vlSymsp->TOP__v.__PVT__u_axi__DOT__request_in_progress_w));
        bufp->chgBit(oldp+51,(vlSymsp->TOP__v.__PVT__u_axi__DOT__req_is_write_w));
        bufp->chgBit(oldp+52,(vlSymsp->TOP__v.__PVT__u_dmux__DOT__request_w));
        bufp->chgCData(oldp+53,(vlSymsp->TOP__v.__PVT__u_dmux__DOT__pending_r),5);
        bufp->chgCData(oldp+54,(vlSymsp->TOP__v__u_tcm.__PVT__ext_wr_w),4);
        bufp->chgBit(oldp+55,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__read_active_w));
        bufp->chgCData(oldp+56,(((IData)(vlSelf->__Vcellinp__v__axi_t_awvalid_i)
                                  ? (IData)(vlSelf->__Vcellinp__v__axi_t_awlen_i)
                                  : ((IData)(vlSelf->__Vcellinp__v__axi_t_arvalid_i)
                                      ? (IData)(vlSelf->__Vcellinp__v__axi_t_arlen_i)
                                      : 0U))),8);
        bufp->chgSData(oldp+57,(vlSymsp->TOP__v__u_tcm.__PVT__muxed_addr_w),14);
        bufp->chgBit(oldp+58,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_push_w));
        bufp->chgBit(oldp+59,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__resp_accept_w));
        bufp->chgBit(oldp+60,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__write_active_w));
        bufp->chgBit(oldp+61,(((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__write_active_w) 
                               & (IData)(vlSelf->__Vcellinp__v__axi_t_wvalid_i))));
        bufp->chgBit(oldp+62,((1U & vlSelf->__Vcellinp__v__intr_i)));
        bufp->chgBit(oldp+63,(vlSymsp->TOP__v__u_core__u_issue.__PVT__fetch_accept_o));
        bufp->chgIData(oldp+64,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r),32);
        bufp->chgBit(oldp+65,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o));
        bufp->chgBit(oldp+66,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_issue_r));
        bufp->chgBit(oldp+67,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_invalid_o));
        bufp->chgBit(oldp+68,(vlSymsp->TOP__v__u_core__u_issue.__PVT__branch_request_o));
        bufp->chgBit(oldp+69,(vlSymsp->TOP__v__u_core.__PVT__writeback_mem_valid_w));
        bufp->chgIData(oldp+70,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r),32);
        bufp->chgBit(oldp+71,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w));
        bufp->chgBit(oldp+72,(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w));
        bufp->chgIData(oldp+73,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__wb_result_r),32);
        bufp->chgIData(oldp+74,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r),32);
        bufp->chgBit(oldp+75,(vlSymsp->TOP__v__u_core__u_issue.__PVT__lsu_opcode_valid_o));
        bufp->chgBit(oldp+76,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_start_w));
        bufp->chgIData(oldp+77,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_input_a_r),32);
        bufp->chgIData(oldp+78,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_input_b_r),32);
        bufp->chgIData(oldp+79,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__result_r),32);
        bufp->chgBit(oldp+80,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_r));
        bufp->chgSData(oldp+81,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_fill_r),16);
        bufp->chgIData(oldp+82,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_1_r),32);
        bufp->chgIData(oldp+83,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_2_r),32);
        bufp->chgIData(oldp+84,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_4_r),32);
        bufp->chgIData(oldp+85,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_right_8_r),32);
        bufp->chgIData(oldp+86,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_1_r),32);
        bufp->chgIData(oldp+87,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_2_r),32);
        bufp->chgIData(oldp+88,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_4_r),32);
        bufp->chgIData(oldp+89,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__shift_left_8_r),32);
        bufp->chgIData(oldp+90,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__u_alu__DOT__sub_res_w),32);
        bufp->chgBit(oldp+91,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__stall_w));
        bufp->chgBit(oldp+92,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__complete_ok_e2_w));
        bufp->chgBit(oldp+93,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__complete_err_e2_w));
        bufp->chgBit(oldp+94,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w));
        bufp->chgIData(oldp+95,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_r),32);
        bufp->chgBit(oldp+96,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_r));
        bufp->chgIData(oldp+97,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_r),32);
        bufp->chgBit(oldp+98,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_rd_r));
        bufp->chgCData(oldp+99,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_wr_r),4);
        bufp->chgCData(oldp+100,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__addr_lsb_r),2);
        bufp->chgBit(oldp+101,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_byte_r));
        bufp->chgBit(oldp+102,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_half_r));
        bufp->chgBit(oldp+103,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_signed_r));
        bufp->chgBit(oldp+104,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellinp__u_lsu_request__push_i));
        bufp->chgBit(oldp+105,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellinp__u_lsu_request__pop_i));
        bufp->chgBit(oldp+106,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_squash_e1_e2_w));
        bufp->chgBit(oldp+107,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_valid_w));
        bufp->chgBit(oldp+108,(vlSymsp->TOP__v__u_core__u_issue.__PVT__opcode_accept_r));
        bufp->chgCData(oldp+109,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_e2_w),5);
        bufp->chgIData(oldp+110,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_e2_r),32);
        bufp->chgBit(oldp+111,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_valid_wb_w));
        bufp->chgCData(oldp+112,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_wb_w),5);
        bufp->chgIData(oldp+113,(vlSymsp->TOP__v__u_core__u_issue.__PVT__scoreboard_r),32);
        bufp->chgBit(oldp+114,((0U != (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_r))));
        bufp->chgBit(oldp+115,(((IData)(vlSymsp->TOP__v__u_core.__PVT__branch_d_exec_request_w) 
                                & (0U != (3U & vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)))));
        bufp->chgBit(oldp+116,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e2_w));
        bufp->chgCData(oldp+117,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_r),6);
        bufp->chgWData(oldp+118,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_str),80);
        bufp->chgWData(oldp+121,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_ra),80);
        bufp->chgWData(oldp+124,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rb),80);
        bufp->chgWData(oldp+127,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_rd),80);
        bufp->chgIData(oldp+130,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_imm),32);
        bufp->chgIData(oldp+131,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_d__DOT__dbg_inst_pc),32);
        bufp->chgWData(oldp+132,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_str),80);
        bufp->chgWData(oldp+135,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_ra),80);
        bufp->chgWData(oldp+138,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rb),80);
        bufp->chgWData(oldp+141,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_rd),80);
        bufp->chgIData(oldp+144,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_imm),32);
        bufp->chgIData(oldp+145,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__u_trace_wb__DOT__dbg_inst_pc),32);
        bufp->chgWData(oldp+146,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_str),80);
        bufp->chgWData(oldp+149,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_ra),80);
        bufp->chgWData(oldp+152,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rb),80);
        bufp->chgWData(oldp+155,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_rd),80);
        bufp->chgIData(oldp+158,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_imm),32);
        bufp->chgIData(oldp+159,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_dec0_verif__DOT__dbg_inst_pc),32);
        bufp->chgBit(oldp+160,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrw_w));
        bufp->chgBit(oldp+161,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrwi_w));
        bufp->chgBit(oldp+162,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrsi_w));
        bufp->chgBit(oldp+163,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrci_w));
        bufp->chgBit(oldp+164,(vlSymsp->TOP__v__u_core__u_csr.__PVT__sfence_w));
        bufp->chgBit(oldp+165,(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_w));
        bufp->chgBit(oldp+166,(vlSymsp->TOP__v__u_core__u_csr.__PVT__set_r));
        bufp->chgBit(oldp+167,(vlSymsp->TOP__v__u_core__u_csr.__PVT__clr_r));
        bufp->chgIData(oldp+168,(vlSymsp->TOP__v__u_core__u_csr.__PVT__data_r),32);
        bufp->chgBit(oldp+169,(vlSymsp->TOP__v__u_core__u_csr.__PVT__satp_update_w));
        bufp->chgBit(oldp+170,(vlSymsp->TOP__v__u_core__u_csr.__PVT__eret_fault_w));
        bufp->chgIData(oldp+171,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_r),32);
        bufp->chgIData(oldp+172,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_next_r),32);
    }
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[1U] 
                     | vlSelf->__Vm_traceActivity[5U]))) {
        __Vtemp_h2633fc29__0[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              (0xfffffffcU 
                                                               & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))));
        __Vtemp_h2633fc29__0[1U] = (IData)(((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                              << 0x20U) 
                                             | (QData)((IData)(
                                                               (0xfffffffcU 
                                                                & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)))) 
                                            >> 0x20U));
        __Vtemp_h2633fc29__0[2U] = (((IData)(vlSymsp->TOP__v.__PVT__dport_axi_rd_w) 
                                     << 4U) | (IData)(vlSymsp->TOP__v.__PVT__dport_axi_wr_w));
        bufp->chgWData(oldp+173,(__Vtemp_h2633fc29__0),69);
        bufp->chgIData(oldp+176,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)
                                   ? vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_target_q
                                   : vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_target_r)),32);
        bufp->chgQData(oldp+177,(((0x2002033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                   ? (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r))
                                   : ((0x2001033U == 
                                       (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                       ? (((QData)((IData)(
                                                           (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r 
                                                            >> 0x1fU))) 
                                           << 0x20U) 
                                          | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r)))
                                       : (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_rb_value_r))))),33);
        bufp->chgQData(oldp+179,(((0x2002033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                   ? (((QData)((IData)(
                                                       (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r 
                                                        >> 0x1fU))) 
                                       << 0x20U) | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r)))
                                   : ((0x2001033U == 
                                       (0xfe00707fU 
                                        & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))
                                       ? (((QData)((IData)(
                                                           (vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r 
                                                            >> 0x1fU))) 
                                           << 0x20U) 
                                          | (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r)))
                                       : (QData)((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_ra_value_r))))),33);
        bufp->chgBit(oldp+181,((1U & (((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                       >> 3U) & (~ (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w))))));
        bufp->chgBit(oldp+182,((IData)((((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q) 
                                         >> 9U) & (~ (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_stall_raw_w))))));
        bufp->chgBit(oldp+183,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0x73U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+184,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0x100073U == vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+185,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0x200073U == (0xcfffffffU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+186,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0x2073U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+187,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0x3073U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+188,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0x10500073U == (0xffff8fffU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+189,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                                & (0xfU == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+190,(((IData)(((0U != (0xf8000U 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                         | (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrw_w))) 
                                | (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__csrrwi_w))));
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[2U])) {
        bufp->chgBit(oldp+191,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_q) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_invalidate_q))));
        bufp->chgCData(oldp+192,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__priv_f_q),2);
        bufp->chgBit(oldp+193,(vlSymsp->TOP__v__u_core__u_csr.__PVT__tlb_flush_q));
        bufp->chgIData(oldp+194,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_pc_w),32);
        bufp->chgIData(oldp+195,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__pc_m_q),32);
        bufp->chgBit(oldp+196,((1U & (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                      >> 0x13U))));
        bufp->chgCData(oldp+197,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_wb_q),6);
        bufp->chgBit(oldp+198,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ret_q));
        bufp->chgCData(oldp+199,(vlSymsp->TOP__v__u_core__u_csr.__PVT__exception_e1_q),6);
        bufp->chgBit(oldp+200,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w));
        bufp->chgBit(oldp+201,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ntaken_q));
        bufp->chgIData(oldp+202,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__pc_x_q),32);
        bufp->chgBit(oldp+203,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_q));
        bufp->chgBit(oldp+204,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w));
        bufp->chgCData(oldp+205,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o),2);
        bufp->chgBit(oldp+206,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_taken_q) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ntaken_q))));
        bufp->chgCData(oldp+207,((3U & ((0x20000U & vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q)
                                         ? (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                            >> 0xbU)
                                         : (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q)))),2);
        bufp->chgBit(oldp+208,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__valid_q));
        bufp->chgIData(oldp+209,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_q),32);
        bufp->chgIData(oldp+210,(vlSymsp->TOP__v__u_core__u_csr.__PVT__csr_wdata_e1_q),32);
        bufp->chgBit(oldp+211,(vlSymsp->TOP__v__u_core__u_csr.__PVT__ifence_q));
        bufp->chgIData(oldp+212,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wdata_wb_q),32);
        bufp->chgBit(oldp+213,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_wb_q));
        bufp->chgSData(oldp+214,((vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                  >> 0x14U)),12);
        bufp->chgBit(oldp+215,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_jmp_q));
        bufp->chgBit(oldp+216,(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_valid_e1_q));
        bufp->chgBit(oldp+217,((1U & (vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q 
                                      >> 0x12U))));
        bufp->chgIData(oldp+218,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_wb_q),32);
        bufp->chgBit(oldp+219,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_call_q));
        bufp->chgBit(oldp+220,(((IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_fetch_w) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_fault_page_w))));
        bufp->chgQData(oldp+221,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__divisor_q),63);
        bufp->chgIData(oldp+223,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__q_mask_q),32);
        bufp->chgBit(oldp+224,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_busy_q));
        bufp->chgBit(oldp+225,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__active_q));
        bufp->chgCData(oldp+226,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_priv_q),2);
        bufp->chgBit(oldp+227,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__stall_q));
        bufp->chgBit(oldp+228,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_fetch_q));
        bufp->chgBit(oldp+229,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_invalidate_q));
        bufp->chgIData(oldp+230,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_d_q),32);
        bufp->chgBit(oldp+231,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_d_q));
        bufp->chgWData(oldp+232,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__skid_buffer_q),66);
        bufp->chgBit(oldp+235,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__skid_valid_q));
        bufp->chgBit(oldp+236,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__pending_lsu_e2_q));
        bufp->chgBit(oldp+237,((1U & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
        bufp->chgIData(oldp+238,((IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                          >> 4U))),32);
        bufp->chgBit(oldp+239,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                              >> 1U)))));
        bufp->chgBit(oldp+240,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                              >> 2U)))));
        bufp->chgBit(oldp+241,((1U & (IData)((vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o 
                                              >> 3U)))));
        bufp->chgQData(oldp+242,(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o),36);
        bufp->chgBit(oldp+244,((2U != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q))));
        bufp->chgBit(oldp+245,((0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q))));
        bufp->chgQData(oldp+246,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__ram_q[0]),36);
        bufp->chgQData(oldp+248,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__ram_q[1]),36);
        bufp->chgBit(oldp+250,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__rd_ptr_q));
        bufp->chgBit(oldp+251,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__wr_ptr_q));
        bufp->chgCData(oldp+252,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__count_q),2);
        bufp->chgIData(oldp+253,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__u_lsu_request__DOT__i),32);
        bufp->chgIData(oldp+254,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e3_q),32);
        bufp->chgQData(oldp+255,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__operand_a_e1_q),33);
        bufp->chgQData(oldp+257,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__operand_b_e1_q),33);
        bufp->chgCData(oldp+259,(vlSymsp->TOP__v__u_core__u_issue.__PVT__priv_x_q),2);
        bufp->chgIData(oldp+260,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_e1_q),32);
        bufp->chgIData(oldp+261,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_e1_q),32);
        bufp->chgIData(oldp+262,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_e1_q),32);
        bufp->chgIData(oldp+263,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_e1_q),32);
        bufp->chgIData(oldp+264,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q),32);
        bufp->chgIData(oldp+265,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_wb_q),32);
        bufp->chgIData(oldp+266,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_wb_q),32);
        bufp->chgCData(oldp+267,(vlSymsp->TOP__v__u_core__u_issue.__PVT__issue_fault_w),6);
        bufp->chgBit(oldp+268,(vlSymsp->TOP__v__u_core__u_issue.__PVT__div_pending_q));
        bufp->chgCData(oldp+269,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                           >> 0xfU))),5);
        bufp->chgCData(oldp+270,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                           >> 0x14U))),5);
        bufp->chgBit(oldp+271,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e1_q));
        bufp->chgIData(oldp+272,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_e1_q),32);
        bufp->chgCData(oldp+273,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e1_q),6);
        bufp->chgBit(oldp+274,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_e2_q));
        bufp->chgBit(oldp+275,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wr_e2_q));
        bufp->chgIData(oldp+276,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__csr_wdata_e2_q),32);
        bufp->chgIData(oldp+277,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__pc_e2_q),32);
        bufp->chgIData(oldp+278,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_e2_q),32);
        bufp->chgIData(oldp+279,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_e2_q),32);
        bufp->chgIData(oldp+280,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_ra_e2_q),32);
        bufp->chgIData(oldp+281,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__operand_rb_e2_q),32);
        bufp->chgCData(oldp+282,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_e2_q),6);
        bufp->chgBit(oldp+283,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__squash_e1_e2_q));
        bufp->chgBit(oldp+284,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__valid_wb_q));
        bufp->chgIData(oldp+285,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__npc_wb_q),32);
        bufp->chgCData(oldp+286,((0x1fU & (vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__opcode_wb_q 
                                           >> 7U))),5);
        bufp->chgCData(oldp+287,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_q),2);
        bufp->chgIData(oldp+288,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_q),32);
        bufp->chgSData(oldp+289,(vlSymsp->TOP__v__u_core__u_csr.__Vcellinp__u_csrfile__csr_waddr_i),12);
        bufp->chgIData(oldp+290,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mepc_q),32);
        bufp->chgIData(oldp+291,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcause_q),32);
        bufp->chgIData(oldp+292,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtvec_q),32);
        bufp->chgIData(oldp+293,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_q),32);
        bufp->chgIData(oldp+294,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mie_q),32);
        bufp->chgIData(oldp+295,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_q),32);
        bufp->chgIData(oldp+296,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_h_q),32);
        bufp->chgIData(oldp+297,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mscratch_q),32);
        bufp->chgIData(oldp+298,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtval_q),32);
        bufp->chgIData(oldp+299,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtimecmp_q),32);
        bufp->chgBit(oldp+300,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtime_ie_q));
        bufp->chgIData(oldp+301,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_medeleg_q),32);
        bufp->chgIData(oldp+302,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mideleg_q),32);
        bufp->chgIData(oldp+303,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sepc_q),32);
        bufp->chgIData(oldp+304,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stvec_q),32);
        bufp->chgIData(oldp+305,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_scause_q),32);
        bufp->chgIData(oldp+306,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stval_q),32);
        bufp->chgIData(oldp+307,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sscratch_q),32);
        bufp->chgCData(oldp+308,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_priv_q),2);
        bufp->chgBit(oldp+309,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_upd_q));
        bufp->chgIData(oldp+310,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mepc_r),32);
        bufp->chgIData(oldp+311,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sr_r),32);
        bufp->chgIData(oldp+312,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtvec_r),32);
        bufp->chgIData(oldp+313,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mie_r),32);
        bufp->chgCData(oldp+314,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mpriv_r),2);
        bufp->chgIData(oldp+315,(((IData)(1U) + vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcycle_q)),32);
        bufp->chgIData(oldp+316,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mscratch_r),32);
        bufp->chgIData(oldp+317,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtimecmp_r),32);
        bufp->chgBit(oldp+318,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtime_ie_r));
        bufp->chgIData(oldp+319,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_medeleg_r),32);
        bufp->chgIData(oldp+320,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mideleg_r),32);
        bufp->chgIData(oldp+321,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_next_q),32);
        bufp->chgIData(oldp+322,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sepc_r),32);
        bufp->chgIData(oldp+323,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stvec_r),32);
        bufp->chgIData(oldp+324,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_stval_r),32);
        bufp->chgIData(oldp+325,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_satp_r),32);
        bufp->chgIData(oldp+326,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_sscratch_r),32);
        bufp->chgBit(oldp+327,((0x10U == (0x30U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__exception_wb_q)))));
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[3U])) {
        bufp->chgIData(oldp+328,((0xfffffffcU & vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[0U])),32);
        bufp->chgIData(oldp+329,(vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[1U]),32);
        bufp->chgCData(oldp+330,((0xfU & vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w[2U])),4);
        bufp->chgBit(oldp+331,(vlSymsp->TOP__v__u_tcm.__PVT__axi_bvalid_o));
        bufp->chgCData(oldp+332,((0xfU & (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w))),4);
        bufp->chgBit(oldp+333,(vlSymsp->TOP__v__u_tcm.__PVT__axi_rvalid_o));
        bufp->chgIData(oldp+334,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__ram
                                 [vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__rd_ptr]),32);
        bufp->chgBit(oldp+335,((1U & ((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w) 
                                      >> 4U))));
        bufp->chgBit(oldp+336,(((2U != (IData)(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__count_q)) 
                                & (2U != (IData)(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__count_q)))));
        bufp->chgSData(oldp+337,(((IData)(vlSymsp->TOP__v.__PVT__u_dmux__DOT__tcm_access_q)
                                   ? (IData)(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_tag_q)
                                   : vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__ram_q
                                  [vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__rd_ptr_q])),11);
        bufp->chgSData(oldp+338,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__ram_q
                                 [vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__rd_ptr_q]),11);
        bufp->chgBit(oldp+339,(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_ack_q));
        bufp->chgSData(oldp+340,(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_tag_q),11);
        bufp->chgBit(oldp+341,(vlSymsp->TOP__v__u_tcm.__PVT__mem_i_valid_q));
        bufp->chgBit(oldp+342,((2U != (IData)(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__count_q))));
        bufp->chgBit(oldp+343,((2U != (IData)(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__count_q))));
        bufp->chgBit(oldp+344,(vlSymsp->TOP__v.__PVT__u_axi__DOT__request_pending_q));
        bufp->chgBit(oldp+345,((0U != (IData)(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__count_q))));
        bufp->chgWData(oldp+346,(vlSymsp->TOP__v.__PVT__u_axi__DOT__req_w),69);
        bufp->chgBit(oldp+349,(vlSymsp->TOP__v.__PVT__u_axi__DOT__awvalid_inhibit_q));
        bufp->chgBit(oldp+350,(vlSymsp->TOP__v.__PVT__u_axi__DOT__wvalid_inhibit_q));
        bufp->chgWData(oldp+351,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__ram_q[0]),69);
        bufp->chgWData(oldp+354,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__ram_q[1]),69);
        bufp->chgBit(oldp+357,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__rd_ptr_q));
        bufp->chgBit(oldp+358,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__wr_ptr_q));
        bufp->chgCData(oldp+359,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_req__DOT__count_q),2);
        bufp->chgBit(oldp+360,((0U != (IData)(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__count_q))));
        bufp->chgSData(oldp+361,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__ram_q[0]),11);
        bufp->chgSData(oldp+362,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__ram_q[1]),11);
        bufp->chgBit(oldp+363,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__rd_ptr_q));
        bufp->chgBit(oldp+364,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__wr_ptr_q));
        bufp->chgCData(oldp+365,(vlSymsp->TOP__v.__PVT__u_axi__DOT__u_resp__DOT__count_q),2);
        bufp->chgBit(oldp+366,(vlSymsp->TOP__v.__PVT__u_dmux__DOT__tcm_access_q));
        bufp->chgCData(oldp+367,(vlSymsp->TOP__v.__PVT__u_dmux__DOT__pending_q),5);
        bufp->chgBit(oldp+368,(vlSymsp->TOP__v__u_tcm.__PVT__ext_ack_q));
        bufp->chgCData(oldp+369,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_len_q),8);
        bufp->chgIData(oldp+370,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_addr_q),32);
        bufp->chgBit(oldp+371,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_rd_q));
        bufp->chgBit(oldp+372,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_wr_q));
        bufp->chgCData(oldp+373,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_id_q),4);
        bufp->chgCData(oldp+374,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_axburst_q),2);
        bufp->chgCData(oldp+375,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_axlen_q),8);
        bufp->chgBit(oldp+376,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_prio_q));
        bufp->chgBit(oldp+377,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_hold_rd_q));
        bufp->chgBit(oldp+378,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_hold_wr_q));
        bufp->chgBit(oldp+379,((4U != (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__count))));
        bufp->chgBit(oldp+380,((0U != (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__count))));
        bufp->chgCData(oldp+381,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w),6);
        bufp->chgBit(oldp+382,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__resp_is_write_w));
        bufp->chgBit(oldp+383,(((0U != (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__count)) 
                                & ((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_out_w) 
                                   >> 5U))));
        bufp->chgBit(oldp+384,((0U != (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__count))));
        bufp->chgBit(oldp+385,((((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_prio_q) 
                                 & (~ (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_hold_rd_q))) 
                                | (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_hold_wr_q))));
        bufp->chgBit(oldp+386,((1U & (((~ (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_prio_q)) 
                                       & (~ (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_hold_wr_q))) 
                                      | (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_hold_rd_q)))));
        bufp->chgCData(oldp+387,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__ram[0]),6);
        bufp->chgCData(oldp+388,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__ram[1]),6);
        bufp->chgCData(oldp+389,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__ram[2]),6);
        bufp->chgCData(oldp+390,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__ram[3]),6);
        bufp->chgCData(oldp+391,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__rd_ptr),2);
        bufp->chgCData(oldp+392,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__wr_ptr),2);
        bufp->chgCData(oldp+393,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_requests__DOT__count),3);
        bufp->chgBit(oldp+394,((4U != (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__count))));
        bufp->chgIData(oldp+395,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__ram[0]),32);
        bufp->chgIData(oldp+396,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__ram[1]),32);
        bufp->chgIData(oldp+397,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__ram[2]),32);
        bufp->chgIData(oldp+398,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__ram[3]),32);
        bufp->chgCData(oldp+399,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__rd_ptr),2);
        bufp->chgCData(oldp+400,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__wr_ptr),2);
        bufp->chgCData(oldp+401,(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__u_response__DOT__count),3);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[4U])) {
        bufp->chgIData(oldp+402,(vlSymsp->TOP__v__u_tcm__u_ram.__PVT__ram_read1_q),32);
        bufp->chgIData(oldp+403,(vlSymsp->TOP__v__u_tcm__u_ram.__PVT__ram_read0_q),32);
        bufp->chgIData(oldp+404,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r1_q),32);
        bufp->chgIData(oldp+405,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r2_q),32);
        bufp->chgIData(oldp+406,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r3_q),32);
        bufp->chgIData(oldp+407,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r4_q),32);
        bufp->chgIData(oldp+408,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r5_q),32);
        bufp->chgIData(oldp+409,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r6_q),32);
        bufp->chgIData(oldp+410,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r7_q),32);
        bufp->chgIData(oldp+411,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r8_q),32);
        bufp->chgIData(oldp+412,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r9_q),32);
        bufp->chgIData(oldp+413,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r10_q),32);
        bufp->chgIData(oldp+414,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r11_q),32);
        bufp->chgIData(oldp+415,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r12_q),32);
        bufp->chgIData(oldp+416,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r13_q),32);
        bufp->chgIData(oldp+417,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r14_q),32);
        bufp->chgIData(oldp+418,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r15_q),32);
        bufp->chgIData(oldp+419,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r16_q),32);
        bufp->chgIData(oldp+420,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r17_q),32);
        bufp->chgIData(oldp+421,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r18_q),32);
        bufp->chgIData(oldp+422,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r19_q),32);
        bufp->chgIData(oldp+423,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r20_q),32);
        bufp->chgIData(oldp+424,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r21_q),32);
        bufp->chgIData(oldp+425,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r22_q),32);
        bufp->chgIData(oldp+426,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r23_q),32);
        bufp->chgIData(oldp+427,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r24_q),32);
        bufp->chgIData(oldp+428,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r25_q),32);
        bufp->chgIData(oldp+429,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r26_q),32);
        bufp->chgIData(oldp+430,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r27_q),32);
        bufp->chgIData(oldp+431,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r28_q),32);
        bufp->chgIData(oldp+432,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r29_q),32);
        bufp->chgIData(oldp+433,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r30_q),32);
        bufp->chgIData(oldp+434,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__reg_r31_q),32);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[5U])) {
        bufp->chgIData(oldp+435,((0xfffffffcU & vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q)),32);
        bufp->chgBit(oldp+436,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
        bufp->chgBit(oldp+437,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q));
        bufp->chgIData(oldp+438,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q),32);
        bufp->chgBit(oldp+439,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
        bufp->chgIData(oldp+440,((0xfffffffcU & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)),32);
        bufp->chgBit(oldp+441,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q));
        bufp->chgBit(oldp+442,((0x10000U > (0xfffffffcU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
        bufp->chgCData(oldp+443,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                           >> 7U))),5);
        bufp->chgIData(oldp+444,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__wb_result_q),32);
        bufp->chgBit(oldp+445,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q));
        bufp->chgCData(oldp+446,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                           >> 0x14U))),5);
        bufp->chgBit(oldp+447,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_mul_w));
        bufp->chgIData(oldp+448,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_wb_q),32);
        bufp->chgIData(oldp+449,(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_target_q),32);
        bufp->chgIData(oldp+450,(vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w),32);
        bufp->chgCData(oldp+451,((0x1fU & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                           >> 0xfU))),5);
        bufp->chgBit(oldp+452,((((((((((3U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                       | (0x1003U == 
                                          (0x707fU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                      | (0x2003U == 
                                         (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                     | (0x4003U == 
                                        (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                    | (0x5003U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x6003U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x23U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x1023U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2023U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+453,(((((((((0x6fU == (0x7fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                      | (0x67U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                     | (0x63U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                    | (0x1063U == (0x707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                   | (0x4063U == (0x707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                  | (0x5063U == (0x707fU 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x6063U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x7063U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+454,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_exec_w));
        bufp->chgBit(oldp+455,(vlSymsp->TOP__v__u_core__u_csr.__PVT__take_interrupt_q));
        bufp->chgIData(oldp+456,(vlSymsp->TOP__v__u_core__u_csr.__PVT__rd_result_e1_q),32);
        bufp->chgIData(oldp+457,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_instr_w),32);
        bufp->chgBit(oldp+458,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_div_w));
        bufp->chgBit(oldp+459,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_rd_valid_w));
        bufp->chgIData(oldp+460,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__result_e2_q),32);
        bufp->chgIData(oldp+461,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__result_q),32);
        bufp->chgBit(oldp+462,((0x2004033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+463,((0x2005033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+464,((0x2006033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+465,((0x2007033U == (0xfe00707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+466,(((((0x2004033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                  | (0x2005033U == 
                                     (0xfe00707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                 | (0x2006033U == (0xfe00707fU 
                                                   & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2007033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+467,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__signed_operation_w));
        bufp->chgBit(oldp+468,(((0x2004033U == (0xfe00707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x2005033U == (0xfe00707fU 
                                                  & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgIData(oldp+469,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q),32);
        bufp->chgIData(oldp+470,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q),32);
        bufp->chgBit(oldp+471,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_inst_q));
        bufp->chgBit(oldp+472,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q));
        bufp->chgBit(oldp+473,(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_complete_w));
        bufp->chgIData(oldp+474,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__div_inst_q)
                                   ? ((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q)
                                       ? (- vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q)
                                       : vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__quotient_q)
                                   : ((IData)(vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__invert_res_q)
                                       ? (- vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q)
                                       : vlSymsp->TOP__v__u_core.__PVT__u_div__DOT__dividend_q))),32);
        bufp->chgIData(oldp+475,((0xfffff000U & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)),32);
        bufp->chgIData(oldp+476,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__imm12_r),32);
        bufp->chgIData(oldp+477,((((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                               >> 0x1fU))) 
                                   << 0xdU) | ((0x1000U 
                                                & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                   >> 0x13U)) 
                                               | ((0x800U 
                                                   & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                      << 4U)) 
                                                  | ((0x7e0U 
                                                      & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                         >> 0x14U)) 
                                                     | (0x1eU 
                                                        & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                           >> 7U))))))),32);
        bufp->chgIData(oldp+478,((((- (IData)((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                               >> 0x1fU))) 
                                   << 0x14U) | ((0xff000U 
                                                 & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w) 
                                                | ((0x800U 
                                                    & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                       >> 9U)) 
                                                   | ((0x7e0U 
                                                       & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                          >> 0x14U)) 
                                                      | (0x1eU 
                                                         & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                                            >> 0x14U))))))),32);
        bufp->chgCData(oldp+479,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__alu_func_r),4);
        bufp->chgBit(oldp+480,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_r));
        bufp->chgBit(oldp+481,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_call_r));
        bufp->chgBit(oldp+482,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_ret_r));
        bufp->chgBit(oldp+483,(vlSymsp->TOP__v__u_core.__PVT__u_exec__DOT__branch_jmp_r));
        bufp->chgBit(oldp+484,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_q));
        bufp->chgIData(oldp+485,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_pc_q),32);
        bufp->chgIData(oldp+486,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q),32);
        bufp->chgIData(oldp+487,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q),32);
        bufp->chgBit(oldp+488,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_rd_q));
        bufp->chgCData(oldp+489,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_wr_q),4);
        bufp->chgBit(oldp+490,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q));
        bufp->chgBit(oldp+491,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q));
        bufp->chgBit(oldp+492,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_load_q));
        bufp->chgBit(oldp+493,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xb_q));
        bufp->chgBit(oldp+494,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xh_q));
        bufp->chgBit(oldp+495,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_ls_q));
        bufp->chgBit(oldp+496,(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__load_inst_w));
        bufp->chgBit(oldp+497,((((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x1003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+498,((((0x23U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x1023U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x2023U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+499,(((3U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x4003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+500,(((0x1003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x5003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+501,(((0x2003U == (0x707fU 
                                             & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                | (0x6003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+502,((0x23U == (0x707fU & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+503,((0x1023U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+504,((0x2023U == (0x707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))));
        bufp->chgBit(oldp+505,((((0x2023U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x2003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x6003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+506,((((0x1023U == (0x707fU 
                                              & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)) 
                                 | (0x1003U == (0x707fU 
                                                & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w))) 
                                | (0x5003U == (0x707fU 
                                               & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+507,((IData)((0x3a001073U 
                                        == (0xfff0707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+508,((IData)((0x3a101073U 
                                        == (0xfff0707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgBit(oldp+509,((IData)((0x3a201073U 
                                        == (0xfff0707fU 
                                            & vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w)))));
        bufp->chgQData(oldp+510,((((QData)((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                                   << 4U) | (QData)((IData)(
                                                            (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_ls_q) 
                                                              << 3U) 
                                                             | (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xh_q) 
                                                                 << 2U) 
                                                                | (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_xb_q) 
                                                                    << 1U) 
                                                                   | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_load_q)))))))),36);
        bufp->chgBit(oldp+512,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mulhi_sel_e1_q));
        bufp->chgWData(oldp+513,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w),65);
        bufp->chgIData(oldp+516,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mulhi_sel_e1_q)
                                   ? vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w[1U]
                                   : vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_result_w[0U])),32);
        bufp->chgBit(oldp+517,(vlSymsp->TOP__v__u_core.__PVT__u_mul__DOT__mult_inst_w));
        bufp->chgBit(oldp+518,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 1U))));
        bufp->chgBit(oldp+519,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 2U))));
        bufp->chgBit(oldp+520,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 5U))));
        bufp->chgBit(oldp+521,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 6U))));
        bufp->chgCData(oldp+522,(vlSymsp->TOP__v__u_core__u_issue.__PVT__pipe_rd_e1_w),5);
        bufp->chgBit(oldp+523,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                      >> 1U))));
        bufp->chgBit(oldp+524,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q) 
                                      >> 5U))));
        bufp->chgBit(oldp+525,(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_pending_q));
        bufp->chgIData(oldp+526,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__ra0_value_r),32);
        bufp->chgIData(oldp+527,(vlSymsp->TOP__v__u_core__u_issue__u_regfile.__PVT__REGFILE__DOT__rb0_value_r),32);
        bufp->chgSData(oldp+528,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q),10);
        bufp->chgBit(oldp+529,((1U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q))));
        bufp->chgBit(oldp+530,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 3U))));
        bufp->chgBit(oldp+531,((1U & ((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e1_q) 
                                      >> 4U))));
        bufp->chgSData(oldp+532,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q),10);
        bufp->chgIData(oldp+533,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__result_e2_q),32);
        bufp->chgBit(oldp+534,((IData)((0U != (6U & (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_e2_q))))));
        bufp->chgSData(oldp+535,(vlSymsp->TOP__v__u_core__u_issue.__PVT__u_pipe_ctrl__DOT__ctrl_wb_q),10);
        bufp->chgSData(oldp+536,((0x3fffU & (vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__pc_f_q 
                                             >> 2U))),14);
        bufp->chgCData(oldp+537,((3U & (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                        >> 0x1cU))),2);
        bufp->chgBit(oldp+538,((3U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                       >> 0x1eU))));
        bufp->chgIData(oldp+539,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__rdata_r),32);
        bufp->chgBit(oldp+540,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__branch_r));
        bufp->chgIData(oldp+541,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__branch_target_r),32);
        bufp->chgIData(oldp+542,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_masked_r),32);
        bufp->chgBit(oldp+543,(vlSymsp->TOP__v__u_core__u_csr.__PVT__reset_q));
        bufp->chgSData(oldp+544,((vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                  >> 0x14U)),12);
        bufp->chgIData(oldp+545,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__irq_pending_r),32);
        bufp->chgIData(oldp+546,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mcause_r),32);
        bufp->chgIData(oldp+547,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mtval_r),32);
        bufp->chgIData(oldp+548,(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_scause_r),32);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[6U])) {
        bufp->chgBit(oldp+549,(vlSymsp->TOP__v.__PVT__dport_tcm_flush_w));
        bufp->chgBit(oldp+550,(vlSymsp->TOP__v.__PVT__dport_tcm_invalidate_w));
        bufp->chgBit(oldp+551,(vlSymsp->TOP__v.__PVT__dport_tcm_writeback_w));
        bufp->chgBit(oldp+552,(vlSymsp->TOP__v.__PVT__dport_accept_w));
        bufp->chgBit(oldp+553,(vlSymsp->TOP__v.__PVT__u_dmux__DOT__hold_w));
        bufp->chgBit(oldp+554,(vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__u_dec__DOT__invalid_w));
        bufp->chgBit(oldp+555,(vlSymsp->TOP__v__u_core.__PVT__fetch_dec_valid_w));
        bufp->chgBit(oldp+556,(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w));
    }
    bufp->chgIData(oldp+557,(((IData)(vlSymsp->TOP__v.__PVT__u_dmux__DOT__tcm_access_q)
                               ? vlSymsp->TOP__v__u_tcm__u_ram.__PVT__ram_read1_q
                               : vlSelf->__Vcellinp__v__axi_i_rdata_i)),32);
    bufp->chgBit(oldp+558,((((0x10000U <= (0xfffffffcU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                             & (~ (IData)(vlSymsp->TOP__v.__PVT__u_dmux__DOT__hold_w))) 
                            & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q))));
    bufp->chgBit(oldp+559,(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_accept_q));
    bufp->chgBit(oldp+560,((((0x10000U <= (0xfffffffcU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                             & (~ (IData)(vlSymsp->TOP__v.__PVT__u_dmux__DOT__hold_w))) 
                            & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q))));
    bufp->chgBit(oldp+561,((((0x10000U <= (0xfffffffcU 
                                           & vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                             & (~ (IData)(vlSymsp->TOP__v.__PVT__u_dmux__DOT__hold_w))) 
                            & (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q))));
    bufp->chgBit(oldp+562,((1U & (~ (IData)(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_accept_q)))));
    bufp->chgIData(oldp+563,((((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_wr_q) 
                               | (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_rd_q))
                               ? vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_addr_q
                               : ((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__write_active_w)
                                   ? vlSelf->__Vcellinp__v__axi_t_awaddr_i
                                   : vlSelf->__Vcellinp__v__axi_t_araddr_i))),32);
    bufp->chgIData(oldp+564,(((IData)(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_accept_q)
                               ? vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_data_wr_q
                               : vlSelf->__Vcellinp__v__axi_t_wdata_i)),32);
    bufp->chgCData(oldp+565,(((IData)(vlSymsp->TOP__v__u_tcm.__PVT__mem_d_accept_q)
                               ? (IData)(vlSymsp->TOP__v.__PVT__dport_tcm_wr_w)
                               : (IData)(vlSymsp->TOP__v__u_tcm.__PVT__ext_wr_w))),4);
    bufp->chgCData(oldp+566,((((IData)(vlSelf->__Vcellinp__v__axi_t_arvalid_i) 
                               & (IData)(vlSymsp->TOP__v__u_tcm.__PVT__axi_arready_o))
                               ? (0x20U | (((0U == (IData)(vlSelf->__Vcellinp__v__axi_t_arlen_i)) 
                                            << 4U) 
                                           | (IData)(vlSelf->__Vcellinp__v__axi_t_arid_i)))
                               : (((IData)(vlSelf->__Vcellinp__v__axi_t_awvalid_i) 
                                   & (IData)(vlSymsp->TOP__v__u_tcm.__PVT__axi_awready_o))
                                   ? (((0U == (IData)(vlSelf->__Vcellinp__v__axi_t_awlen_i)) 
                                       << 4U) | (IData)(vlSelf->__Vcellinp__v__axi_t_awid_i))
                                   : (((IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__read_active_w) 
                                       << 5U) | (((0U 
                                                   == (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_len_q)) 
                                                  << 4U) 
                                                 | (IData)(vlSymsp->TOP__v__u_tcm.__PVT__u_conv__DOT__req_id_q)))))),6);
    bufp->chgBit(oldp+567,(((((((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q) 
                                  | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                                 | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                                | (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w)) 
                               | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                              & (~ (IData)(vlSymsp->TOP__v.__PVT__dport_accept_w))) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__delay_lsu_e2_w)) 
                            | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e1_q))));
    bufp->chgCData(oldp+568,(((IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_q)
                               ? (IData)(vlSymsp->TOP__v__u_core__u_csr.__PVT__branch_csr_priv_o)
                               : (IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__priv_x_q))),2);
    bufp->chgBit(oldp+569,(((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_pending_q) 
                            | (IData)(vlSymsp->TOP__v__u_core.__PVT__fetch_instr_csr_w))));
    bufp->chgCData(oldp+570,((((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                               & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                               ? 0x14U : (((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                                           & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                           ? 0x16U : 
                                          (((IData)(vlSymsp->TOP__v.__PVT__dport_error_w) 
                                            & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))
                                            ? 0x15U
                                            : (((IData)(vlSymsp->TOP__v.__PVT__dport_error_w) 
                                                & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))
                                                ? 0x17U
                                                : 0U))))),6);
    bufp->chgBit(oldp+571,(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__icache_busy_w));
    bufp->chgBit(oldp+572,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_q) 
                            | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_fetch__DOT__branch_d_q))));
    bufp->chgBit(oldp+573,(((((((IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_rd_w) 
                                | (0U != (IData)(vlSymsp->TOP__v__u_core.__PVT__mmu_lsu_wr_w))) 
                               | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_writeback_q)) 
                              | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_invalidate_q)) 
                             | (IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_flush_q)) 
                            & (IData)(vlSymsp->TOP__v.__PVT__dport_accept_w))));
    bufp->chgBit(oldp+574,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                            & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
    bufp->chgBit(oldp+575,(((IData)(vlSymsp->TOP__v__u_core.__PVT__u_lsu__DOT__mem_unaligned_e2_q) 
                            & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))));
    bufp->chgBit(oldp+576,(((IData)(vlSymsp->TOP__v.__PVT__dport_error_w) 
                            & (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o))));
    bufp->chgBit(oldp+577,(((IData)(vlSymsp->TOP__v.__PVT__dport_error_w) 
                            & (~ (IData)(vlSymsp->TOP__v__u_core.u_lsu__DOT____Vcellout__u_lsu_request__data_out_o)))));
    bufp->chgBit(oldp+578,((((IData)(vlSymsp->TOP__v__u_core__u_issue.__PVT__csr_opcode_valid_o) 
                             & ((0x344U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                            >> 0x14U)) 
                                | (0x144U == (vlSymsp->TOP__v__u_core.__PVT__u_decode__DOT__genblk1__DOT__fetch_in_instr_w 
                                              >> 0x14U)))) 
                            | (IData)(vlSymsp->TOP__v__u_core__u_csr__u_csrfile.__PVT__csr_mip_upd_q))));
}

void Vriscv_tcm_top___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_cleanup\n"); );
    // Init
    Vriscv_tcm_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_tcm_top___024root*>(voidSelf);
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[4U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[5U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[6U] = 0U;
}
